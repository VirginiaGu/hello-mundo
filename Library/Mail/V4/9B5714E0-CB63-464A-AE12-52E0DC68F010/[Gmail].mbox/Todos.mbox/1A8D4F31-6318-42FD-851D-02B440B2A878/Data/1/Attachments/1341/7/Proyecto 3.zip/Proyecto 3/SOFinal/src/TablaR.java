import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JToolBar;
import javax.swing.JButton;

public class TablaR extends JFrame{

	String[] titulos={"PC","IR","AC"};
	String t="";
	int canttabla;

	Proceso Proceso = new Proceso();
	
	Vector<Proceso> ListadeHechos = new Vector<Proceso>();
	
	JPanel contentPane;
	JTable table = new JTable();
	DefaultTableModel tabla;
		
	
	public TablaR(){
		super("\tTabla");
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(1113,0,250,600);

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		setContentPane(contentPane);
		
		table.setModel(new DefaultTableModel(new Object[][] {},titulos));
		
		tabla=(DefaultTableModel) table.getModel();
		
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
			
				
	}
	
		
	public void Mostrar(){
		
		for (int i = 0; i <this.tabla.getRowCount();)
	           this.tabla.removeRow(i);
		
		ArrayList<Object[]> ListaNuevos = new ArrayList<Object[]>();
		Proceso ProcesoAux = new Proceso();
		Object[] fila = new Object[5];
		canttabla=ListadeHechos.size(); 
		
		for(int aux=0;aux<canttabla;aux++){
			ProcesoAux=ListadeHechos.get(aux);
			
			   fila[0]=ProcesoAux.error;
			   fila[1]=ProcesoAux.tama�o;
			   fila[2]=ProcesoAux.prioridad;
			   ListaNuevos.add(fila);
			   fila= new Object[5];
		}
						
			Iterator<Object[]> iteradora = ListaNuevos.iterator();
			while(iteradora.hasNext()){
			        Object[] f = iteradora.next();
			        this.tabla.addRow(f);
			}		
	}
	
	public void putunHecho(int PC, int IR, int AC){
	   Proceso.error=PC;
	   Proceso.tama�o=IR;
	   Proceso.prioridad=AC;
	   ListadeHechos.add(Proceso);
	   Proceso=new Proceso();
			   
	}
	
}