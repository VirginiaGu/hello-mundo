//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 3
package sistemaDistribuido.sistema.rpc.modoUsuario;

import sistemaDistribuido.sistema.rpc.modoUsuario.Libreria;
import sistemaDistribuido.util.Escribano;

public class LibreriaServidor extends Libreria{

	/**
	 * 
	 */
	public LibreriaServidor(Escribano esc){
		super(esc);
	}

	/**
	 * Ejemplo de servidor suma verdadera
	 */
	/*protected void suma(){
		//saca parametros de pila

		//devuelve valor izquierdo
	}*/
	
	@Override
	protected void sum() {
		// TODO Auto-generated method stub
		int resultado,aux;
		aux=(int) pila.peek();
		pila.pop();
		resultado=aux;
		aux=(int) pila.peek();
		pila.pop();
		resultado=resultado+aux;
		pila.push(Integer.valueOf(resultado));
		
	}

	@Override
	protected void cubo() {
		// TODO Auto-generated method stub
		int resultado,aux;
		aux=(int) pila.peek();
		pila.pop();
		resultado=aux*aux*aux;
		pila.push(Integer.valueOf(resultado));
	}

	@Override
	protected void div() {
		// TODO Auto-generated method stub127.0.0
		int resultado,aux1, aux2;
		aux1=(int) pila.peek();
		pila.pop();
		aux2=(int) pila.peek();
		pila.pop();
		resultado=aux1/aux2;
		pila.push(Integer.valueOf(resultado));
	}

	@Override
	protected void cuad() {
		// TODO Auto-generated method stub
		int resultado,aux;
		aux=(int) pila.peek();
		pila.pop();
		resultado=aux*aux;
		pila.push(Integer.valueOf(resultado));
	}

	@Override
	protected void suma() {
		// TODO Auto-generated method stub
		
	}

}