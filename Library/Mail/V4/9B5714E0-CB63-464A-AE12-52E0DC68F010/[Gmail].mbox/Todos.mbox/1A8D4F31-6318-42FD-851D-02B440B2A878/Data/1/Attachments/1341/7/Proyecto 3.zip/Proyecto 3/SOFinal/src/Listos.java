import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JToolBar;
import javax.swing.JButton;


public class Listos extends JFrame{

	String[] titulos={"Proceso","Tama�o","Prioridad","Error","Bloqueo"};
	String t="";
	int algoritmo, cantListos;

	Proceso Proceso = new Proceso();
	
	Vector<Proceso> ListadeListos = new Vector<Proceso>();
	
	JPanel contentPane;
	JTable table = new JTable();
	DefaultTableModel tabla;
	JFileChooser buscador = new JFileChooser();
		
	
	public Listos(){
		super("\tListos");
		buscador.setDialogTitle("Abrir Documento");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(742,0,370,300);

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		setContentPane(contentPane);
		
		table.setModel(new DefaultTableModel(new Object[][] {},titulos));
		
		tabla=(DefaultTableModel) table.getModel();
		
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
		
		
	}
	
	
	public void Mostrar(){
		
		for (int i = 0; i <tabla.getRowCount();)
	           tabla.removeRow(i);
		
		ArrayList<Object[]> ListaListos = new ArrayList<Object[]>();
		Proceso ProcesoAux = new Proceso();
		Object[] fila = new Object[5];
		cantListos=ListadeListos.size(); 
				
		for(int aux=0;aux<cantListos;aux++){
			ProcesoAux=ListadeListos.get(aux);
			
			   fila[0]=ProcesoAux.ID;
			   fila[1]=ProcesoAux.tama�o;
			   fila[2]=ProcesoAux.prioridad;
			   fila[3]=ProcesoAux.error;
			   fila[4]=ProcesoAux.bloqueo;
			  
			   ListaListos.add(fila);
			   fila= new Object[5];
		}
						
			Iterator<Object[]> iterador = ListaListos.iterator();
			while(iterador.hasNext()){
			        Object[] f = iterador.next();
			        tabla.addRow(f);
			}		
	}
	
		
	public void setListadeListos(Vector<Proceso> Lista){
		this.ListadeListos=Lista;
	}
	
	public Proceso getunListo(){
		Proceso Procesoaux = new Proceso();
	    Procesoaux=ListadeListos.elementAt(0);
	    ListadeListos.removeElement(Procesoaux);
	    return Procesoaux;
		
	}
	
	public void putunListo(Proceso RecienListo){
		ListadeListos.add(RecienListo);
		
	}
		
	public void SJF(){
		Vector<Proceso> vectoraux = new Vector<Proceso>();
		Proceso Procesoaux = new Proceso();
		do{
		   Procesoaux=ListadeListos.elementAt(0);
		   for(int i=0; i<ListadeListos.size();i++){
			  if(Procesoaux.tama�o>ListadeListos.elementAt(i).tama�o)
				 Procesoaux=ListadeListos.elementAt(i);
           }
		   ListadeListos.removeElement(Procesoaux);
		   vectoraux.add(Procesoaux);
		}while(ListadeListos.size()!=0);
		
		ListadeListos=vectoraux;
		
	}
	
	public void Priori(){
		Vector<Proceso> vectoraux = new Vector<Proceso>();
		Proceso Procesoaux = new Proceso();
		do{
		   Procesoaux=ListadeListos.elementAt(0);
		   for(int i=0; i<ListadeListos.size();i++){
			  if(Procesoaux.prioridad<ListadeListos.elementAt(i).prioridad)
				 Procesoaux=ListadeListos.elementAt(i);
           }
		   ListadeListos.removeElement(Procesoaux);
		   vectoraux.add(Procesoaux);
		}while(ListadeListos.size()!=0);
		
		ListadeListos=vectoraux;
		
	}
	
	
}