import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultCaret;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ScrollPaneConstants;

public class Nucleo extends JFrame {

	private JPanel contentPane;
	private JTextArea textArea;
	private JComboBox comboBox;
	private CSControlSingleton clt = CSControlSingleton.getInstance();
	private JMenuItem menuCliente;
	private JMenuItem menuServidor;
	private int ip;

	public static void main(String[] args) {
		Nucleo frame = new Nucleo();
		frame.setVisible(true);
		try {
			frame.arranque();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Nucleo() {
		setTitle("Micro N\u00FAcleo");
		this.ip=30000;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 376, 486);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNuevo = new JMenu("Nuevo");
		menuBar.add(mnNuevo);
		
		menuCliente = new JMenuItem("Cliente");
		menuCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crearCliente();
				comboBox.setModel(new DefaultComboBoxModel(clt.listaProcesos()));
				if(clt.cDisponibles()==0){
					menuCliente.setEnabled(false);
				}else{
					menuCliente.setEnabled(true);
				}
			}
		});
		mnNuevo.add(menuCliente);
		
		menuServidor = new JMenuItem("Servidor");
		menuServidor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crearServidor();
				comboBox.setModel(new DefaultComboBoxModel(clt.listaProcesos()));
				if(clt.sDisponibles()==0){
					menuServidor.setEnabled(false);
				}else{
					menuServidor.setEnabled(true);
				}
			}
		});
		mnNuevo.add(menuServidor);
		
		JMenu mnEliminar = new JMenu("Eliminar");
		menuBar.add(mnEliminar);
		
		JMenuItem mntmSeleccionarProceso = new JMenuItem("Eliminar Seleccionado");
		mntmSeleccionarProceso.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String elegida = (String) comboBox.getSelectedItem();
				if(elegida!=null && !elegida.equals("...")){
					if(elegida.startsWith("S")){
						clt.disposeServidor(elegida).dispose();
						clt.servidorPush(elegida);
						clt.eliminarServidor(elegida);
					}else{
						clt.disposeCliente(elegida).dispose();
						clt.clientePush(elegida);
						clt.eliminarCliente(elegida);
					}
				}
			}
		});
		mnEliminar.add(mntmSeleccionarProceso);
		
		JMenu mnOpciones = new JMenu("Opciones");
		menuBar.add(mnOpciones);
		
		JMenuItem mntmCerrarAplicacin = new JMenuItem("Cerrar aplicaci\u00F3n");
		mntmCerrarAplicacin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnOpciones.add(mntmCerrarAplicacin);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 34, 340, 161);
		contentPane.add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		DefaultCaret caret_creados = (DefaultCaret)textArea.getCaret();
		caret_creados.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		scrollPane.setViewportView(textArea);
		
		JLabel lblEventos = new JLabel("Eventos");
		lblEventos.setBounds(10, 11, 46, 14);
		contentPane.add(lblEventos);
		
		comboBox = new JComboBox();
		comboBox.setBounds(12, 231, 338, 30);
		contentPane.add(comboBox);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"..."}));
		
		JLabel lblProcesosAbiertos = new JLabel("Procesos Abiertos");
		lblProcesosAbiertos.setBounds(10, 206, 162, 14);
		contentPane.add(lblProcesosAbiertos);
	}
	
	public void arranque()throws Exception{
		while(true){
			CSControlSingleton clt = CSControlSingleton.getInstance();
			byte[] datagramaRecibir = new byte[1024];
			byte[] datagramaEnviar = new byte[1024];
			DatagramSocket serverSocket = new DatagramSocket(25000);
			DatagramPacket paqueteRecibido = new DatagramPacket(datagramaRecibir, datagramaRecibir.length);
			serverSocket.receive(paqueteRecibido);
			InetAddress IPAddress = paqueteRecibido.getAddress();                   
			int port = paqueteRecibido.getPort();
			String stringRecibido = new String(paqueteRecibido.getData());
			if(stringRecibido.startsWith("Termin�")){
				//textArea.append(stringRecibido+"\n");
				textArea.append("Fin de proceso\n");
				textArea.append("ID: "+stringRecibido.substring(stringRecibido.indexOf(":")+1)+"\n");
				textArea.append("�������������������������������������\n");
				comboBox.setModel(new DefaultComboBoxModel(clt.listaProcesos()));
				if(clt.cDisponibles()>0)
					menuCliente.setEnabled(true);
				if(clt.sDisponibles()>0)
					menuServidor.setEnabled(true);
			}else if(stringRecibido.startsWith("C")){
				String[] paquete = stringRecibido.split("~");
				textArea.append(paquete[0]+" Ha solicitado un servidor\n");
				if(clt.sDisponibles()==16){
					textArea.append("La solicitud no podr� procesarse, Servidores == 0\n");
					textArea.append("�������������������������������������\n");
					datagramaEnviar=("No hay servidores disponibles").getBytes();
					DatagramPacket sendPacket = new DatagramPacket(datagramaEnviar, datagramaEnviar.length, IPAddress, port);
					serverSocket.send(sendPacket);
				}else{
					String[] serv = clt.getAServer().split("~");
					textArea.append("Enlazando "+serv[0]+" con la solicitud de "+paquete[0]+"\n");
					textArea.append("�������������������������������������\n");
					///
					byte[] toServer = new byte[1024];
					byte[] fromServer = new byte[1024];
					toServer=stringRecibido.getBytes();				
					DatagramSocket conection = new DatagramSocket();
					InetAddress IP = InetAddress.getByName("localhost");
					DatagramPacket sending = new DatagramPacket(toServer, toServer.length, IP, Integer.parseInt(serv[1]));
					conection.send(sending);
					DatagramPacket llegando = new DatagramPacket(fromServer, fromServer.length);      
					conection.receive(llegando);
					String response = new String(llegando.getData());
					conection.close();
					datagramaEnviar=response.getBytes();
					DatagramPacket sendPacket = new DatagramPacket(datagramaEnviar, datagramaEnviar.length, IPAddress, port);
					serverSocket.send(sendPacket);
				}
			}
			serverSocket.close();
		}
	}
	
	public static String receive(int ip){
		byte[] datagramaRecibir = new byte[1024];
		byte[] datagramaEnviar = new byte[1024];
		try{
			DatagramSocket serverSocket = new DatagramSocket(25000);
			DatagramPacket paqueteRecibido = new DatagramPacket(datagramaRecibir, datagramaRecibir.length);
			InetAddress IPAddress = paqueteRecibido.getAddress();                   
			int port = paqueteRecibido.getPort();
			serverSocket.receive(paqueteRecibido);
			String stringRecibido = new String(paqueteRecibido.getData());
			serverSocket.close();
			return stringRecibido;
		}catch(IOException e){
			return "Error en el env�o del mensaje";
		}
	}
	
	public static void send(String datagrama, int ip){
		byte[] datagramaEnviar = new byte[1024];
		datagramaEnviar=datagrama.getBytes();
		try {
			DatagramSocket clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			DatagramPacket paqueteEnviar = new DatagramPacket(datagramaEnviar, datagramaEnviar.length, IPAddress, ip);
			clientSocket.send(paqueteEnviar);
			clientSocket.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	private void crearCliente(){
		CSControlSingleton clt = CSControlSingleton.getInstance();
		if(clt.cDisponibles()>0){
			String id=clt.clientePop();
			ClienteGUI cliente = new ClienteGUI(id);
			clt.registrarCliente(id, cliente);
			cliente.setVisible(true);
			textArea.append("Inicio de proceso\n");
			textArea.append("Tipo: Cliente\n");
			textArea.append("ID: "+id+"\n");
			textArea.append("�������������������������������������\n");
		}else{
			JOptionPane.showMessageDialog(null, "Limite de 16 Clientes alcanzado", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private void crearServidor(){
		CSControlSingleton clt = CSControlSingleton.getInstance();
		if(clt.sDisponibles()>0){
			String id=clt.servidorPop();
			ServidorGUI servidor = new ServidorGUI(id,ip++);
			clt.registrarServidor(id, servidor);
			servidor.setVisible(true);
			textArea.append("Inicio de proceso\n");
			textArea.append("Tipo: Servidor\n");
			textArea.append("ID: "+id+"\n");
			textArea.append("�������������������������������������\n");
		}else{
			JOptionPane.showMessageDialog(null, "Limite de 16 Servidores alcanzado", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
