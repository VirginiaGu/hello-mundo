import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JToolBar;
import javax.swing.JButton;


public class Bloqueados extends JFrame{

	String[] titulos={"Proceso","Tama�o","Prioridad","Error","Bloqueo","Contador"};
	String t="";
	int algoritmo, cantBloqueados;
	int flagbloq=0;
	Proceso Proceso = new Proceso();
	Vector<Proceso> ListadeBloqueados = new Vector<Proceso>();	
	JPanel contentPane;
	JTable table = new JTable();
	DefaultTableModel tabla;
		
	public Bloqueados(){
		super("\tESTADO BLOQUEADO");		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(452,302,450,300);		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(15,15,15,15));
		contentPane.setLayout(new BorderLayout(0,0));
		contentPane.setBackground(Color.red);
		setContentPane(contentPane);		
		table.setModel(new DefaultTableModel(new Object[][] {},titulos));		
		tabla=(DefaultTableModel) table.getModel();		
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);				
	}//Bloqueados
			
	public void Mostrar(){		
		for (int i = 0; i <tabla.getRowCount();)
	           tabla.removeRow(i);
				ArrayList<Object[]> ListaBloqueados = new ArrayList<Object[]>();
		Proceso ProcesoAux = new Proceso();
		Object[] fila = new Object[6];
		cantBloqueados=ListadeBloqueados.size(); 		
		for(int aux=0;aux<cantBloqueados;aux++){
			ProcesoAux=ListadeBloqueados.get(aux);			
			   fila[0]=ProcesoAux.ID;
			   fila[1]=ProcesoAux.tama�o;
			   fila[2]=ProcesoAux.prioridad;
			   fila[3]=ProcesoAux.error;
			   fila[4]=ProcesoAux.bloqueo;
			   fila[5]=ProcesoAux.contador;
			   ListaBloqueados.add(fila);
			   fila= new Object[6];
		}//for						
			Iterator<Object[]> iterador = ListaBloqueados.iterator();
			while(iterador.hasNext()){
			        Object[] f = iterador.next();
			        tabla.addRow(f);
			}//while	
	}//Mostrar
	
	public Proceso getunBloqueado(){
		Proceso Procesoaux = new Proceso();
	    Procesoaux=ListadeBloqueados.elementAt(0);
	    ListadeBloqueados.removeElement(Procesoaux);
	    Procesoaux.contador=0;
	    Procesoaux.tama�o--;
	    return Procesoaux;		
	}//getunBloqueado
	
	public void putunBloqueado(Proceso RecienBloq){
		ListadeBloqueados.add(RecienBloq);
		
	}//puntunBloqueado	
	
	public void ajusteBloqueados(){
		flagbloq=0;
		Proceso Procesoaux = new Proceso();		
		if(ListadeBloqueados.size()>0){
			for(int i=0; i<ListadeBloqueados.size();i++){
			   Procesoaux=ListadeBloqueados.elementAt(0);
			   ListadeBloqueados.removeElement(Procesoaux);
			   if(Procesoaux.contador>=10)
				  flagbloq=1;			   
			   else
			      Procesoaux.contador++;			    
			   ListadeBloqueados.add(Procesoaux);		     
			}//for		    
		}//if		
	}//ajusteBloqueados
}//Clase Bloqueados