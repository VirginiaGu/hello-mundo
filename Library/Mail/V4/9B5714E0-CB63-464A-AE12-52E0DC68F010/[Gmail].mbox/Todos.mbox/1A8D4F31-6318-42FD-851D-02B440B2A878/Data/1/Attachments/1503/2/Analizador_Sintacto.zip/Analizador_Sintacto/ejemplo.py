"""
class Pila:
	lista = []
	def inicializar(self):
		print ":D ",self.lista
		self.lista.append("$")
		self.lista.append(0)
	def pop(self, objeto):
		self.lista.append(objeto)
	def imprimir(self):
		print self.lista

class ide:
	estado = 0
	terminal = "T"
	noterminal = "E"
	def inicializar(self,estado):
		self.estado = estado



pila2 = Pila()
pila2.inicializar()
pila2.imprimir()

ide1 = ide()
ide1.inicializar(3)
print ide1
Pila.pop(1)
pila2.imprimir()"""

"""class Objeto:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
 
    def __str__(self):
        return "a=%s b=%s c=%s" % (self.a, self.b, self.c)
 
obj1 = Objeto(1, 2, 'a')
obj2 = Objeto(3, 4, 'b')
obj3 = Objeto(5, 6, 'c')
obj4 = Objeto(7, 8, 'd')
 
l = [obj1, obj2, obj3, obj4]
 
for obj in l:
    print obj.a, obj.b, obj.c
    print obj
    print"""
class Arbol(list):
	def __int__(self, *lista):
		for k in lista:
			self.append(k)
	def idr(self):
		if self:
			for x in self[1:]:
				if isinstance(x, list):
					x.idr()
				else:
					end = " "
					print x, end
			end = " "
			print self[0], end
	def rid(self):
		if self:
			end = " "
			print self[0], end
			for x in self[1:]:
				for x in self[1:]:
					if isinstance(x, list):
						x.rid()
					else:
						end = " "
						print x, end
	def raiz(self):
		if self:
			return self[0]
	def altura(self):
		if self:
			maxganador = 0
			for x in self[1:]:
				if isinstance(x, list):
					altura_subarbol = x.altura()
				else:
					altura_subarbol = 1
				if altura_subarbol > maxganador:
					maxganador = altura_subarbol
			return maxganador + 1
		else:
			return 0

def Generar_Nodo(numero, lista_nodos, parametros):
        lista_nodos.append(Arbol(parametros))
        print lista_nodos
        print numero

arbolito = Arbol([1, 3, Arbol([9, 15, 19, 42]), 10])
print arbolito
arbolito = Arbol([1, 3, Arbol([9, 15, 19, 42]), 10])
print arbolito
print "Hola mundo :D"

listita = []
Generar_Nodo(1,listita, [1,2,3])
Generar_Nodo(2,listita, [4,5,6])
Generar_Nodo(3,listita, [7,8,9])
Generar_Nodo(4,listita, [10,11,12])
