package mipaquete;

import java.io.*;

public class Sentencia {
	public void leer(String Archivo){
	try{
		File f;
		FileReader r = new FileReader(Archivo);
		BufferedReader lec = new BufferedReader(r);
		f=new File("Datos.txt");
		FileWriter w=new  FileWriter(f);	
			System.out.println("Archivo: " +Archivo);
				String dato = lec.readLine();
			System.out.println("No.de instrucciones: " +dato);
		        int instrucciones = Integer.parseInt(dato);
		        dato=lec.readLine();
		    System.out.println("No. de datos: " +dato);
		        int datos = Integer.parseInt(dato);
		        dato=lec.readLine();
		    System.out.println("Direccion inicial de instrucciones: " +dato);	
		        int dirins= Integer.parseInt(dato);
		        dato=lec.readLine();
		    System.out.println("Direccion inicial de datos: " +dato);
		        int dirdat= Integer.parseInt(dato);
		    System.out.println("\nInstrucciones");
		        int contins=0;
		        while(contins<instrucciones){
			       dato=lec.readLine();
			       System.out.println(dirins+"\tCod: "+dato.charAt(0)+"\tDir: "+dato.charAt(1)+dato.charAt(2)+dato.charAt(3));			
			       contins++;
			       dirins++;
		     }//while
		        System.out.println("\nDatos");
		           int contdat=0;
		             while(contdat<datos){
			            dato=lec.readLine();
			            System.out.println(dirdat+"\tValor: " +dato);
			              contdat++;
			              dirdat++;
		              }//while
	    }catch(Exception e){
		System.out.println(e.getMessage());
	};
	}//void leer	
}//clase Sentencia

