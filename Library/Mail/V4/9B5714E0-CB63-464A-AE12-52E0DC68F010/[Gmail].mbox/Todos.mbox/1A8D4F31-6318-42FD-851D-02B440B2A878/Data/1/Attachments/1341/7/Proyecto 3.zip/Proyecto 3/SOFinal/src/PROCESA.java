import java.io.*;
import java.util.*;


public class PROCESA{
	
	int Codop, Dato;
	int PC=0, IR=0,AC=0;
	int cantInstrucciones, cantProcesos, cantDatos, primInst, primDat;
	int topeinst=0, i=0, terminadas[],Memoria[][];
	
	TablaR tablita=new TablaR();
		
	
	public PROCESA(int cantInstrucciones, int cantDatos, int primInst, int primDat, int Memoria[][]){
		this.cantDatos=cantDatos;
		this.cantInstrucciones=cantInstrucciones;
		this.primDat=primDat;
		this.primInst=primInst;
		this.Memoria=Memoria;
		PC=primInst;
		terminadas=new int[cantInstrucciones];
		
	}
		
	public void Procesamiento(){
		tablita.setVisible(true);
		topeinst=primInst+cantInstrucciones;
		
		
		int  j=0, bandera=0;					
														//j es el contador auxiliar para revisar si ya se paso por las direcciones de memoria
		if(PC<topeinst && PC>=primInst && bandera!=1){								//bandera se activa s� se detecta que se esta repitiendo alguna direccion
			
			while(tablita.ListadeHechos.size()>=j){
				
				if(terminadas[j]==PC)
					bandera=1;
					
			j++;	
			}
			
			if(bandera!=1){
				i=0;
			  terminadas[tablita.ListadeHechos.size()]=PC;
			  while(Memoria[0][i]!=PC)
					i++;
			  //System.out.println("PC"+ PC);
			  IR=Memoria[1][i];
			  Codop=SeparaCodop(IR);
			  Dato=IR-(Codop*1000);
			  if(ValidaDato()&&ValidaCodop())
			     Estados();
			  
			  PC++;
			  
			}
			
		}
		//Instrucciones();
		System.out.println("PC: "+ PC);
		Datos();
		tablita.Mostrar();
		System.out.println("\n");
	}
	
	public int SeparaCodop(int instruccion){
		if(instruccion<1000)
			return Codop=0;
		else
			Codop=instruccion/1000;
			return Codop;
	}
	
	public void Estados(){
		this.i=0;
		switch (Codop){
			
			case 0:
				tablita.putunHecho(PC, IR, AC);
				PC=Dato;
				PC--;
			break;
		
			case 1:
				while(Memoria[0][i]!=Dato)
					i++;
				AC=Memoria[1][i];
				tablita.putunHecho(PC, IR, AC);
				break;
				
			case 2:
				while(Memoria[0][i]!=Dato)
					i++;
				Memoria[1][i]=AC;
				tablita.putunHecho(PC, IR, AC);
				break;
				
			case 3:
				while(Memoria[0][i]!=Dato)
					i++;
				AC+=Memoria[1][i];
				tablita.putunHecho(PC, IR, AC);
				break;
				
			case 4:
				while(Memoria[0][i]!=Dato)
					i++;
				AC-=Memoria[1][i];
				tablita.putunHecho(PC, IR, AC);
				break;
				
			case 5:
				while(Memoria[0][i]!=Dato)
					i++;
				AC*=Memoria[1][i];
				tablita.putunHecho(PC, IR, AC);
				break;
				
			case 6:
				while(Memoria[0][i]!=Dato)
					i++;
				AC/=Memoria[1][i];
				tablita.putunHecho(PC, IR, AC);
				break;
				
			case 7:
				try{
					
					int ext=0;
					FileReader a = new FileReader ("Archivo.txt");
			           BufferedReader b = new BufferedReader (a);	
			        	   ext=Integer.parseInt(b.readLine());
			        AC+=ext;
			           
			        b.close();
			        a.close();
			        tablita.putunHecho(PC, IR, AC);
				}catch(IOException ioe){
		        	System.out.println(ioe);
		        }
				break;
				
			case 8:
				try{
					FileWriter instruc1 = new FileWriter(new File("Archivo.txt"));
					instruc1.write(Integer.toString(AC));
					instruc1.close();
					tablita.putunHecho(PC, IR, AC);
				}catch(IOException ioe){
					System.out.println(ioe);
				}
				break;
				
			case 9:
				try{
				
					FileWriter apunta2 = new FileWriter(new File("Secundario.txt"));
					for(int y=0; y<cantInstrucciones+cantDatos;y++)
						apunta2.write(Integer.toString(Memoria[0][y])+" " +Integer.toString(Memoria[1][y])+ " \n");
					
					apunta2.close();
					tablita.putunHecho(PC, IR, AC);
				}catch(IOException ioe){
					System.out.println(ioe);
				}
				break;
				
			default:
				
				break;
				
	
		
		}
	}
	
	
	public void ImprimeMem(){
    	for(int i=0; i<cantInstrucciones+cantDatos;i++)
    	System.out.println("Localidad " + Memoria[0][i] + ": " + Memoria[1][i]);
    }

	
	public void Datos(){
		System.out.println("\nDatos:");
		for(int j= cantInstrucciones;j<cantDatos+cantInstrucciones;j++){
			System.out.println((primDat+j-cantInstrucciones) + " Valor: " + Memoria[1][j] );
		}
			
	}
	
	public boolean ValidaDato(){
		if(Codop<7)
		   if(Dato<primDat||Dato>(primDat+cantDatos-1))
		      return false;
		
			return true;
    }
	
	public boolean ValidaCodop(){
		if(Codop<0||Codop>9)
		   return false;
		else
			return true;
    }

}