/*
 * Pr�ctica #2: Modelo Cliente / Servidor 
 * Administraci�n de Procesos y Mecanismo de Comunicaci�n B�sico 
 * @author: Adriana Guadalupe Montes D�az
 */

package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

public class Par implements ParMaquinaProceso {
	String ip;
	int id;
	
	public Par(int id, String ip) {
		this.id = id;
		this.ip = ip;
	}
	
	@Override
	public String dameIP() {
		// TODO Auto-generated method stub
		return ip;
	}

	@Override
	public int dameID() {
		// TODO Auto-generated method stub
		return id;
	}

}
