package mipaquete;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class ProductorConsumidor extends JFrame{
		private JPanel contentPane;
		public static JTextArea area;
		public static JLabel estados;
		
		public ProductorConsumidor() {
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(20, 20, 450, 300);
			contentPane = new JPanel();
			estados =new JLabel("Estados");
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			contentPane.setLayout(new BorderLayout(0, 0));		
			estados.setBounds(0, 350, 80, 70);
			estados.setVisible(true);
			area = new JTextArea (10,10);
			setContentPane(contentPane);
			getContentPane().add(estados, BorderLayout.SOUTH);
			getContentPane().add(area, BorderLayout.CENTER);			
		}//ProductorConsumidor	
		
		public static void main(String[] args){
			Stack p=new Stack();
			Random r = new Random();//constructor
			int cont1=0, cont2=0, comp=0, opc=0;
			int T=70;//tiempo
			ProductorConsumidor v = new ProductorConsumidor();//constructor 
		   	v.setVisible(true);//visualiza la ventana
		
     do
      {
         area.setText("Proceso ganador: "+opc+"    Turno: "+comp); 
    	 estados.setText("Elementos: "+p);
 	 	 comp++;
    	 opc=r.nextInt(3);
    	switch(opc)
    {
  	case 0:
  		if(cont1<20&&p.size()<20)
  			p=Productor1(p);
  			cont1++;
  	break;
  	case 1:
  		if(cont2<20&&p.size()<20)
  			p=Productor2(p);
  		cont2++;
  	break;
  	case 2:
  		p=Consumidor(p);
  		break;
 }//switch    	
    	try {
    		Thread.sleep (T);
    	}catch (Exception e){}
  		}while(cont1<20||cont2<20||!p.empty()); 
		}//main
        
        //proceso del productor 1 de letras mayusculas aleatorias
        public static Stack Productor1(Stack p){
        	char letter;
        	Random ra = new Random();
        	int result=ra.nextInt(26);
        	result+=65;//letras mayusculas
        	letter = (char)result;
        	p.push(letter);
        return p;
        }//Productor1
        
        //proceso del productor 2 de n�meros
        public static Stack Productor2(Stack p){
           int result;
           Random ra = new Random();
           result=ra.nextInt(9);//numeros
           p.push(result);
        return p;
        }//Productor2
        
        //proceso del consumidor
        public static Stack Consumidor(Stack p){
             if(!p.empty())//checa si la pila no esta vacia
              p.pop();
             return p;
        }//consumidor
 }//ProductorConsumidor





	

