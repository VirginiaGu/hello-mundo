/*Nombre: Virginia Sayde Gutierrez Gonzalez
 *Seccion: D01
 *Tarea Java #4: Interfaz Grafica 
 */

import javax.swing.*;
import java.awt.*;

public class Ventana extends JFrame{
	JButton b1;
	JTextField t1;
	JLabel l1;
  
	 public  Ventana (){
	     b1 = new JButton("Boton");
	     this.getContentPane().add(b1,BorderLayout.SOUTH);
	     t1 = new JTextField("Texto");
	     this.getContentPane().add(t1,BorderLayout.NORTH);
	     l1 = new JLabel("HOLA");
	     this.getContentPane().add(l1,BorderLayout.CENTER);
	 }//ventana
	     
	     public static void main(String []args){
	   	  Ventana v = new Ventana();
	   	  v.setSize(790,590);
	   	  v.setVisible(true);
	   	  v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	   }//main 	     
}//clase Ventana
