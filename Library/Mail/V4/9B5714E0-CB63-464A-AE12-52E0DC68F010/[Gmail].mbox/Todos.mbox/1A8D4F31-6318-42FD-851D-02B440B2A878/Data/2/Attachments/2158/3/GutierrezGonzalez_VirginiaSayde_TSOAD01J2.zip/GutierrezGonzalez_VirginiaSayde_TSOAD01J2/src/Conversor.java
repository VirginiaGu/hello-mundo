//*Nombre: Virginia Sayde Guti�rrez Gonz�lez
//*Secci�n: D01
//*Tarea#2: Operadores para manejo de Bits

public class Conversor{	
	public void formato(int pipe){	
		System.out.print((pipe == 0) ? (" | "):(""));//imprime el formato
	}//formato
	
	public void binario(byte a){//metodo para imprimir la serie de bits para el tipo de datos de 1 byte
		int cod = 1<<7;//operador de corrimiento
		for(int i=0, pipe = 1; i<Byte.SIZE; i++, pipe++){
			if((cod & a) == 0){
				System.out.print("0");
			}//if
			else
			System.out.print("1");	
			formato(pipe %8);//da los espacios
			cod>>>=1;//operador de corrimiento
		}//for
		System.out.println();
	}//binario
	
	public void binario(short a){//metodo para imprimir la serie de bits para el tipo de datos de 2 byte
		int cod = 1<<(Short.SIZE-1);//operador de corrimiento
		for(int i=0, pipe = 1; i<Short.SIZE; i++, pipe++){
			if((cod & a) == 0){
				System.out.print("0");
			}//if
			else
			System.out.print("1");	
			formato(pipe %8);//da los espacios
			cod>>>=1;
		}//for
		System.out.println();
	}//binario

	public void binario(int a){//metodo para imprimir la serie de bits para el tipo de datos de 4 byte
		int cod = 1<<(Integer.SIZE-1);//operador de corrimiento
		for(int i=0, pipe = 1; i<Integer.SIZE; i++, pipe++){
			if((cod & a) == 0){
				System.out.print("0");
			}//if
			else
			System.out.print("1");	
			formato(pipe %8);//da los espacios
			cod>>>=1;
		}//for
		System.out.println();
	}//binario
	
	public void binario(long a){//metodo para imprimir la serie de bits para el tipo de datos de 8 byte
		int cod = 1<<(Long.SIZE-1);//operador de corrimiento
		for(int i=0, pipe = 1; i<Long.SIZE; i++, pipe++){
			if((cod & a) == 0){
				System.out.print("0");
			}//if
			else
			System.out.print("1");	
			formato(pipe %8);//da los espacios
			cod>>>=1;
		}//for
		System.out.println();
	}//binario

	public static void main(String[] args) {		
	 	Conversor c = new Conversor();//constructor
	 	System.out.println("Pasando el valor int 1: ");
	 	System.out.println();
	 	c.binario((byte)1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2: ");
	 	System.out.println();
	 	c.binario((byte)2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 128: ");
	 	System.out.println();
	 	c.binario((byte)128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 256: ");
	 	System.out.println();
	 	c.binario((byte)256);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 1024: ");
	 	System.out.println();
	 	c.binario((byte)1024);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2147483647: ");
	 	System.out.println();
	 	c.binario((byte)2147483647);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -1: ");
	 	System.out.println();
	 	c.binario((byte)-1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2: ");
	 	System.out.println();
	 	c.binario((byte)-2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -127: ");
	 	System.out.println();
	 	c.binario((byte)-127);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -128: ");
	 	System.out.println();
	 	c.binario((byte)-128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2147483648: ");
	 	System.out.println();
	 	c.binario((byte)-2147483648);
		System.out.println();
		System.out.println("Pasando el valor int 1: ");
	 	System.out.println();
	 	c.binario((short)1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2: ");
	 	System.out.println();
	 	c.binario((short)2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 128: ");
	 	System.out.println();
	 	c.binario((short)128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 256: ");
	 	System.out.println();
	 	c.binario((short)256);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 1024: ");
	 	System.out.println();
	 	c.binario((short)1024);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2147483647: ");
	 	System.out.println();
	 	c.binario((short)2147483647);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -1: ");
	 	System.out.println();
	 	c.binario((short)-1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2: ");
	 	System.out.println();
	 	c.binario((short)-2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -127: ");
	 	System.out.println();
	 	c.binario((short)-127);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -128: ");
	 	System.out.println();
	 	c.binario((short)-128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2147483648: ");
	 	System.out.println();
	 	c.binario((short)-2147483648);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 1: ");
	 	System.out.println();
	 	c.binario((int)1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2: ");
	 	System.out.println();
	 	c.binario((int)2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 128: ");
	 	System.out.println();
	 	c.binario((int)128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 256: ");
	 	System.out.println();
	 	c.binario((int)256);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 1024: ");
	 	System.out.println();
	 	c.binario((int)1024);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2147483647: ");
	 	System.out.println();
	 	c.binario((int)2147483647);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -1: ");
	 	System.out.println();
	 	c.binario((int)-1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2: ");
	 	System.out.println();
	 	c.binario((int)-2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -127: ");
	 	System.out.println();
	 	c.binario((int)-127);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -128: ");
	 	System.out.println();
	 	c.binario((int)-128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2147483648: ");
	 	System.out.println();
	 	c.binario((int)-2147483648);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 1: ");
	 	System.out.println();
	 	c.binario((long)1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2: ");
	 	System.out.println();
	 	c.binario((long)2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 128: ");
	 	System.out.println();
	 	c.binario((long)128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 256: ");
	 	System.out.println();
	 	c.binario((long)256);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 1024: ");
	 	System.out.println();
	 	c.binario((long)1024);
	 	System.out.println();
	 	System.out.println("Pasando el valor int 2147483647: ");
	 	System.out.println();
	 	c.binario((long)2147483647);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -1: ");
	 	System.out.println();
	 	c.binario((long)-1);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2: ");
	 	System.out.println();
	 	c.binario((long)-2);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -127: ");
	 	System.out.println();
	 	c.binario((long)-127);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -128: ");
	 	System.out.println();
	 	c.binario((long)-128);
	 	System.out.println();
	 	System.out.println("Pasando el valor int -2147483648: ");
	 	System.out.println();
	 	c.binario((long)-2147483648);
	}//main
}//clase Conversor