import string
import sys
#Importamos la tablaLR desde otro archivo
from TablaLR import TablaLR
#Importamos la tabla de reglas
from Reglas import Reglas
#Cadena de entrada
cadena = "int main(){int a;}"
#Agregamos el final de linea
cadena = cadena + "$"
#Variables globales
posicion = 0
posicion2 = 0
c = ""
c2 = ""
estado = -1
bandera  = 0
acum = 0
#Conjunto de caracteres permitidos
OPADI = ['+','-']
OPMULT = ['*','/']
OPREL = ['<','>','=','!']
OPASI = ['=']
OPCOM = ['&','|']
PAR = ['(',')']
LLA = ['{','}']
NUM = ['0','1','2','3','4','5','6','7','8','9']
ESP = " "
PUN = [";"]
END = "$"
#Retorno del analisador lexico
IDENTIFICADOR = 0
ENTERO =1
REAL = 2
CADENA = 3
TIPO = 4
OPSUMA = 5
OPMUL = 6
OPRELAC = 7
OPOR = 8
OPAND = 9
OPNOT = 10
OPIGUALDAD = 11
PUNTOYCOMA = 12
COMA = 13
PARA = 14
PARC = 15
LLAVEA = 16
LLAVEC = 17
IGUAL = 18
IF = 19
WHILE = 20
RETURN = 21
ELSE = 22
FIN = 23
#Equivalencia de las reglas(columnas) en la tabla LR
PROGRAMA = 24
DEFINICIONES = 25
DEFINICION = 26
DEFVAR = 27
LISTAVAR = 28
DEFFUNC = 29
PARAMETROS = 30
LISTAPARAM = 31
BLOQFUNC = 32
DEFLOCALES = 33
DEFLOCAL = 34
SENTENCIAS = 35
SENTENCIA = 36
OTRO = 37
BLOQUE = 38
VALORREGRESA = 39
ARGUMENTOS = 40
LISTAARGUMENTOS = 41
TERMINO = 42
LLAMADAFUNC = 43
SENTENCIABLOQUE = 44
EXPRESION = 45
E = 101
ESPACIO = 102
ERROR = 100
#Valor que regresa el analizador lexico
token = 0
#Linea actual del compilador
linea = 0
#Definimos nuestra clase ARBOL
class ARBOL:
        padre = -1
        hijos = []
        def __init__(self, numero, nombre, entero):
                self.numero = numero
                self.nombre = nombre
                self.entero = entero
        def inprimir(self):
                print "numero de nodo: ",self.numero
                print "nombre del nodo: ",self.nombre
                #print self.entero
                print "nodo padre: ",self.padre
                print "lista de hijos: ",self.hijos
                print ""
#Funcion que genera el nodo n-esimo
def Generar_Nodo(numero, entero, nombre):
        global lista_nodos
        if nombre == END:
                return 0
        lista_nodos.append(ARBOL(numero, nombre, entero))
#Funcion para mostrar nuestro arbol en pantalla
nivel = 0
def Mostrar_Arbol(nodo):
        visitados = []
        global lista_nodos
        global nivel
        y = nivel
        while y > 0:
                y -=1
                print "|\t",
        nodoaux = lista_nodos[nodo]
        print "(",nodoaux.numero,")",
        print "Nodo: ",nodoaux.nombre,
        print "apunta a: ",nodoaux.hijos
        #Tiene hijos
        if nodoaux.hijos:
                visitados = nodoaux.hijos
                y = 0
                while y < len(visitados):
                        x = visitados[0]
                        del visitados[0]
                        auxi = nivel
                        #Bajamos un nivel en cada iteracion
                        nivel += 1
                        Mostrar_Arbol(x)
                        #Regresamos al nivel previo al terminar
                        nivel = auxi
        #No tiene hijos
        else:
                nivel -= 1
                return 0
#Lista donde almacenamos los objetos como nodos de un arbol
hijos = []
lista_nodos = []
#Funcion para generar el nodo de la clase arbol, annadir objeto al diccionario y pila_Objeto
def Annadir_Objeto(diccionario, identificador, entero):
        global numero
        print "numero de nodo: ", numero
        print "Identificador: ",identificador
        diccionario[numero] = identificador
        Generar_Nodo(numero, entero, identificador)
        Pila_Objetos.append(numero)
        print "Pila_Objetos: ", Pila_Objetos
        numero += 1
#Funcion para annadir padre a una lista de nodos hijos y annadir una lista de nodos hijos a un padre
def Annadir_Padre(lista, padre):
        global lista_nodos
        for x in lista:
                lista_nodos[x].padre = padre
        lista_nodos[padre].hijos = lista
#Funcion para optener el caracter siguiente en la cadena de entrada
def Caracter_Sig(cadena,posicionP):
        c2 = cadena[posicionP]
        posicionP += 1
        return c2 , posicionP
#Funcion para evaluar los caracteres leidos, Analizador Lexico
def Evaluar_Caracter_L(cadena,car,posicionP):
        tipo = 0
        global c
        global posicion
        global bandera
        global estado
        global linea
        #Evaluar los numero enteros
        if car in NUM:
                estado = 1
                #print estado
                while estado == 1:
                        #print "vuelta"
                        c2, posicion2 = Caracter_Sig(cadena,posicion)
                        if c2 in NUM:
                                car = car + c2
                                posicion = posicion2
                                continue
                        elif c2 == ".":
                                car = car + c2
                                c = car 
                                posicion = posicion2
                                #print car
                                #print posicion
                                estado = 2
                        else: 
                                c = car 
                                posicion = posicion2 - 1
                                print "Numero Entero ",
                                tipo = ENTERO
                                estado = 0
                #Evaluar los numeros flotantes
                while estado == 2:    
                        #print estado
                        c2, posicion2 = Caracter_Sig(cadena, posicion)
                        if c2 in NUM:
                                car = car + c2
                                c = car
                                bandera = 1
                                posicion = posicion2
                                #print car
                                #print posicion
                                continue
                        elif c2 == "$":
                                if  bandera == 1:
                                        print "Numero Flotante ",
                                        tipo = REAL
                                        c = car 
                                        #print c
                                        posicion = posicion2
                                        estado = 0
                                print "FIN"
                                break
                                
                        elif bandera == 1:
                                print "Numero Flotante ",
                                tipo = REAL
                                c = car 
                                posicion = posicion2 - 1
                                estado = 0
                        elif bandera == 0:
                                print "ERROR" 
                                tipo = ERROR
        #Evaluar los aperadores de adicion + -
        elif c in OPADI:
                print "Operador de adicion ",
                tipo = OPSUMA
        #Evaluar los operadores de multiplicacion * /
        elif c in OPMULT:
                print "Operador de multiplicacion ",
                tipo = OPMUL
        #Evaluar los operadores relacionales, NOT y Equivalencia == >= <= < > ! =
        elif c in OPREL:
                #print estado
                c2, posicion2 = Caracter_Sig(cadena,posicion)
                aux = cadena[posicion - 1:posicion + 3]
                if  c == "=":
                        if aux == "== ":
                                print "Operador igualdad ",
                                c = c + c2
                                posicion = posicion2
                                tipo = OPIGUALDAD
                                estado = 0
                        elif c2 == " ":
                                #Operador De Equivalencia
                                print "Equivalencia ",
                                tipo = IGUAL
                                estado = 0
                        else:
                                print "ERROR"
                                tipo = ERROR
                elif c == "!":
                        if aux == "!= " :
                                print "Operador relacional ",
                                c = c + c2
                                posicion = posicion2
                                tipo = OPRELAC
                                estado = 0
                        elif c2 == " ":
                                #Operador NOT
                                print "NOT ",
                                tipo = OPNOT
                        else:
                                print "ERROR"
                                tipo = ERROR
                elif c == "<" or c == ">":
                        if aux =="<= " or aux == ">= ":
                                print "Operador relacional ",
                                c = c + c2
                                posicion = posicion2
                                tipo = OPRELAC
                                estado = 0
                        elif c2 == " ":
                                print "Operador relacional ",
                                tipo = OPRELAC
                                estado = 0
                        else:
                                print "ERROR"
                                estado = 0 
                                tipo = ERROR
        #Evaluar los operadores de comparacion &&  ||
        elif c in OPCOM:
                aux = cadena[posicion - 1:posicion + 3]
                c2, posicion2 = Caracter_Sig(cadena,posicion)
                if aux == "&& ":
                        print "AND ",
                        tipo = OPAND
                        c = c + c2
                        posicion = posicion2
                        estado = 0
                elif c == "|| ":
                        c = c + c2
                        posicion = posicion2
                        estado = 0
                        print "OR ",
                        tipo = OPOR
                else:
                        print "ERROR"
                        tipo = ERROR
        #Evaluamos los parentesis
        elif c == "(":
                print "Parentesis Abierto",
                tipo = PARA
        elif c == ")":
                print "Parentesis Cerrado",
                tipo = PARC
        #Evaluamos las llaves
        elif c == "{":
                print "Llave Abierta",
                tipo = LLAVEA
        elif c == "}":
                print "Llave Cerrada",
                tipo = LLAVEC
        #Evaluamos el salto de linea
        elif c == "\n":
                print "Salto de linea ",
                linea = linea + 1
        elif c == ESP:
        #Evaluamos el espacio
                print "Espacio "
                print ""
                tipo = ESPACIO
        #Evaluamos fin de cadena
        elif c == "$":
                print "FIN ",
                tipo = FIN
        #Evaluamos punto y coma
        elif c == ";":
                tipo = PUNTOYCOMA
        #Evaluamos coma
        elif c == ",":
                print "Coma ",
                tipo = COMA
        #Evaluamos Identificadores y palabras reservadas
        elif c in string.ascii_uppercase or c in string.ascii_lowercase:
                if c == "i":
                        c2, posicion2 = Caracter_Sig(cadena,posicion)
                        if c2 == "f":
                                c = c + c2
                                posicion = posicion2
                                c2, posicion2 = Caracter_Sig(cadena,posicion)
                                if c2 == " ":
                                        print "IF ",
                                        tipo = IF
                                        estado = 0
                                else: 
                                        estado = 5
                        elif c2 == "n":
                                c = c + c2
                                posicion = posicion2
                                c2, posicion2 = Caracter_Sig(cadena,posicion)
                                if c2 == "t":
                                        c = c + c2
                                        posicion = posicion2
                                        c2, posicion2 = Caracter_Sig(cadena,posicion)
                                        if c2 == " ":
                                                print "TIPO ",
                                                #print c
                                                #print  ""
                                                #print c2
                                                tipo = TIPO
                                                estado = 0

                                        else: estado = 5
                                else:
                                        estado = 5
                        else: estado = 5
                elif c == "f":
                        aux = cadena[posicion - 1:posicion + 5]
                        if aux == "float ":
                                c = aux
                                posicion = posicion + 4
                                estado = 0
                                print "TIPO ",
                                tipo = TIPO

                        else: estado = 5
                elif c == "e":
                        aux = cadena[posicion - 1:posicion + 4]
                        if aux == "else ":
                                c = aux
                                posicion = posicion + 3
                                tipo = ELSE
                                estado = 0
                                print "ELSE ", 
                        else: estado = 5
                elif c == "r":
                        aux = cadena[posicion - 1:posicion + 6]
                        if aux == "return ":
                                c = aux
                                posicion = posicion + 5
                                tipo = RETURN
                                estado = 0
                                print "RETURN ",
                        else: estado = 5
                elif c == "w":
                        aux = cadena[posicion - 1:posicion + 5]
                        if aux == "while ":
                                c = aux
                                posicion = posicion + 4
                                estado = 0
                                print "WHILE ",
                                tipo = WHILE
                        else: estado = 5
                else:
                        estado = 5
                        #print "Identificador ",
                        tipo = 0
                while estado == 5:
                        c2, posicion2 = Caracter_Sig(cadena,posicion)
                        if c2 in string.ascii_uppercase or c2 in string.ascii_lowercase or c2 in NUM:
                                c = c + c2
                                posicion = posicion2
                                estado = 5
                        else:
                                estado = 0
                                print "Identificador ",
                                tipo = 0
        #Estado de error para todo caracter no valido
        else:
                print "ERROR"
                tipo = ERROR
        return tipo
#_____________________________________________________________________________
#Funcion para validar, Analizador Sintantico    
def Evaluar_Tipo_S(tipo_S):
        global fila
        global columna
        global accion
        global Pila_Enteros
        global TablaLR
        global c
        global Pila_Objetos
        global ARBOL
        global numero

        print "Simbolo: ",c
        fila = Pila_Enteros[len(Pila_Enteros) - 1]
        print "Fila ",fila
        columna = tipo_S
        print "Columna ",columna
        accion = TablaLR[fila][columna]

        if accion == 0:
                print "Error Semantico"
                sys.exit()
        print "Entrada ",columna
        print "Accion ",accion
        regla_Numero = accion * (- 1)
        if accion < -1:
                print""
                accion = accion + 1
                #print accion
                print"REGLA POR VALIDAR"
                print "Pila actual ",Pila_Enteros
                Comparar_Regla(regla_Numero)
                print "PUSH ",Pila_Enteros
                Evaluar_Tipo_S(tipo_S)
        elif accion == -1:
                Annadir_Objeto(diccionario, c, columna)
                Pila_Enteros.append(columna)
                Pila_Enteros.append(accion)
                print ""
                print "ACEPTADO"
                print "PILA FINAL",Pila_Enteros
        else:
                Pila_Enteros.append(columna)
                Pila_Enteros.append(accion)
                print "PUSH ",Pila_Enteros
                Annadir_Objeto(diccionario, c, columna)
                
#Funcion para validar la regla
def Validar_Regla_S():
        global fila
        global columna
        global accion
        global Pila_Enteros
        global TablaLR

        fila = Pila_Enteros[len(Pila_Enteros) - 1]
        columna = FIN
        accion = TablaLR[fila][columna]
        print "Fila ",fila
        print "entrada ",
        print columna
        print "Accion ",
        print accion
        if (accion == -1):
                print "ACEPTADO"  
                print "Pila Final ",Pila_Enteros
                sys.exit()
#Encontrar los datos de la regla
def Comparar_Regla(regla_Numero):
        global Reglas
        print "Regla numero: ",regla_Numero - 1
        auxN = Reglas[3][regla_Numero - 1]
        #Simbolo por el cual sustituir
        auxS = Reglas[2][regla_Numero - 1]
        #Cantidad de reducciones a realizar
        auxR = Reglas[1][regla_Numero - 1]
        #Accion
        #auxA = reglaLR[3][regla_Numero - 1]
        print "Numero Columna LR", auxN
        print "Simbolo ", auxS
        print"Reduccion ",auxR
        Reducir(auxS, auxR, auxN)
#Reducir pila de acuerdo a la regla
def Reducir(auxS, auxR, auxN):
        print"\nREDUCCION"
        global Pila_Enteros
        global Pila_Objetos
        global ARBOL
        global diccionario
        global numero
        lista_hijos = []
        auxR *= 2
        while auxR > 0:
                auxR -= 1
                if (auxR % 2) == 0 and Pila_Objetos:
                        lista_hijos.insert(0,Pila_Objetos.pop())
                Pila_Enteros.pop()
  
        print "Pila Reducida: ",Pila_Enteros,"\n"
        print"Comparamos tope con E para obtener accion y los metemos"
        fila = Pila_Enteros[len(Pila_Enteros) - 1] #* (-1)
        print "Fila ",fila
        columna2 = auxN
        print "Columna ",columna2
        accion2 = TablaLR[fila][columna2]
        print "Accion: ", accion2

        Pila_Enteros.append(auxS)
        Pila_Enteros.append(accion2)
        Annadir_Objeto(diccionario, auxS, columna)
        print "Lista de hijos: ",lista_hijos
        auxN = lista_nodos[len(lista_nodos) - 1].numero
        print "Padre: ",auxN
        Annadir_Padre(lista_hijos, auxN) 
#_____________________________________________________________________________
#Declaramos la pila de enteros y sus datos correspondientes
Pila_Enteros = []
fila = 0
columna = 0
accion = 0
aceptacion = False
#_____________________________________________________________________________
#Datos inicializados
Pila_Objetos = []
numero = 0
diccionario = {}
#Inicializar la pila de enteros vacias
Pila_Enteros.append("$")
Pila_Enteros.append(0)
#Annadir_Objeto(diccionario, '$', 23)
print "Diccionario inicial: ", diccionario
print "Pila de objetos inicial: ", Pila_Objetos
#Obtenemos longitud de nuestra cadena de entrada
longitud = len(cadena)
#Mostramos la pila iniciada
print "Pila Inicial: ",Pila_Enteros
print ""
#Bucle para leer y evaluar caracter por caracter
while posicion < longitud:
        #Se obtiene el caracter
        c, posicion =Caracter_Sig(cadena, posicion)
        #Se obtiene el tipo de token
        token = Evaluar_Caracter_L(cadena,c,posicion)
        #Comprobamos error lexico
        if token == ERROR:
                print "El codigo tiene errores lexicos, revisa la linea: ",linea
                sys.exit()
        #Ignoramos los espacios
        elif token == ESPACIO:
                continue
        print c
        
        #Evaluamos sintacticamente haciendo uso de la pila de enteros
        Evaluar_Tipo_S(token)
        print "Diccionario de objetos: ",diccionario
        print "Pila de objetos: ",Pila_Objetos
        print " "
#Validar_Regla_S()
#print arbol
#print ARBOL.__dict__.keys()
#print lista_nodos
x = 0
#Mostramos la lista de los nodos
"""for x in range(len(lista_nodos)):
        lista_nodos[x].inprimir()"""
numero -= 2
#Imprimimos nuestro arbol IDR: Izquierda,Derecha,Raiz
print "Arbol Sintactico Generado."
Mostrar_Arbol(numero)
