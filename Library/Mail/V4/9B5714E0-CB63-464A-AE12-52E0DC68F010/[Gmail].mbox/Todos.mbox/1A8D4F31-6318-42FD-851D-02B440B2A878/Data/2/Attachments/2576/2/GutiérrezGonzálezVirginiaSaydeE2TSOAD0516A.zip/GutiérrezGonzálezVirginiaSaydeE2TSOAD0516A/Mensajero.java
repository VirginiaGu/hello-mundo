package examen;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.*;
import javax.swing.*;

public class Mensajero{
	private Ventana ventana;
	private static final int PORT = 8081;
	
	public Mensajero(){
		ventana = new Ventana(PORT);  
	}
	
class Ventana extends JFrame implements ActionListener{
	private static final int WIDTH_TEXT_AREA = 20, HEIGHT_TEXT_AREA = 15;
	private JTextField t1, t2;
	private JTextArea a;
	private JButton b;
	private JPanel p;
	private Recive r;
	private Transmite t;

	public Ventana(int port){
		super("Eddie Vedder");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		r = new Recive(this, port);
		new Thread(r,"receptor").start();
		t = new Transmite(port);
		setLayout(new BorderLayout());
		t1 = new JTextField();
		p = new JPanel();
		p.add(new JLabel("IP"));
		t1 = new JTextField(17);
		p.add(t1);
	    a = new JTextArea(WIDTH_TEXT_AREA, HEIGHT_TEXT_AREA);
		a.setEditable(false);
		t2 = new JTextField(20);
		b = new JButton("SEND");
		b.addActionListener(this);
		add(p, BorderLayout.NORTH);
		add(new JScrollPane(a,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
		p = new JPanel();
		p.add(new JLabel("Mensaje"));
		p.add(t2);
		p.add(b);
		add(p, BorderLayout.SOUTH);
		pack();
	}
	
	public void mostrar(String m){
		a.setText(a.getText()+m+"\n");
	}

	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==b){
			String ip = t1.getText();
			String mensaje = t2.getText();
			t.mandar(ip, mensaje);
			t2.setText("");
		}
	}
}

class Recive implements Runnable{	
	private Ventana parent;
	private DatagramSocket socket;
	private DatagramPacket dp;
	private byte[] buffer;
	private static final int  SIZE = 1024;
	
	public Recive(Ventana parent, int port){
		buffer = new byte[SIZE];
		this.parent = parent;
		dp=new DatagramPacket(buffer,buffer.length);
		try {
			socket=new DatagramSocket(port);
		}
		catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public void espera(){
		while(true){
			try{
				socket.receive(dp);
				parent.mostrar(formato(dp));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void run() {
		espera();
	}
	
	private String formato(DatagramPacket incoming){
		String formattedString = ""; 
		formattedString+="IP: "+incoming.getAddress().getHostAddress()+": "+
						 new String(incoming.getData(),0,incoming.getLength());		
		return formattedString;
	}	
}

class Transmite{	
	private DatagramSocket socket;
	private int port;
	
	public Transmite(int port){
		this.port = port;
		try {
			socket = new DatagramSocket();
		}
		catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public void mandar(String ip, String messageToSend){
		byte [] mensaje = messageToSend.getBytes();
		DatagramPacket packet;
		try {
			packet = new DatagramPacket(mensaje, mensaje.length, InetAddress.getByName(ip), port);
			socket.send(packet);
		}
		catch (UnknownHostException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
	}	
}
    public Ventana gVentana(){
	return ventana;
}

		public static void main(String[] args) {	
			Mensajero men = new Mensajero();
			men.gVentana().setVisible(true);
	}
}






