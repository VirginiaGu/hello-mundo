import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;

public class HiloServidor extends Thread {
	
	private JTextArea textArea = new JTextArea();
	private int ip;
	
	public HiloServidor(int ip, String id){
		textArea.setEditable(false);
		DefaultCaret caret_creados = (DefaultCaret)textArea.getCaret();
		caret_creados.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		textArea.append("Inicio de proceso\n");
		textArea.append("Tipo: Servidor\n");
		textArea.append("ID: "+id+"\n");
		textArea.append("�������������������������������������\n");
		this.ip=ip;
	}
	
	public void run(){
		while(true){
			byte[] datagramaRecibir = new byte[1024];
			byte[] datagramaEnviar = new byte[1024];
			DatagramSocket serverSocket = null;
			
			try{
				serverSocket = new DatagramSocket(ip);
				DatagramPacket paqueteRecibido = new DatagramPacket(datagramaRecibir, datagramaRecibir.length);
				serverSocket.receive(paqueteRecibido);
				InetAddress IPAddress = paqueteRecibido.getAddress();                   
				int port = paqueteRecibido.getPort();
				String stringRecibido = new String(paqueteRecibido.getData());
				String[] client = stringRecibido.split("~");
				textArea.append("Solicitud Recibida de: "+client[0]+"\n");
				textArea.append("Operaci�n solicitada: "+operacion(client[1])+"\n");
				textArea.append("Primer operador: "+client[2]+"\n");
				textArea.append("Segundo operador: "+client[3]+"\n");
				String res = resultado(client[1], client[2], client[3]);
				textArea.append("Respuesta a enviar: :"+res+"\n");
				textArea.append("Invocando a send\n");
				textArea.append("�������������������������������������\n");
				StringBuilder sb = new StringBuilder();
				sb.append("Invocando a receive");
				sb.append("~");
				sb.append("Resultado: "+res);
				datagramaEnviar=sb.toString().getBytes();
				DatagramPacket sendPacket = new DatagramPacket(datagramaEnviar, datagramaEnviar.length, IPAddress, port);
				serverSocket.send(sendPacket);
			}catch(IOException e1) {
				e1.printStackTrace();
			}
			serverSocket.close();
		}
	}
	
	private String resultado(String op, String opr1, String opr2){
		
		double d1=0;
		double d2=0;
		
		if(!opr1.startsWith("--")){
			d1 = Double.parseDouble(opr1);
			d2 = Double.parseDouble(opr2);
		}
		
		switch(op){
		case "SMR":
			return Double.toString(d1+d2);
		case "RST":
			return Double.toString(d1-d2);
		case "MLT":
			return Double.toString(d1*d2);
		case "DVR":
			return Double.toString(d1/d2);
		case "TXT":
			return "\n"+fileToString(opr2.trim());
		}
		return "---";
	}
	
	private String operacion(String op){
		switch(op){
		case "SMR":
			return "Suma";
		case "RST":
			return "Resta";
		case "MLT":
			return "M�dulo";
		case "DVR":
			return "Division";
		case "TXT":
			return "Abri un archivo de texto";
		}
		return "---";
	}
	
	private String fileToString(String archivo){
		if(archivo == null)
			return "";
		StringBuilder acumulador = new StringBuilder();
		File f=new File(archivo);
		try {
			Scanner s = new Scanner(f);
			while(s.hasNextLine())
				acumulador.append(s.nextLine()+"\n");
			s.close();
		}catch (FileNotFoundException e) {
			return "No se pudo abrir el archivo D:";
		}
		return acumulador.toString();
	}
	
	public JTextArea getArea(){
		return this.textArea;
	}
}
