//*Nombre: Virginia Sayde Guti�rrez Gonz�lez
//Secci�n: D01
//Tarea #7: Arreglos de caracteres

public class Arreglos {
	String cadena="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static int MAX_TAM = 77;
	private Boolean cambio[];	
	
	public char aleatorio(){
		int letra=(int)(Math.random()*cadena.length());
		return cadena.charAt(letra);
	}//aleatorio
	
	public String llenado(int t){
		String cad="";
		for(int i=0; i<=t; i++){
			cad=cad+aleatorio();
		}//for
		return cad;
	}//llenado
	
	public void imprimir(char c[], Boolean cambio[], Boolean com){
		for(int i=0; i<cambio.length; i++){
			if(cambio[i] || com){
				System.out.print(c[i]);
			}//if
		}//for
		System.out.println();
	}//imprimir
	
	private Boolean []nc(char original[], char cadena[]){
		int length =cadena.length;
		int a = MAX_TAM/length;
		cambio = new Boolean[length * a];
		for(int i=0, j=0; i<a*length; i++, j=(j+1)%length){
			cambio[i]=(original[i]==cadena[j])?false:true;
			if(cambio[i])
				original[i] =cadena[j];
		}//for
		return cambio;
	}//nc
	
	public static void main(String[] args){
		char original[];
		Boolean []cambios;
		String toCopy="PINKFLOYD";
		Arreglos a= new Arreglos();
		original= new char[Arreglos.MAX_TAM];
		original= a.llenado(Arreglos.MAX_TAM).toCharArray();
		System.out.println(original);
		cambios = a.nc(original,toCopy.toUpperCase().toCharArray());
		a.imprimir(original, cambios, true);
		a.imprimir(original, cambios, false);				
	}//main
}//clase arreglo
