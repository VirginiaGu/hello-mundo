//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 1
//Operaciones:
//Para CREAR el archivo solo es necesario ingresar el nombre del archivo seguido de la extension que puede ser .txt o .doc si se ingresa otra extension marcara error. 
//Ej: Tsoa.txt o Tsoa.doc
//Para la opcion de ESCRIBIR se ingresa el titulo del archivo se da un espacio despues una / espacio y enseguida el texto que se desea escribir. 
//Ej: Tsoa.txt / Daniela Padron
//Para LEER solo ingresamos el nombre del archivo.
//Ej: Tsoa.txt
//Para ELIMINAR solo ingresamos el nombre del archivo.
//Ej: Tsoa.txt
 
package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import java.awt.Choice;
import java.awt.TextField;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 */
public class ProcesoCliente extends Proceso{

	/**
	 * 
	 */
	private Choice opc;
	private TextField cMsj;
	public ProcesoCliente(Escribano esc, Choice x, TextField y){
		super(esc);
		opc=x;
		cMsj=y;
		start();
	}

	/**
	 * 
	 */
	public void run(){
		int opera1=0,j=11;
		String msj_2;
		byte[] solCliente=new byte[1024];
		byte[] respCliente=new byte[1024];
		byte[] opera2=new byte [4];
		imprimeln(" Proceso cliente en ejecucion.");
		imprimeln(" Esperando datos para continuar.");
		msj_2="";
		Nucleo.suspenderProceso();
		opera1=opc.getSelectedIndex();
		Empaqueta(opera1,opera2);
		for(int i=0;i<8;i++)
			solCliente[i]=(byte)10;
		solCliente[8]=opera2[0];
		solCliente[9]=opera2[1];
		msj_2=cMsj.getText();
		solCliente[10]=(byte) msj_2.length();
		imprimeln("Esperando datos para continuar");
		for(int i=0;i<msj_2.length();i++){
			solCliente[j]=(byte)(msj_2.charAt(i));
			j++;
		}
		imprimeln("\nEl mensaje se esta enviando...");
		Nucleo.send(248,solCliente);
		imprimeln("\nLlamando a receive...");
		Nucleo.receive(dameID(),respCliente);
		imprimeln(" Procesando respuesta del servidor");
		if(respCliente[9]==-101)
			imprimeln("AU: Address Unknown");
		else{
			msj_2=" ";
			for (int i=11;i<respCliente.length;i++)
				msj_2+=(char)respCliente[i];
			imprimeln("\n El servidor a enviado el msj: "+msj_2);	
		}
		}
	
	void Empaqueta(int num,byte[] paq){
		for(int i=0;i<4;i++){
			paq[i]=(byte)(num);
			num=num>>>8;
		}
	}
}
