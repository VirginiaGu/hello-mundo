/*Sofía Silva Villalobos
  Sección: D01
  Práctica #3
*/

package clienteservidor;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Nucleo extends JFrame implements Runnable, ActionListener{
    JLabel lblEventos=new JLabel("Eventos:");
    JLabel lblIp=new JLabel("IP:");
    JLabel lblId=new JLabel("ID:");
    JTextField txtIp=new JTextField("140.0.0.1");
    JTextField txtId=new JTextField();
    JTextArea txtEventos=new JTextArea();
    JButton cmdClientes=new JButton("CLIENTE");
    JButton cmdServidores=new JButton("SERVIDOR");
    JButton cmdEliminar=new JButton("ELIMINAR");
    JButton cmdFinalizar=new JButton("FINALIZAR");
    JScrollPane scrollPane= new JScrollPane();
    
    int id=1,totalClientes=0,totalServidores=0,emisor,receptor,existe;
    boolean llegoMensaje;
    Thread hilo;
    ByteArrayOutputStream buffer=new ByteArrayOutputStream();
    
    Hashtable<String,Thread> TablaHilos=new Hashtable<String,Thread>(); 
    Hashtable<String,String> TablaMaquinas=new Hashtable<String,String>();
    Hashtable<String,Procesos> TablaProcesos=new Hashtable<String,Procesos>();
    Hashtable<String,ResguardoCliente> TablaResguardosClientes=new Hashtable<String,ResguardoCliente>();
    Hashtable<String,ResguardoServidor> TablaResguardosServidores=new Hashtable<String,ResguardoServidor>();
    Hashtable<String,Procesos> TablaServidores=new Hashtable<String,Procesos>();
    Vector<Procesos> ServidoresDisponibles=new Vector<Procesos>();
    Hashtable<String,byte[]> Peticiones=new Hashtable<String,byte[]>();
    
    public Nucleo(){
        super("NUCLEO");
        this.setLayout(null);
        
        this.setBounds(0,0,600,500);
        lblIp.setBounds(425,375,50,25);
        lblId.setBounds(425,415,50,25);
        lblEventos.setBounds(510,25,50,25);
        txtIp.setBounds(450,375,100,25);
        txtId.setBounds(450,415,100,25);
        cmdClientes.setBounds(25,50,100,50);
        cmdServidores.setBounds(25,125,100,50);
        cmdEliminar.setBounds(25,200,100,50);
        cmdFinalizar.setBounds(25,400,100,50);
	scrollPane.setBounds(160,50,400,300);
	scrollPane.setViewportView(txtEventos);
        
        this.add(lblIp);
        this.add(lblId);
        this.add(lblEventos);
        this.add(txtIp);
        this.add(txtId);
        this.add(cmdClientes);
        this.add(cmdServidores);
        this.add(cmdEliminar);
        this.add(cmdFinalizar);
        this.add(scrollPane);
        
        txtEventos.setEditable(false);
        
        txtId.addActionListener(this);
        cmdClientes.addActionListener(this);
        cmdServidores.addActionListener(this);
        cmdEliminar.addActionListener(this);
        cmdFinalizar.addActionListener(this);
        
        this.setVisible(true);
        
        txtId.setText(Integer.toString(id));   
        llegoMensaje=false;
    }
    
    public void run() {
        while(true){
            try {
                ActualizarRegistros();
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Nucleo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void ActualizarRegistros(){
        totalClientes=0;
        totalServidores=0;
        if(!TablaProcesos.isEmpty()){
            Enumeration<String> llaves = TablaProcesos.keys();
            String llaveActual;
			
            while (llaves.hasMoreElements()) {				
		llaveActual=llaves.nextElement();
		if(!TablaProcesos.get(llaveActual).isVisible()){  
                    
                    try {
                        hilo=TablaHilos.get(llaveActual);
                        synchronized(hilo)
                        {
                            hilo.wait();
                            
                        }
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Nucleo.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    int tamanio=ServidoresDisponibles.size();
                    boolean esServidor=false;
                    
                    if(!ServidoresDisponibles.isEmpty()){
                        for(int i=0;i<tamanio;i++){
                           if(ServidoresDisponibles.get(i)==TablaProcesos.get(llaveActual))
                               esServidor=true;  
                        }
                    }
                    if(esServidor==true)
                        totalServidores++;
                    else
                        totalClientes++;
                }
            }	
        }
    }
    
    public void Send(int dest,byte[] messagePtr){
        txtEventos.append("Buscando en listas locales el par (máquina, proceso)\n");
        int encontro=0;
        if(!TablaMaquinas.isEmpty()){
            int finalizar=0;
            Enumeration<String> llaves=TablaMaquinas.keys();
            String llaveActual;
            while (llaves.hasMoreElements() && finalizar==0) {				
                llaveActual=llaves.nextElement();
                if(TablaMaquinas.get(llaveActual).equals(Integer.toString(receptor))){
                    finalizar=1;
                    encontro=1;
                    txtEventos.append(llaveActual+"\t"+TablaMaquinas.get(llaveActual)+"\n");
                }
            }
        }
        Dormir();
        if(encontro==0){
            txtEventos.append("Enviando mensaje de búsqueda del servidor\n");
            txtEventos.append("No se conoce el destino\n");
        }
        else{
            txtEventos.append("Enviando mensaje por la red\n");
            Dormir();
            Peticiones.put(Integer.toString(dest),messagePtr);
            int encontrado=0;
            if(TablaResguardosClientes.get(Integer.toString(dest))!=null){
                encontrado=1;
                TablaResguardosClientes.get(Integer.toString(dest)).recibir=true;
            }
            if(encontrado==0){
                TablaResguardosServidores.get(Integer.toString(dest)).recibir=true;
            }
        }
    }
    
    public void Receive(int addr,byte[] messagePtr){
        try {
            int encontrado=0;
            buffer.reset();
            buffer.write(Peticiones.get(Integer.toString(addr)));
            txtEventos.append("Copiando el mensaje hacia el espacio del proceso\n");
            Dormir();
            if(TablaResguardosClientes.get(Integer.toString(addr))!=null){
                encontrado=1;
                TablaResguardosClientes.get(Integer.toString(addr)).buffer=buffer;
            }
            if(encontrado==0){
                TablaResguardosServidores.get(Integer.toString(addr)).buffer=buffer;
            }
        } catch (IOException ex) {
            Logger.getLogger(Nucleo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void CompletarMensajeCliente(int idOrigen,byte[] mensaje){
        txtEventos.append("\n*************************INICIO DE PROCESO*************************\n");
        emisor=idOrigen;
        llegoMensaje=true;
        
        try {  
            Procesos procesoAux=TablaProcesos.get(Integer.toString(idOrigen));
            procesoAux.txtResguardo.append("Señalando al nucleo para envio de mensaje\n");
            Dormir();
            
            if(llegoMensaje==true){
                txtEventos.append("Recibido mensaje proveniente de la red\n");
                if(!TablaMaquinas.isEmpty()){
                    int finalizar=0;
                    Enumeration<String> llaves=TablaMaquinas.keys();
                    String llaveActual;
                    while (llaves.hasMoreElements() && finalizar==0) {				
                        llaveActual=llaves.nextElement();
                        if(TablaMaquinas.get(llaveActual).equals(Integer.toString(emisor))){
                            finalizar=1;
                            txtEventos.append("Emisor: "+llaveActual+"\t"+TablaMaquinas.get(llaveActual)+"\n");
                        }
                    }
                }           
                llegoMensaje=false;
            }
            
            txtEventos.append("Enviando mensaje de búsqueda del servidor\n");
            Dormir();
            int idDestino=ObtenerServidor();
            receptor=idDestino;
            
            if(existe==1){
                int tamanio=ServidoresDisponibles.size();
                boolean desocupado=false;
                    
                if(!ServidoresDisponibles.isEmpty()){
                    for(int i=0;i<tamanio;i++){
                        if(ServidoresDisponibles.get(i)==TablaServidores.get(Integer.toString(idDestino))){
                            desocupado=true;  
                            ServidoresDisponibles.remove(i);
                        }
                    }
                }
                txtEventos.append("Recibido mensaje que contiene la ubicación (máquina, proceso) del servidor\n");
                txtEventos.append("Completando campos de encabezado del mensaje a ser enviado\n");
                Dormir();
                buffer.reset();
                buffer.write(ConvertirBytes(idOrigen));
                buffer.write(ConvertirBytes(idDestino));
                buffer.write(mensaje);
                TablaResguardosClientes.get(Integer.toString(idOrigen)).llegoMensaje=true;
                
                if(desocupado==true){
                    Send(idDestino,buffer.toByteArray());
                }
                else{
                    TablaProcesos.get(Integer.toString(idOrigen)).txtEventos.append("Recibio TA("+idDestino+","+idOrigen+")\n");
                    txtEventos.append("***************************FIN DE PROCESO**************************\n");
                    TablaResguardosClientes.get(Integer.toString(idOrigen)).enviar=false;
                    TablaResguardosClientes.get(Integer.toString(idOrigen)).recibir=false;
                    TablaResguardosClientes.get(Integer.toString(idOrigen)).llegoMensaje=true;
                }     
            } 
            else{
                TablaResguardosClientes.get(Integer.toString(idOrigen)).enviar=false;
                TablaResguardosClientes.get(Integer.toString(idOrigen)).recibir=false;
                TablaResguardosClientes.get(Integer.toString(idOrigen)).llegoMensaje=true;
                txtEventos.append("***************************FIN DE PROCESO**************************\n");
            }
        } catch (IOException ex) {
            Logger.getLogger(Nucleo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void CompletarMensajeServidor(int idOrigen,int idDestino,byte[] mensaje){
        try {
            
            emisor=idOrigen;
            receptor=idDestino;
            llegoMensaje=true;
            
            if(llegoMensaje==true){
                txtEventos.append("\nRecibido mensaje proveniente de la red\n");
                if(!TablaMaquinas.isEmpty()){
                    int finalizar=0;
                    Enumeration<String> llaves=TablaMaquinas.keys();
                    String llaveActual;
                    while (llaves.hasMoreElements() && finalizar==0) {				
                        llaveActual=llaves.nextElement();
                        if(TablaMaquinas.get(llaveActual).equals(Integer.toString(emisor))){
                            finalizar=1;
                            txtEventos.append("Emisor: "+llaveActual+"\t"+TablaMaquinas.get(llaveActual)+"\n");
                        }
                    }
                }           
                llegoMensaje=false;
            }
            
            Procesos procesoAux=TablaProcesos.get(Integer.toString(idOrigen));
            procesoAux.txtResguardo.append("Señalando al nucleo para envio de mensaje\n");
            Dormir();
            
            txtEventos.append("Completando campos de encabezado del mensaje a ser enviado\n");
            Dormir();
            buffer.reset();
            buffer.write(ConvertirBytes(idOrigen));
            buffer.write(ConvertirBytes(idDestino));
            buffer.write(mensaje);
            
            TablaResguardosServidores.get(Integer.toString(idOrigen)).llegoMensaje=true;
            Send(idDestino,buffer.toByteArray());
            
            
            
            ServidoresDisponibles.add(procesoAux);
        } catch (IOException ex) {
            Logger.getLogger(Nucleo.class.getName()).log(Level.SEVERE, null, ex);
        }  
    }
    
    public int ObtenerServidor(){
        int numServidores=TablaServidores.size();
        int numAleatorio;
        if(numServidores!=0)
           numAleatorio=(int) (Math.random() * numServidores + 1);
        else
           numAleatorio=(int) (Math.random() * numServidores);
        
        int idServidor;
        String llaveActual="0";
        idServidor=Integer.parseInt(llaveActual);
        if(!TablaServidores.isEmpty()){
            Enumeration<String> llaves=TablaServidores.keys();
            for(int x=0;x<numAleatorio;x++){
                llaveActual=llaves.nextElement();
            }
            idServidor=Integer.parseInt(llaveActual);
        }
        if(TablaServidores.get(Integer.toString(idServidor))!=null){
            existe=1;
        }
        else{
            TablaProcesos.get(Integer.toString(emisor)).txtEventos.append("Recibio AU("+idServidor+","+emisor+")\n");
            existe=0;
        }
	return idServidor;
    }
    
    public byte[] ConvertirBytes(int numero){
        byte num=(byte)numero;
        byte[] convertido= new byte[2];
        convertido[0]=0;
        convertido[1]=num;
        return convertido;
    }
    
    public void BuscarProceso(){
        String procesoBuscado=txtId.getText();
        if(TablaProcesos.get(procesoBuscado)!=null)
            TablaProcesos.get(procesoBuscado).setVisible(true);
        
        if(!TablaHilos.isEmpty()){
            synchronized(hilo)
            { 
                hilo.notify();
            }
        }
        txtId.setText(Integer.toString(id));
    }
    
    public void actionPerformed(ActionEvent evt){
        Object presionado=evt.getSource();
        if(presionado==cmdClientes){
            if(totalClientes<16){
                int encontro=0;
                if(!TablaMaquinas.isEmpty()){
                    int finalizar=0;
                    Enumeration<String> llaves=TablaMaquinas.keys();
                    String llaveActual;
                    while (llaves.hasMoreElements() && finalizar==0) {				
                        llaveActual=llaves.nextElement();
                        if(llaveActual.equals(txtIp.getText())){
                            finalizar=1;
                            encontro=1;
                        }
                    }
                }
                if(encontro==0){
                    Procesos nuevoCliente=new Procesos(id,txtIp.getText(),this,1);
                    ResguardoCliente resguardo=new ResguardoCliente(nuevoCliente,this);
                    
                    Thread nuevoHiloCliente=new Thread(resguardo);
                
                    TablaProcesos.put(Integer.toString(id), nuevoCliente);
                    TablaHilos.put(Integer.toString(id),nuevoHiloCliente);
                    TablaResguardosClientes.put(Integer.toString(id),resguardo);
                    TablaMaquinas.put(txtIp.getText(),Integer.toString(id));
                    nuevoHiloCliente.start();
                
                    id++;
                    totalClientes++;
                    txtId.setText(Integer.toString(id));
                }
                else
                    JOptionPane.showMessageDialog(null, "Ip repetida","", JOptionPane.INFORMATION_MESSAGE);
            }
            else
                JOptionPane.showMessageDialog(null, "Se ha llegado al máximo de procesos cliente","", JOptionPane.INFORMATION_MESSAGE);
        }
        if(presionado==cmdServidores){
            if(totalServidores<16){
                int encontro=0;
                if(!TablaMaquinas.isEmpty()){
                    int finalizar=0;
                    Enumeration<String> llaves=TablaMaquinas.keys();
                    String llaveActual;
                    while (llaves.hasMoreElements() && finalizar==0) {				
                        llaveActual=llaves.nextElement();
                        if(llaveActual.equals(txtIp.getText())){
                            finalizar=1;
                            encontro=1;
                        }
                    }
                }
                if(encontro==0){
                    Procesos nuevoServidor=new Procesos(id,txtIp.getText(),this);
                    ResguardoServidor resguardo=new ResguardoServidor(nuevoServidor,this);
                    
                    Thread nuevoHiloServidor=new Thread(resguardo);
                
                    TablaProcesos.put(Integer.toString(id), nuevoServidor);
                    TablaServidores.put(Integer.toString(id),nuevoServidor);
                    TablaHilos.put(Integer.toString(id),nuevoHiloServidor);
                    TablaResguardosServidores.put(Integer.toString(id),resguardo);
                    TablaMaquinas.put(txtIp.getText(),Integer.toString(id));
                    ServidoresDisponibles.add(nuevoServidor);
                    nuevoHiloServidor.start();
                
                    id++;
                    totalServidores++;
                    txtId.setText(Integer.toString(id));
                }
                else
                    JOptionPane.showMessageDialog(null, "Ip repetida","", JOptionPane.INFORMATION_MESSAGE);
            }
            else
                JOptionPane.showMessageDialog(null, "Se ha llegado al máximo de procesos servidor","", JOptionPane.INFORMATION_MESSAGE);
        }
        if(presionado==cmdEliminar){
            Eliminar elimina=new Eliminar(TablaProcesos,ServidoresDisponibles,this);
            Thread hiloEliminar=new Thread(elimina);
            hiloEliminar.start();
        }
        if(presionado==cmdFinalizar){
            System.exit(0);
        }
        if(presionado==txtId){
            BuscarProceso();
        }
    }
    
    public void Dormir(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String args[]){
        Nucleo microNucleo=new Nucleo();
        Thread HiloNucleo= new Thread(microNucleo);
        HiloNucleo.run();
    }   
}
