import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ScrollPaneConstants;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class ServidorGUI extends JFrame {

	private JPanel contentPane;
	private int ip;
	private String id;
	private JTextArea textArea;
	private HiloServidor hilo;

	public ServidorGUI(String id, int ip) {
		this.id = id;
		this.ip=ip;
		hilo = new HiloServidor(this.ip, this.id);
		setTitle(id);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(550, 400, 554, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnOpciones = new JMenu("Opciones");
		menuBar.add(mnOpciones);
		
		JMenuItem mntmCerrar = new JMenuItem("Cerrar");
		mntmCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cerrar();
				dispose();
			}
		});
		mnOpciones.add(mntmCerrar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		scrollPane.setViewportView(hilo.getArea());
		
		JLabel lblNewLabel = new JLabel("Eventos");
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
		hilo.start();
	}
	
	private void cerrar(){
		CSControlSingleton clt = CSControlSingleton.getInstance();
		clt.servidorPush(this.id);
		clt.eliminarServidor(this.id);
	}
	
	public String getID(){
		return this.id;
	}
	
	public int getIP(){
		return this.ip;
	}
	
	public JTextArea getArea(){
		return this.textArea;
	}
}
