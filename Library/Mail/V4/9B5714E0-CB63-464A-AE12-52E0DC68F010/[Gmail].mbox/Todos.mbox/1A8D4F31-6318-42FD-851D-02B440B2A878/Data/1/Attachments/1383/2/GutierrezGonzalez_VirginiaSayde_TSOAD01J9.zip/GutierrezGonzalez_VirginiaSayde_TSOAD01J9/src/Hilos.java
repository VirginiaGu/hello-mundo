//*Nombre: Virginia Sayde Guti�rrez Gonz�lez
//*Secci�n: D01
//Tarea #9: Paso de mensajes en un hilo


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Hilos extends JTextArea implements Runnable{
	private static final int WIDTH_TEXT_AREA =50, HEIGHT_TEXT_AREA =30;
	private Ventana p;
	private String nombre;
	private int cont;
	private long tiempo;
	
	public Hilos(String nombre, long tiempo, Ventana p){
		super(HEIGHT_TEXT_AREA, WIDTH_TEXT_AREA);
		this.tiempo =tiempo;
		this.nombre=nombre;
		this.p=p;
		cont=0;
		new Thread(this,"HILO_1").start();
	}//Hilos
    
    public void run(){
    	while(true){
			try{
				Thread.sleep(tiempo);
				p.imprimir();
				cont=cont+1; 
				setText(getText()+nombre+":  "+cont+"\n");				
			}//try
			catch (InterruptedException e) {}
		}//while
    }//correr
    
    public static void main(String[]args){
    	Ventana v=new Ventana();
    	v.setVisible(true);
    	v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	v.correr();
    }//main
}//clase Hilos

class Ventana extends JFrame implements ActionListener{
	private final int WIDTH_TEXT_AREA =50, HEIGHT_TEXT_AREA=30;
	private final long TIME_1 =1000, TIME_2=2000;
	private static final long serialVersionUID = 1L;
	private JButton b;
	private JTextArea a;
	private Hilos h;
	private JPanel bp;
	private JPanel tp;
	private int cont;
	private boolean bandera=true;
	
	public Ventana(){
		super("HILOS");	
		setLayout(new BorderLayout());
		a =new JTextArea(HEIGHT_TEXT_AREA, WIDTH_TEXT_AREA);
		a.setSize(WIDTH_TEXT_AREA,HEIGHT_TEXT_AREA);
		b=new JButton("Dormir/Despertar HILO UNO");
		b.addActionListener(this);
		h = new Hilos("HILO_1",TIME_1,this);
		h.setSize(WIDTH_TEXT_AREA,HEIGHT_TEXT_AREA);
		bp= new JPanel();
		tp=new JPanel();
		tp.add(new JScrollPane(h,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
        tp.add(new JScrollPane(a,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
        bp.add(b);
        add(tp, BorderLayout.CENTER);
        add(bp, BorderLayout.NORTH);
        cont = 0;
        pack();
	}//Ventana	
	
	public synchronized void cambioBandera(){
		bandera=!bandera;
		if(bandera){
			notify();
		}//if
	}//cambioBandera
	
	public void actionPerformed(ActionEvent ae){
		cambioBandera();
	}//actionPerformed
	
	public synchronized void  imprimir(){
		if(!bandera){
			try{
				wait();
			}//try
			catch(InterruptedException e){}
		}//if
	}//imprimir	
	
	public void texto(String text){
		while(true){
			try {
				Thread.sleep(TIME_2);
				cont=cont+1;
				a.setText(a.getText()+text+":  "+cont+"\n");
			}//try 
			catch (InterruptedException e){}
		}//while
	}//texto
	
	public void correr(){
		texto("HILO_2");
	}//correr
}//clase Ventana

