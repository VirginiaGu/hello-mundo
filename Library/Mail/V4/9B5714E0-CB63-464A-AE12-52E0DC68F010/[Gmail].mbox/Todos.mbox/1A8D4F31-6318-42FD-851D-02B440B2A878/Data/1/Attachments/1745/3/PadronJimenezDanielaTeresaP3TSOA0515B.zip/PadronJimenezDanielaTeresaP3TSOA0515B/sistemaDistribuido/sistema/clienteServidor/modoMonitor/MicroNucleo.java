//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 2
package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Hashtable;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.MicroNucleoBase;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;

/**
 * 
 */
public final class MicroNucleo extends MicroNucleoBase{
	private static MicroNucleo nucleo=new MicroNucleo();
	private TablaRecepcion TablaRecibe=new TablaRecepcion();
	private TablaEmision TablaEmite=new TablaEmision();

	/**
	 * 
	 */
	private MicroNucleo(){
	}

	/**
	 * 
	 */
	public final static MicroNucleo obtenerMicroNucleo(){
		return nucleo;
	}

	/*---Metodos para probar el paso de mensajes entre los procesos cliente y servidor en ausencia de datagramas.
    Esta es una forma incorrecta de programacion "por uso de variables globales" (en este caso atributos de clase)
    ya que, para empezar, no se usan ambos parametros en los metodos y fallaria si dos procesos invocaran
    simultaneamente a receiveFalso() al reescriir el atributo mensaje---*/
	byte[] msj;

	/*public void sendFalso(int dest,byte[] message){
		System.arraycopy(message,0,msj,0,message.length);
		notificarHilos();  //Reanuda la ejecucion del proceso que haya invocado a receiveFalso()
	}

	public void receiveFalso(int addr,byte[] message){
		msj=message;
		suspenderProceso();
	}
	/*---------------------------------------------------------*/

	/**
	 * 
	 */
	protected boolean iniciarModulos(){
		return true;
	}

	/**
	 * 
	 */
	protected void sendVerdadero(int dest,byte[] message){
		//sendFalso(dest,message);
		imprimeln("El proceso invocante es el "+super.dameIdProceso());
		int aux;
		String Ip = null;
		//lo siguiente aplica para la pr�ctica #2
		ParMaquinaProceso pmp=dameDestinatarioDesdeInterfaz();
		imprimeln("Enviando mensaje a IP="+pmp.dameIP()+" ID="+pmp.dameID());
		//suspenderProceso();   //esta invocacion depende de si se requiere bloquear al hilo de control invocador
		DatagramSocket socketEmision=dameSocketEmision();
		DatagramPacket dp;
		
		if(TablaEmite.BuscaElem(dest)==1){
			aux=super.dameIdProceso();
			for(int i=0;i<3;i++){
				message[i]=(byte)(aux);
				aux=aux>>>8;
				imprimeln("bien"+message);
			}
			aux=TablaEmite.id(dest);
			
			
			for(int i=4;i>7;i++){
				message[i]=(byte)(aux);
				aux=aux>>>8;
				
		}
			Ip=TablaEmite.ip(dest);
			}
		else{
			aux=super.dameIdProceso();
			for(int i=0;i<4;i++){
				message[i]=(byte)(aux);
				aux=aux>>>8;
				
			}
			
			aux=pmp.dameID();
			
			for(int i=4;i<8;i++){
				message[i]=(byte)(aux);
				aux=aux>>>8;
			}
			Ip=pmp.dameIP();
		}
		
		try{
			dp=new DatagramPacket(message,message.length,InetAddress.getByName(Ip),damePuertoRecepcion());
			socketEmision.send(dp);
			//socketEmision.close();
		}catch(SocketException ex){
			System.out.println("Error iniciando socket: "+ex.getMessage());
		}catch(UnknownHostException ex){
			System.out.println("UnknownHostException: "+ex.getMessage());
		}catch(IOException ex){
			System.out.println("IOException: "+ex.getMessage());
		}
	}

	/**
	 * 
	 */
	protected void receiveVerdadero(int addr,byte[] message){
		//receiveFalso(addr,message);
		//el siguiente aplica para la pr�ctica #2
		TablaRecibe.Agregar(addr, message);
		System.out.println("Asignado a Tabla Recepcion");
		suspenderProceso();
	}

	/**
	 * Para el(la) encargad@ de direccionamiento por servidor de nombres en pr�ctica 5  
	 */
	protected void sendVerdadero(String dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void sendNBVerdadero(int dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void receiveNBVerdadero(int addr,byte[] message){
	}

	/**
	 * 
	 */
	public void run(){

		DatagramSocket socketRecepcion=dameSocketRecepcion();
		DatagramPacket dp;
		byte[] buffer=new byte[1024];
		dp=new DatagramPacket(buffer,buffer.length);
		String ip;
		int o,d,i,emp;
		int blanqueador, aux;
		Proceso proc;
		while(seguirEsperandoDatagramas()){
			/* Lo siguiente es reemplazable en la pr�ctica #2,
			 * sin esto, en pr�ctica #1, seg�n el JRE, puede incrementar el uso de CPU
			 */ 
			try{
				socketRecepcion.receive(dp);
				ip=dp.getAddress().getHostAddress();
				aux=0x00000000;
				emp=0;
					for(i=3;i>=0;i--){
						aux=(aux<<8);
						emp= buffer[i];
						blanqueador=0x000000FF;
						emp= (emp&blanqueador);
						aux=(aux|emp);
					}
					o=aux;
					aux=0x00000000;
					emp=0;
					for(i=7;i>=4;i--){
						aux=(aux<<8);
						emp= buffer[i];
						blanqueador=0x000000FF;
						emp= (emp&blanqueador);
						aux=(aux|emp);
					}
					d=aux;
					System.out.println("d"+d);
					proc=dameProcesoLocal(d);
					if(proc!=null){	
						if(TablaRecibe.BuscaElem(d)==1){
							System.arraycopy(buffer, 0, TablaRecibe.message(d), 0, buffer.length);
							TablaEmite.Agrega(o, ip);
							TablaRecibe.EliminaElem(d);
							reanudarProceso(proc);
						}
						else if(buffer[9]==-101){
							imprimeln("AU: Address Uknown");
							reanudarProceso(proc);
						}							
					}
					else {
						for(int y=0;y<4;y++){
							buffer[y]=(byte)(d);
							d=d>>>8;
							}
						for(int y=4;y<8;y++){
							buffer[y]=(byte)(o);
							o=o>>>8;
							}
						buffer[9]=-101;
					DatagramSocket socketEmision2=dameSocketEmision();	
					imprimeln("AU: Address Uknown");
					dp=new DatagramPacket(buffer,buffer.length,InetAddress.getByName(ip),damePuertoRecepcion());
					socketEmision2.send(dp);
					}
				sleep(600);
			}catch(InterruptedException e){
				System.out.println("InterruptedException");
			}
			catch(IOException ex){
			System.out.println("IOException: "+ex.getMessage());
			}
		}
	}
}

class TablaRecepcion{
	private static Hashtable <Integer,byte[]> materias;

	public TablaRecepcion (){
	materias = new Hashtable<Integer,byte[]>();
	}
	
	public void Agregar(int addr, byte[] message){
		Hashtable tr=new Hashtable<Integer,byte[]>();
		materias.put(Integer.valueOf(addr), message);
		}
	
	public byte [] message(int addr){
		byte [] aux;
		if(materias.containsKey(addr)){
			aux=materias.get(addr);
			return aux;
		}
		else
		return null;
		
	}
	
	public void EliminaElem(int id){
		if(materias.containsKey(id)){
			materias.remove(id);
		}
		
	}
	
	public int BuscaElem(int id){
		int band;
		if(materias.containsKey(id)){
			return band=1;
		}
		else
			return band=0;
	}

	}
class ParMP{
	public int id;
	public String ip;
}
	class TablaEmision{
		private static Hashtable <Integer,ParMP> materias;

		public TablaEmision (){
		materias = new Hashtable<Integer,ParMP>();
		}
		
		public String ip(int dest) {
			ParMP aux =new ParMP();
			if(materias.containsKey(dest)){
				aux=materias.get(dest);
				return aux.ip;
			}
			else
			return null;
		}

		public int id(int dest) {
			ParMP aux =new ParMP();
			if(materias.containsKey(dest)){
				aux=materias.get(dest);
				return aux.id;
			}
			else
			return -100;
			
		}

		public void Agrega(int addr, String ip){
			ParMP TE=new ParMP();
			TE.id=addr;
			TE.ip=ip;
			materias.put(Integer.valueOf(addr), TE);
			}
		
		public void EliminaElem(int id){
			if(materias.containsKey(id)){
				materias.remove(id);
			}
		}
		
		public int BuscaElem(int id){
			int band;
			if(materias.containsKey(id)){
				return band=1;
			}
			else
				return band=0;
		}
	}
		