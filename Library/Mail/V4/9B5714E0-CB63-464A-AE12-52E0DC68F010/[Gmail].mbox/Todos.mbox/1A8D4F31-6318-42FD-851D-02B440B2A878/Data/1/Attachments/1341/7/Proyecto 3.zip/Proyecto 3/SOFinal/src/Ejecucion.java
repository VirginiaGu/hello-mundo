
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JToolBar;
import javax.swing.JButton;


public class Ejecucion extends JFrame{

	String[] titulos={"Proceso","Tama�o","Prioridad","Error","Bloqueo"};
	String t="";
	int algoritmo, situacion=0;
	int Memoria[][];
	
	PROCESA Procesa;
	
	Proceso ProcesoenEjecucion = new Proceso();
	
	JPanel contentPane;
	JTable table = new JTable();
	DefaultTableModel tabla;
		
	
	public Ejecucion(){
		super("\tEjecucion");
			
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0,302,370,300);

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		setContentPane(contentPane);
		
		table.setModel(new DefaultTableModel(new Object[][] {},titulos));
		
		tabla=(DefaultTableModel) table.getModel();
		
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
			
				
	}
	
		
	public void Mostrar(){
		
		for (int i = 0; i <tabla.getRowCount();)
	           tabla.removeRow(i);
		
		ArrayList<Object[]> ListaEjecucion = new ArrayList<Object[]>();
		Object[] fila = new Object[5];
		 
			   fila[0]=ProcesoenEjecucion.ID;
			   fila[1]=ProcesoenEjecucion.tama�o;
			   fila[2]=ProcesoenEjecucion.prioridad;
			   fila[3]=ProcesoenEjecucion.error;
			   fila[4]=ProcesoenEjecucion.bloqueo;
			   
			   ListaEjecucion.add(fila);
			   fila= new Object[5];
						
			Iterator<Object[]> iterador = ListaEjecucion.iterator();
			        Object[] f = iterador.next();
			        tabla.addRow(f);		
	}
	
	public Proceso getProcesoenEjecucion(){
		Proceso Procesoaux = new Proceso();
	    Procesoaux=ProcesoenEjecucion;
	    ProcesoenEjecucion=new Proceso();
		return Procesoaux;
	}
	
	public void setProcesoenEjecucion(Proceso ProcesoAux){
		this.ProcesoenEjecucion=ProcesoAux;
	}	
	
	public void Ejecutar(){
		
	    	
		if(ProcesoenEjecucion.tama�o==0||ProcesoenEjecucion.tama�o==ProcesoenEjecucion.error)
			  situacion=1;
		
		  else if(ProcesoenEjecucion.tama�o==ProcesoenEjecucion.bloqueo){
			  Procesa.Procesamiento(); 
			  situacion=2; 
		  }
		  else{
		      ProcesoenEjecucion.tama�o--;
		      Procesa.Procesamiento();
		      situacion=0;
		  }
	}
	
	
}