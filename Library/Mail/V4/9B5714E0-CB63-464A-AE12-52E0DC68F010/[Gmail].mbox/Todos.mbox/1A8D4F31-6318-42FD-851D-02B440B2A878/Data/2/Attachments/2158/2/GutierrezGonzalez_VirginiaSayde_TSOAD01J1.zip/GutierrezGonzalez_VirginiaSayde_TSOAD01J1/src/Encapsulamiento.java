//Tarea Java#1: Ocultamiento de Informaci�n y Encapsulamiento
//Nombre: Virginia Sayde Guti�rrez Gonz�lez
//Secci�n: D01

import java.util.*;

public class Encapsulamiento {
	public static class MiFecha{
			//atributos
			private int dia, mes, anio;	
			//constructor sin parametros
			public MiFecha(){
				dia=7; mes= 4; anio=1989;
			}//fin de constructor
			
			private boolean verificaDia(int d, int m, int a){
				boolean bisiesto=false;
				if(m<1 || m>=13){			
					return false;
				}//if
				else if(d<1 || d>=32){				
					return false;
				}//else if
					   if((m==4 || m==6 || m==9 || m==11) && (d>30)){
						   return false;
					   }//if
						   if((m==1 || m==3 || m==5 || m==7 || m==8 || m==10 || m==12) && (d>31)){
							   return false;
						   }//if
						     if(m==2 && a%4==0 && d<=29){	
						       bisiesto= true;
						        if(m==2 && a%100==0 && d<=29){	
						        	bisiesto=false;
						        	   if(m==2 && a%400==0 && d<=29){
						        		   bisiesto=true;
						        	   }//if
						        }//if
						     }//if
			     if(bisiesto!=true && m==2 &&d>=29){
			    	 return false;
			     }//if
			     dia=d;
			     mes=m;
			     anio=a;
			     return true;
			}//verificaDia
			
			//familia de metodos fija 	
			public boolean fijaDia(int d){			
				if(verificaDia(d,mes,anio)){	
					return true;
				}//if	
				else return false;
			}//fijaDia
			
			public boolean fijaMes(int m){
				if(verificaDia(dia,m,anio)){
					return true;
				}//if
				else return false;
			}//fijaMes
			
			public boolean fijaAnio(int a){
				if(verificaDia(dia,mes,a)){
					return true;
				}//if
				else return false;
			}//fijaAnio
			
			//familia de metodos dame	
			public int dameDia(){
			    return dia;    
			}//dameDia
			
			public int dameMes(){
				 return mes;
			}//dameMes

			public int dameAnio(){
				   return anio;
			}//dameAnio		
	}//clase MiFecha
	
	public static void main(String[]args){	
		int opc,cd,cm,ca;
		MiFecha Calender = new MiFecha();
	do{				
		System.out.println("Fecha: "+Calender.dameDia() +"/"+ Calender.dameMes() +"/"+ Calender.dameAnio());
		System.out.println("\n\nMenu");
		System.out.println("1) Cambiar Dia");
		System.out.println("2) Cambiar Mes");
		System.out.println("3) Cambiar anio");
		System.out.println("4) Salir del programa");
		System.out.println("Dame tu opcion: ");
		Scanner s=new Scanner (System.in);
		opc=s.nextInt();
		switch(opc){
		case 1: System.out.print("Dame Dia: ");
		        cd=s.nextInt();
		        Calender.fijaDia(cd);
			break;
		case 2: System.out.print("Dame Mes: ");
			     cm=s.nextInt();
			     Calender.fijaMes(cm);
			break;
		case 3: System.out.print("Dame anio: ");
		        ca=s.nextInt();
		        Calender.fijaAnio(ca);
			break;	
		case 4: System.out.print("saliendo del programa...");
			break;
		default: System.out.println("Opcion no valida, intentalo de nuevo");
		}//fin switch
	  }while(opc!=4);
	}//main
}//clase Encapsulamiento
