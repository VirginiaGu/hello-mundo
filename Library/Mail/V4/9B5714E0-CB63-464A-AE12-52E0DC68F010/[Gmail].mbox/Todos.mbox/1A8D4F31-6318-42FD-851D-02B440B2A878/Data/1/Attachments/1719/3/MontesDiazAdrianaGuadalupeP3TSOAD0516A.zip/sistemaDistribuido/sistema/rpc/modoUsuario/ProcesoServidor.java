/*
 * Pr�ctica #3: 
 * Llamadas a Procedimientos Remotos (RPC) 
 * �Resguardos del Cliente y del Servidor� 
 * @author: Adriana Guadalupe Montes D�az
 * @code: 210224063
 */

package sistemaDistribuido.sistema.rpc.modoUsuario;

//import sistemaDistribuido.sistema.rpc.modoMonitor.RPC;   //para pr�ctica 4
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 */
public class ProcesoServidor extends Proceso{
	final int MESSAGE_LENGTH = 1024;
	final int BYTES_X_INT = 4;
	final int BITS_X_BYTE = 8;
	final short CUBE = 11;
	final short FACTORIAL = 12;
	final short POW = 13;
	final short MIN = 14;
	private LibreriaServidor ls;   //para pr�ctica 3
	

	/**
	 * 
	 */
	public ProcesoServidor(Escribano esc){
		super(esc);
		ls=new LibreriaServidor(esc);   //para pr�ctica 3
		start();
	}
	
	protected int convertToInteger(byte[] array) {
		int number = 0;
		for(int i = 0; i < array.length; i++) {
			number +=(int)((array[i] & 0xFF)<<(i*8));
		}
		return number;
	}
	
	protected byte[] convertToByte(int decimal) {
		byte[] result = new byte[BYTES_X_INT];
		
		for(int i = 0; i < BYTES_X_INT; i++) {
			result[i] = (byte) ((decimal >> (BITS_X_BYTE*i))& 0xFF);
		}
		return result;
	}

	/**
	 * Resguardo del servidor
	 */
	public void run(){
		imprimeln("Proceso servidor en ejecucion.");
		//idUnico=RPC.exportarInterfaz("FileServer", "3.1", asa)  //para pr�ctica 4
		byte[] solServidor = new byte[MESSAGE_LENGTH];
		byte[] resServidor = new byte[MESSAGE_LENGTH];

		while(continuar()){
			Nucleo.receive(dameID(),solServidor);
			byte[] codop = {
					solServidor[8],
					solServidor[9]
			};
			int operation = convertToInteger(codop);
			imprimeln("Procesando solicitud.");
			switch(operation) {
				case CUBE: {
					byte[] aux = {
							solServidor[10],
							solServidor[11],
							solServidor[12],
							solServidor[13]
					};
					int side = convertToInteger(aux);
					int result  = ls.cube(side);
					
					aux = convertToByte(result);
					System.arraycopy(aux, 0, resServidor, 10, BYTES_X_INT);
				}break;
				case FACTORIAL:{
					byte[] aux = {
							solServidor[10],
							solServidor[11],
							solServidor[12],
							solServidor[13]
					};
					int number = convertToInteger(aux);
					int result  = ls.factorial(number);
					
					aux = convertToByte(result);
					System.arraycopy(aux, 0, resServidor, 10, BYTES_X_INT);
				}break;
				case POW:{
					byte[] aux1 = {
							solServidor[10],
							solServidor[11],
							solServidor[12],
							solServidor[13]
					};
					byte[] aux2 = {
							solServidor[14],
							solServidor[15],
							solServidor[16],
							solServidor[17]
					};
					
					int exp = convertToInteger(aux1);
					int base = convertToInteger(aux2);
					int result  = ls.pow(base, exp);
					
					byte[] aux = convertToByte(result);
					System.arraycopy(aux, 0, resServidor, 10, BYTES_X_INT);
				}break;
				
				
				case MIN:{
					byte[] aux = {
							solServidor[10],
							solServidor[11],
							solServidor[12],
							solServidor[13]
					};
					
					int count = convertToInteger(aux);
					int[] list = new int[count];
					
					
					for(int i = 14, j = 0; j < count; j++) {
						byte[] number = {
								solServidor[i++],
								solServidor[i++],
								solServidor[i++],
								solServidor[i++]
						};
						list[j] = convertToInteger(number);
					}

					int result  = ls.min(list);
					
					byte[] res = convertToByte(result);
					System.arraycopy(res, 0, resServidor, 10, BYTES_X_INT);
				}break;
			}
			Nucleo.send((int)solServidor[1], resServidor);
		}

		//RPC.deregistrarInterfaz(nombreServidor, version, idUnico)  //para pr�ctica 4
	}
}
