/*Sofía Silva Villalobos
  Sección: D01
  Práctica #3
*/

package clienteservidor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ResguardoCliente implements Runnable{
    Nucleo Nucleo;
    Procesos cliente;
    
    ByteArrayOutputStream buffer=new ByteArrayOutputStream();
    int operacion;
    boolean enviar,esperar,recibir,llegoMensaje;
    String idOrigen;
    
    public ResguardoCliente(Procesos c,Nucleo nucleo){
        cliente=c;
        Nucleo=nucleo;
    }
    
    public void run() {
        while(true){
                if(this.esperar==false){
                    try {
                        if(this.enviar==true){
                            Dormir();
                            cliente.txtResguardo.append("Sacar parametros\n");
                            cliente.txtResguardo.append("\nInvocando a Send()\n");
                            cliente.txtNumero1.setEditable(false);  
                            cliente.txtNumero2.setEditable(false);
                            cliente.cmdEnviar.setEnabled(false);
                            CrearMensaje();
                            enviar=false;
                        }
                        if(this.recibir==true){
                            RecibirRespuestas();
                            EliminarParametros();
                            Nucleo.txtEventos.append("***************************FIN DE PROCESO**************************\n");
                            recibir=false;
                        }
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if(this.llegoMensaje==true){
                    llegoMensaje=false;
                    cliente.txtNumero1.setEditable(true);  
                    cliente.txtNumero2.setEditable(true);
                    cliente.cmdEnviar.setEnabled(true);
                }
        } 
    }
    
    public void CrearMensaje(){
        cliente.txtResguardo.append("Generando mensaje a ser enviado,llenando los campos necesarios\n");
        Dormir();
        
        try {
            buffer.reset();
            buffer.write(cliente.codop);
            ObtenerOperandos();
            Nucleo.CompletarMensajeCliente(cliente.id,buffer.toByteArray());   
        } catch (IOException ex) {
            Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void ObtenerOperandos(){
        int tamanioOp1,tamanioOp2,pos;
        tamanioOp1=cliente.txtNumero1.getText().length();
        tamanioOp2=cliente.txtNumero2.getText().length();
        
        if(tamanioOp1+tamanioOp2<1014){
            try {
                byte[] operando;
                operando=ConvertirBinario(tamanioOp1);
                buffer.write(operando);
                operando=ConvertirBinario(tamanioOp2);
                buffer.write(operando);
                
                
                byte[] operando1=new byte[tamanioOp1];
                byte[] opBytes;
                opBytes=cliente.txtNumero1.getText().getBytes();
                pos=0;
                while(pos<tamanioOp1){
                    operando1[pos]=opBytes[pos];
                    pos++;
                }
                buffer.write(operando1);
                
                byte[] operando2=new byte[tamanioOp2];
                opBytes=cliente.txtNumero2.getText().getBytes();
                pos=0;
                while(pos<tamanioOp2){
                    operando2[pos]=opBytes[pos];
                    pos++;
                }
                buffer.write(operando2);
            } catch (IOException ex) {
                Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
            JOptionPane.showMessageDialog(null, "Operandos demasiado largos","", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public byte[] ConvertirBinario(int num){
        char[] cadenaBinaria=new char[17];
        int dividendo,nuevo_dividendo,residuo,pos=15;
        char caracter;

        dividendo=num;
        nuevo_dividendo=dividendo/2;

        while(nuevo_dividendo!=0){
            residuo=dividendo%2;
            caracter=(char)(residuo+48);
            cadenaBinaria[pos]=caracter;
            pos--;
            dividendo=nuevo_dividendo;
            nuevo_dividendo=dividendo/2;
        }
        caracter=(char)(dividendo+48);
        cadenaBinaria[pos]=caracter;
        
        byte[] operando=ConvertirEntero(cadenaBinaria);
        return operando;
    }
    
    public byte[] ConvertirEntero(char[] cadenaBinaria){
        byte[] operando=new byte[2];
        int num,suma=0;
        for(int x=0;x<8;x++){
            if(cadenaBinaria[x]=='0'||cadenaBinaria[x]=='1'){
                num=(int)(cadenaBinaria[x]-48);
                suma=(suma*2)+num;
            }
        }
        operando[0]=(byte) suma;
        suma=0;
        for(int x=8;x<16;x++){
            if(cadenaBinaria[x]=='0'||cadenaBinaria[x]=='1'){
                num=(int)(cadenaBinaria[x]-48);
                suma=(suma*2)+num;
            }
        }
        operando[1]=(byte) suma;
        return operando;
    }
    
    public void RecibirRespuestas(){
        buffer.reset();
        Nucleo.Receive(cliente.id,buffer.toByteArray());
        
        byte[] mensaje=buffer.toByteArray();        
        
        String idOrig="";
        idOrig+=Byte.toString(mensaje[0]);
	idOrig+=Byte.toString(mensaje[1]);
        
        cliente.txtEventos.append("Recibio: REP("+Integer.parseInt(idOrig)+",");
        int tamanio=mensaje.length;
        for(int x=0;x<tamanio;x++){
            cliente.txtEventos.append(Byte.toString(mensaje[x]));
        }
        cliente.txtEventos.append(","+cliente.id+")\n");
        
        idOrigen=Integer.toString(Integer.parseInt(idOrig));
        Nucleo.TablaProcesos.get(idOrigen).txtEventos.append("Recibio: ACK("+cliente.id+","+Integer.parseInt(idOrig)+")\n");
        Nucleo.TablaProcesos.get(idOrigen).txtResguardo.append("\nInvocando a Receive()\n");
        Nucleo.TablaResguardosServidores.get(idOrigen).llegoMensaje=true;
        
        cliente.txtResguardo.append("Mensaje recibido:");
        for(int x=0;x<tamanio;x++){
            cliente.txtResguardo.append(Byte.toString(mensaje[x]));
        }
        cliente.txtResguardo.append("\n");

        int res;
        res=ObtenerResultado(buffer.toByteArray());
        
        cliente.txtResguardo.append("Procesando respuesta recibida del servidor\n");
        Dormir();
        cliente.txtResguardo.append("Respuesta desempacada: "+res+"\n");
        cliente.txtResguardo.append("Regresando respuesta al cliente\n");
        Dormir();
        cliente.txtEventos.append("Respuesta recibida del Resguardo\n");
        cliente.txtEventos.append("Respuesta del servidor: "+res+"\n");
         
        Nucleo.Peticiones.remove(Integer.toString(cliente.id));
    }
    
    public int ObtenerResultado(byte[] Mensaje){
        int i,respuesta;
        respuesta=0;
        for(i=4;i<Mensaje.length;i++){
            int num=Mensaje[i];
            if(num!=0)
                num-=48;

            respuesta=(respuesta*10)+num;
        }
        return respuesta;
    }
   
    public void EliminarParametros(){
        int x=0;
        int tamaniopila=cliente.pila.size();
        while(x<tamaniopila){
            cliente.pila.set(x, null);
            x++;
        }
        x=0;
        cliente.txtPila.setText("");
        while(x<tamaniopila){
            if(cliente.pila.get(x)!=null)
                cliente.txtPila.append(cliente.pila.get(x)+"\n");
            x++;
        }
    }
    
    public void Dormir(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
