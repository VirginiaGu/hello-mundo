/*
 * PRACTICA 1
 * @author: Adriana Guadalupe Montes D�az
 */

package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;
import sistemaDistribuido.util.Pausador;
	
/**
 * 
 */
public class ProcesoServidor extends Proceso{
	final int MESSAGE_LENGTH = 1024;
	final int CONTENT_LENGTH = 1016;
	String file_name;
	String file_content;
	final int CREATE = 0;
	final int DELETE = 1;
	final int READ = 2;
	final int WRITE = 3;
	final static int BYTES_X_SHORT = 2;
	final int BITS_X_BYTE = 8;
	final static int BYTES_X_INT = 4;
	final int SUCCESS = 1;
	final int ERROR = 0;
	
	String  response;
	short code_operation;
	
	final String ARCHIVO_CREADO = "Archivo CREADO con exito.";
	final String ARCHIVO_NO_CREADO = "El archivo NO pudo ser creado.";
	
	final String ARCHIVO_ELIMINADO = "Archivo ELIMINADO con exito.";
	final String ARCHIVO_NO_ELIMINADO = "El archivo NO pudo ser eliminado.";
	
	final String ARCHIVO_ESCRITO = "Archivo ESCRITO con exito.";
	final String ARCHIVO_NO_ESCRITO = "El archivo NO pudo ser escrito.";
	
	final String ARCHIVO_LEIDO = "Archivo LEIDO con exito.";
	final String ARCHIVO_NO_LEIDO = "El archivo NO pudo ser leido.";
	
	final String OPERACION_INVALIDA = "NO se reconoci� la operacion.";

	
	/**
	 * 
	 */
	public ProcesoServidor(Escribano esc){
		super(esc);
		start();
		file_name = "";
		file_content = "";
		code_operation = -1;
		response = "";
	}
	
	public static short convertToShort(byte[] array) {
		short number = 0;
		for(int i = 0; i < BYTES_X_SHORT; i++) {
			number +=(short)((array[i] & 0xFF)<<(i*8));
		}
		return number;
	}
	
	public static int convertToInteger(byte[] array) {
		int number = 0;
		for(int i = 0; i < BYTES_X_INT; i++) {
			number +=(int)((array[i] & 0xFF)<<(i*8));
		}
		return number;
	}
	
	public static void printArray(byte[] array) {
		System.out.println("");
		for(int i = 0; i < array.length; i++) {
			System.out.println(" - "+(char)array[i]+" - "+(int)array[i]);
		}
	}
	
	public byte[] convertToByte(int decimal) {
		byte[] result = new byte[BYTES_X_INT];
		
		for(int i = 0; i < BYTES_X_INT; i++) {
			result[i] = (byte) ((decimal >> (BITS_X_BYTE*i))& 0xFF);
		}
		return result;
	}
	
	public byte[] convertToByte(short decimal) {
		byte[] result = new byte[BYTES_X_SHORT];
		
		for(int i = 0; i < BYTES_X_SHORT; i++) {
			result[i] = (byte) ((decimal >> (BITS_X_BYTE*i))& 0xFF);
		}
		return result;
	}

	public void getData(byte[] array) {
		//printArray(array);
		
		if(array.length > 10) {
			byte[] size = {
					array[10],
					array[11],
					array[12],
					array[13]
			};
			int file_name_size = convertToInteger(size)-BYTES_X_INT;
			if(file_name_size > 0) {
				byte[] aux = new byte[file_name_size];
				System.arraycopy(array, 14, aux, 0, file_name_size);
		
				for(int i = 0; i < aux.length; i++) {
					file_name += ((char)aux[i]);
				}
				
				if(array.length > (file_name_size+10+BYTES_X_INT)) {
					int index = file_name_size+10+BYTES_X_INT;
					
					byte[] size1 = {
							array[index++],
							array[index++],
							array[index++],
							array[index++]
					};
					int file_size = convertToInteger(size1)-BYTES_X_INT;
					if(file_size > 0) {
						byte[] aux1 = new byte[file_size];
						System.arraycopy(array, index, aux1, 0, file_size);
						
						
						for(int i = 0; i < aux1.length; i++) {
							file_content += ((char)aux1[i]);
						}
					}
				}
			}
			//System.out.println(array.length);
			
			
		}
	}

	/**
	 * 
	 */
	public void run(){
		imprimeln("Proceso servidor en ejecucion.");
		byte[] solServidor=new byte[MESSAGE_LENGTH];
		byte[] respServidor;
		
		while(continuar()){
			Nucleo.receive(dameID(),solServidor);
			byte[] codop = {
					solServidor[8],
					solServidor[9]
			};
			
			imprimeln("Procesando petici�n recibida del cliente");
			code_operation = convertToShort(codop);
			
			if(solServidor.length > 10) {
				getData(solServidor);
				TextFile file = new TextFile(file_name);
				
				switch(code_operation) {
					case CREATE: {
						imprimeln("El cliente solicit� CREAR el archivo "+file_name);
						imprimeln("TEXTO: "+file_content);
						if (file.write(file_content)) {
							response = ARCHIVO_CREADO;
						} else {
							response = ARCHIVO_NO_CREADO;
						}
					}
					break;
					case DELETE: {
						imprimeln("El cliente solicit� ELIMNAR el archivo "+file_name);
						if (file.delete()) {
							response = ARCHIVO_ELIMINADO;
						} else {
							response = ARCHIVO_NO_ELIMINADO;
						}
					}
					break;
					case READ: {
						imprimeln("El cliente solicit� LEER el archivo "+file_name);
						if (file.read()) {
							response = ARCHIVO_LEIDO;
						} else {
							response = ARCHIVO_NO_LEIDO;
						}
					}
					break;
					case WRITE: {
						imprimeln("El cliente solicit� ESCRIBIR el archivo "+file_name);
						
						imprimeln("TEXTO: "+file_content);
						if (file.write(file_content)) {
							response = ARCHIVO_ESCRITO;
						} else {
							response = ARCHIVO_NO_ESCRITO;
						}

					}
					break;
					default: 
						imprimeln(OPERACION_INVALIDA);
						response = OPERACION_INVALIDA;
				}
			}
			
			respServidor=new byte[1024];
			int lenght = response.length()+BYTES_X_INT;
			System.arraycopy(convertToByte(lenght), 0, respServidor, 8, BYTES_X_INT);
			System.arraycopy(response.getBytes(), 0, respServidor, 12, response.getBytes().length);
			imprimeln("Generando respuesta a ser enviada, llenando los campos necesarios");
			Pausador.pausa(1000);  //sin esta l�nea es posible que Servidor solicite send antes que Cliente solicite receive
			imprimeln("Enviando respuesta");
			Nucleo.send(solServidor[1],respServidor);
		}
	}
}
