import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.swing.JFrame;

public class CSControlSingleton {
	
	private static CSControlSingleton instancia = null;
	private ArrayList<String> ClientesDisponibles = new ArrayList<String>();
	private HashMap<String, ClienteGUI> Clientes = new HashMap<String, ClienteGUI>();
	private ArrayList<String> ServidoresDisponibles = new ArrayList<String>();
	private HashMap<String, ServidorGUI> Servidores = new HashMap<String, ServidorGUI>();
	
	private CSControlSingleton(){
		ClientesDisponibles.add("Cliente 1"); ClientesDisponibles.add("Cliente 2"); ClientesDisponibles.add("Cliente 3");
		ClientesDisponibles.add("Cliente 4"); ClientesDisponibles.add("Cliente 5"); ClientesDisponibles.add("Cliente 6");
		ClientesDisponibles.add("Cliente 7"); ClientesDisponibles.add("Cliente 8"); ClientesDisponibles.add("Cliente 9");
		ClientesDisponibles.add("Cliente 10"); ClientesDisponibles.add("Cliente 11"); ClientesDisponibles.add("Cliente 12");
		ClientesDisponibles.add("Cliente 13"); ClientesDisponibles.add("Cliente 14"); ClientesDisponibles.add("Cliente 15");
		ClientesDisponibles.add("Cliente 16");
		
		ServidoresDisponibles.add("Servidor 1"); ServidoresDisponibles.add("Servidor 2"); ServidoresDisponibles.add("Servidor 3"); 
		ServidoresDisponibles.add("Servidor 4"); ServidoresDisponibles.add("Servidor 5"); ServidoresDisponibles.add("Servidor 6");
		ServidoresDisponibles.add("Servidor 7"); ServidoresDisponibles.add("Servidor 8"); ServidoresDisponibles.add("Servidor 9");
		ServidoresDisponibles.add("Servidor 10"); ServidoresDisponibles.add("Servidor 11"); ServidoresDisponibles.add("Servidor 12"); 
		ServidoresDisponibles.add("Servidor 13"); ServidoresDisponibles.add("Servidor 14"); ServidoresDisponibles.add("Servidor 15"); 
		ServidoresDisponibles.add("Servidor 16");
	}
	
	public int cDisponibles(){//Cu�ntos ID disponibles para crear Clientes hay
		return ClientesDisponibles.size();
	}
	
	public int sDisponibles(){//Cu�ntos ID disponibles para crear Servidores hay
		return ServidoresDisponibles.size();
	}
	
	public String clientePop(){//Elimina el primer elemento de los Clientes disponibles y lo regresa
		return ClientesDisponibles.remove(0);
	}
	
	public String servidorPop(){//Elimina el primer elemento de los Servidores disponibles y lo regresa
		return ServidoresDisponibles.remove(0);
	}
	
	public void clientePush(String id){//Agrega en la primera posici�n un ID porque ahora estar� dispinible para Clientes
		ClientesDisponibles.add(0,id);
	}
	
	public void servidorPush(String id){//Agrega en la primera posici�n un ID porque ahora estar� dispinible para Servidores
		ServidoresDisponibles.add(0,id);
	}
	
	public void registrarCliente(String id, ClienteGUI frame){//Agrega un Cliente al mapa que los contiene
		Clientes.put(id, frame);
	}
	
	public void registrarServidor(String id, ServidorGUI frame){//Agrega un Servidor al mapa que los contiene
		Servidores.put(id, frame);
	}
	
	public void eliminarCliente(String id){//Elimina un Cliente del mapa que los contiene
		Clientes.remove(id);
		byte[] datagramaEnviar = new byte[1024];
		datagramaEnviar=("Termin� el proceso: "+id).getBytes();
		try {
			DatagramSocket clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			DatagramPacket paqueteEnviar = new DatagramPacket(datagramaEnviar, datagramaEnviar.length, IPAddress, 25000);
			clientSocket.send(paqueteEnviar);
			clientSocket.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}   
	}
	
	public void eliminarServidor(String id){//Elimina un Servidor del mapa que los contiene
		Servidores.remove(id);
		byte[] datagramaEnviar = new byte[1024];
		datagramaEnviar=("Termin� el proceso: "+id).getBytes();
		try {
			DatagramSocket clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			DatagramPacket paqueteEnviar = new DatagramPacket(datagramaEnviar, datagramaEnviar.length, IPAddress, 25000);
			clientSocket.send(paqueteEnviar);
			clientSocket.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}  
	}
	
	public ClienteGUI disposeCliente(String id){
		return Clientes.get(id);
	}
	
	public ServidorGUI disposeServidor(String id){
		return Servidores.get(id);
	}
	
	public String[] listaProcesos(){
		HashMap<String, JFrame> procesos = new HashMap<String, JFrame>();
		procesos.putAll(Clientes);
		procesos.putAll(Servidores);
		if(procesos.size()>0){
			return procesos.keySet().toArray(new String[procesos.size()]);
		}
		else{
			String[] n = {"..."};
			return n;
		}
	}
	
	public String getAServer(){
		if(sDisponibles()<16){
			Random rand = new Random();
			String[] disponibles = Servidores.keySet().toArray(new String[Servidores.size()]);
			ServidorGUI serv = Servidores.get(disponibles[0]);
			return serv.getID()+"~"+serv.getIP();
		}else{
			return null;
		}
	}

	public static CSControlSingleton getInstance(){
		if(instancia == null)
			instancia = new CSControlSingleton();
		return instancia;
	}
}
