import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class MyWindow extends JFrame implements ActionListener{
   JButton b1,b2,b3;
   JLabel l;
   JTextField t;
   
   public MyWindow(){
	   b1=new JButton("Presione");
	   this.getContentPane().add(b1,BorderLayout.NORTH);
	   b1.addActionListener(this);
	   b2=new JButton("Borra area de texto");
	   this.getContentPane().add(b2,BorderLayout.EAST);
	   b2.addActionListener(this);
	   b3=new JButton("Borra texto");
	   this.getContentPane().add(b3,BorderLayout.WEST);
	   b3.addActionListener(this);
	   l=new JLabel();
	   this.getContentPane().add(l,BorderLayout.CENTER);
	   t=new JTextField("");
	   this.getContentPane().add(t,BorderLayout.SOUTH);
   }
   public void actionPerformed(ActionEvent ae){
	   if(ae.getSource()==b1){
		   String dato;
		   dato=this.t.getText();
		   this.l.setText(dato);
	   }
	   if(ae.getSource()==b2){
		   this.l.setText("");
	   }
	   if(ae.getSource()==b3){
		   this.t.setText("");
	   }
	   
   }
   public static void main(String []args){
	   MyWindow m=new MyWindow();
	   m.setVisible(true);
	   m.setSize(515,515);
	   m.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   
   }
}
