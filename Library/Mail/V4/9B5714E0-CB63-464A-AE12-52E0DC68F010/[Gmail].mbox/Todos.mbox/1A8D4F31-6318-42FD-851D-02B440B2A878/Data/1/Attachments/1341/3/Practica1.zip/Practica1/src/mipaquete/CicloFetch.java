/**
 * @(#)CicloFetch.java
 * Fecha 03/02/2016
 * @author Virginia Sayde Gutierrez Gonzalez
 * @version 1.00 
 */

package mipaquete;

import java.io.*;
import java.util.*;


class CicloFetch {
	public static void main(String[] args) {
		InputStreamReader in=new InputStreamReader(System.in);//lector
		BufferedReader lec = new BufferedReader(in);
		String archivo;
		System.out.println("Archivo: ");
		try{
		   archivo = lec.readLine() + ".txt";
		   Sentencia t = new Sentencia();
		  t.leer(archivo);
		}catch(IOException e){};
	}//main
}//clase CicloFetch



