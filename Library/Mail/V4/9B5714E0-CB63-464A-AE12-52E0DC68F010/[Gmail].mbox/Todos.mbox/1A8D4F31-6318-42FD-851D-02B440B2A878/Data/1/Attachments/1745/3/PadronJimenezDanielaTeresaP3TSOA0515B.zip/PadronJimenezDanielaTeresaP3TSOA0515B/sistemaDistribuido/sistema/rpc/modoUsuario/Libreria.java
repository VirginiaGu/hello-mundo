//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 3
package sistemaDistribuido.sistema.rpc.modoUsuario;

import java.util.Stack;
import java.util.StringTokenizer;

import sistemaDistribuido.util.Escribano;

public abstract class Libreria{
	private Escribano esc;
	Stack pila=new Stack();

	/**
	 * 
	 */
	public Libreria(Escribano esc){
		this.esc=esc;
	}

	/**
	 * 
	 */
	protected void imprime(String s){
		esc.imprime(s);
	}

	/**
	 * 
	 */
	protected void imprimeln(String s){
		esc.imprimeln(s);
	}

	/**
	 * Ejemplo para el paso intermedio de parametros en pila.
	 * Esto es lo que esta disponible como interfaz al usuario programador
	 */
	/*public int suma(int sum1,int sum2){
    //...
    suma();
    //...
    return 0;
  }

	public int suma(int sum1,int sum2){
		return sum1+sum2;
	}

	public int resta(int minuendo,int sustraendo){
		return minuendo-sustraendo;
	}

	public int multiplicacion(int multiplicando,int multiplicador){
		return multiplicando*multiplicador;
	}

	public int division(int dividendo,int divisor){
		return dividendo/divisor;
	}

	/**
	 * Servidor suma verdadera generable por un compilador estandar
	 * o resguardo de la misma por un compilador de resguardos.
	 */
	protected abstract void suma();
	protected abstract void sum();
	protected abstract void cubo();
	protected abstract void div();
	protected abstract void cuad();

	public int sum(byte[] operacion) {
		int aux,emp,blanqueador;
		aux=0x00000000;
		emp=0;
			for(int i=3;i>=0;i--){
				aux=(aux<<8);
				emp= operacion[i];
				blanqueador=0x000000FF;
				emp= (emp&blanqueador);
				aux=(aux|emp);
			}
			pila.push(Integer.valueOf(aux));
			aux=0x00000000;
			emp=0;
			for(int i=7;i>=4;i--){
				aux=(aux<<8);
				emp= operacion[i];
				blanqueador=0x000000FF;
				emp= (emp&blanqueador);
				aux=(aux|emp);
			}
			pila.push(Integer.valueOf(aux));
			sum();
			aux=(int) pila.peek();
		return aux;
	}


	public int cubo(byte[] operacion2) {
		int aux,emp,blanqueador;
		aux=0x00000000;
		emp=0;
			for(int i=3;i>=0;i--){
				aux=(aux<<8);
				emp= operacion2[i];
				blanqueador=0x000000FF;
				emp= (emp&blanqueador);
				aux=(aux|emp);
			}
			pila.push(Integer.valueOf(aux));
			cubo();
			aux=(int) pila.peek();
		return aux;
	}
	
	public int div(byte[] operacion3) {
		int aux,emp,blanqueador;
		aux=0x00000000;
		emp=0;
			for(int i=3;i>=0;i--){
				aux=(aux<<8);
				emp= operacion3[i];
				blanqueador=0x000000FF;
				emp= (emp&blanqueador);
				aux=(aux|emp);
			}
			pila.push(Integer.valueOf(aux));
			aux=0x00000000;
			emp=0;
			for(int i=7;i>=4;i--){
				aux=(aux<<8);
				emp= operacion3[i];
				blanqueador=0x000000FF;
				emp= (emp&blanqueador);
				aux=(aux|emp);
			}
			pila.push(Integer.valueOf(aux));
			div();
			aux=(int) pila.peek();
		return aux;
		}

	public int cuad(byte[] operacion4) {
		// TODO Auto-generated method stub
		int aux,emp,blanqueador;
		aux=0x00000000;
		emp=0;
			for(int i=3;i>=0;i--){
				aux=(aux<<8);
				emp= operacion4[i];
				blanqueador=0x000000FF;
				emp= (emp&blanqueador);
				aux=(aux|emp);
			}
			pila.push(Integer.valueOf(aux));
			cuad();
			aux=(int) pila.peek();
		return aux;
	}

	//****
	
}