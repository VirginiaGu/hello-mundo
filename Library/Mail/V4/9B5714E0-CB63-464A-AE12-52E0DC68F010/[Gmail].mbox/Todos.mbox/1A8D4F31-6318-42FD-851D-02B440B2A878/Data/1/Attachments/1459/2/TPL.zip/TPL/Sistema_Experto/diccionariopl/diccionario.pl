esrespuesta('si').
esrespuesta('no').

%PREGUNTAS
espregunta('saludos?',X):-esrespuesta(X).
espregunta('despedidas?',X):-esrespuesta(X).
espregunta('preguntar por el nombre?',X):-esrespuesta(X).
espregunta('preguntar por la edad?',X):-esrespuesta(X).
espregunta('preguntar por la hora?',X):-esrespuesta(X).
espregunta('n�meros?',X):-esrespuesta(X).
espregunta('pronombres?',X):-esrespuesta(X).

%PRINCIPAL
espregunta('IDIOMA INGLES ?',X):-esrespuesta(X).
espregunta('IDIOMA ALEMAN ?',X):-esrespuesta(X).

main:-
        new(D,dialog('SISTEMA EXPERTO DE IDIOMAS')),
        send(D,size,size(960,900)),
        send(D,colour,colour(blue)),
        send(D, append, new(Menu, menu_bar)),
        send(Menu, append, new(Iniciar, popup(iniciar))),
        send(Menu, append, new(Creditos, popup(creditos))),
        send_list(Iniciar, append,
                         [ menu_item(iniciar, message(@prolog,pp))
                         ]),
        send_list(Creditos, append,
                         [ menu_item(autor, message(@display, inform, 'Virginia Sayde Guti�rrez Gonz�lez'))
                         ]),
        mostrar('C:/diccionariopl/brandenburgo.jpg',D,Menu),
        send(D,open,point(200,200)).

halt.qsave_program('c:/ejecutable.exe', [stand_alone(true), goal(main)]).

mostrar(V,D,M):- new(I, image(V)),
        new(B, bitmap(I)),
        new(F2, figure),
        send(F2, display, B),
        new(D1, device),
        send(D1, display, F2),
        send(D, display, D1),
        send(D1,below(M)).

pp:-new(D,dialog('IDIOMA')),
        new(Pre1,menu('IDIOMA INGLES ?')),
       send_list(Pre1,append,[si , no]),
        new(Pre2,menu('IDIOMA ALEMAN ?')),
        send_list(Pre2,append,[si,no]),
          send(D,append(Pre1)),
       send(D,append,Pre2),
      new(B,button(siguiente,and(message(@prolog,principal,Pre1?selection,Pre2?selection),message(D,destroy)))),
      send(D,append,B),
      send(D,default_button,siguiente),
        send(D,open,point(350,350)).

%PARA INGLES
principal(P1,P2):-
espregunta('IDIOMA INGLES ?',P1),P1='si',
espregunta('IDIOMA ALEMAN ?',P2),P2='no',
pi.

%PARA ALEMAN
principal(P1,P2):-
espregunta('IDIOMA INGLES ?',P1),P1='no',
espregunta('IDIOMA ALEMAN ?',P2),P2='si',
pal.

principal(_,_):-new(D,dialog('ERROR')),
new(L,label(l,'ELIJA SOLO UNA OPCION',font('times','roman',16))),
send(D,append,L),
send(D,open,point(350,350)).

pi:-new(D,dialog('PREGUNTAS')),
        new(Pre1,menu('saludos?')),
       send_list(Pre1,append,[si , no]),
        new(Pre2,menu('despedidas?')),
        send_list(Pre2,append,[si,no]),
        new(Pre3,menu('preguntar por el nombre?')),
        send_list(Pre3,append,[si,no]),
        new(Pre4,menu('preguntar por la edad?')),
        send_list(Pre4,append,[si,no]),
        new(Pre5,menu('preguntar por la hora?')),
       send_list(Pre5,append,[si,no]),
        new(Pre6,menu('n�meros?')),
         send_list(Pre6,append,[si,no]),
        new(Pre7,menu('pronombres?')),
         send_list(Pre7,append,[si,no]),
       send(D,append(Pre1)),
       send(D,append,Pre2),
       send(D,append,Pre3),
       send(D,append,Pre4),
       send(D,append,Pre5),
       send(D,append,Pre6),
       send(D,append(Pre7)),
       new(B1,button(atras,and(message(@prolog,pp),message(D,destroy)))),
                new(B,button(siguiente,message(@prolog,ingles,Pre1?selection,Pre2?selection,Pre3?selection,Pre4?selection,Pre5?selection,Pre6?selection,Pre7?selection))),
                 send(D,append,B1),
                send(D,append,B),
        send(D,open,point(300,300)).

ingles(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='si',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf01('C:/diccionariopl/saludosi.jpg','INGLES','C:/diccionariopl/eua.jpg').

ingles(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='si',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf02('C:/diccionariopl/despedidasi.jpg','INGLES','C:/diccionariopl/eua.jpg').

ingles(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='si',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf03('C:/diccionariopl/nombrei.jpg','INGLES','C:/diccionariopl/eua.jpg').

ingles(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='si',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf04('C:/diccionariopl/edadi.jpg','INGLES','C:/diccionariopl/eua.jpg').

ingles(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='si',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf05('C:/diccionariopl/horai.jpg','INGLES','C:/diccionariopl/eua.jpg').

ingles(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='si',
espregunta('pronombres?',P7),P7='no',
pf06('C:/diccionariopl/numerosi.jpg','INGLES','C:/diccionariopl/eua.jpg').

ingles(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='si',
pf07('C:/diccionariopl/pronombresi.jpg','INGLES','C:/diccionariopl/eua.jpg').

pal:-new(D,dialog('PREGUNTAS')),
        new(Pre1,menu('saludos?')),
       send_list(Pre1,append,[si , no]),
        new(Pre2,menu('despedidas?')),
        send_list(Pre2,append,[si,no]),
        new(Pre3,menu('preguntar por el nombre?')),
        send_list(Pre3,append,[si,no]),
        new(Pre4,menu('preguntar por la edad?')),
        send_list(Pre4,append,[si,no]),
        new(Pre5,menu('preguntar por la hora?')),
       send_list(Pre5,append,[si,no]),
        new(Pre6,menu('n�meros?')),
         send_list(Pre6,append,[si,no]),
        new(Pre7,menu('pronombres?')),
         send_list(Pre7,append,[si,no]),
       send(D,append(Pre1)),
       send(D,append,Pre2),
       send(D,append,Pre3),
       send(D,append,Pre4),
       send(D,append,Pre5),
       send(D,append,Pre6),
       send(D,append(Pre7)),
       new(B1,button(atras,and(message(@prolog,pp),message(D,destroy)))),
                new(B,button(siguiente,message(@prolog,aleman,Pre1?selection,Pre2?selection,Pre3?selection,Pre4?selection,Pre5?selection,Pre6?selection,Pre7?selection))),
                 send(D,append,B1),
                send(D,append,B),
        send(D,open,point(300,300)).

aleman(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='si',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf1('C:/diccionariopl/saludosa.jpg','ALEMAN','C:/diccionariopl/alemania.jpg').

aleman(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='si',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf2('C:/diccionariopl/despedidasa.jpg','ALEMAN','C:/diccionariopl/alemania.jpg').

aleman(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='si',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf3('C:/diccionariopl/nombrea.jpg','ALEMAN','C:/diccionariopl/alemania.jpg').

aleman(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='si',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf4('C:/diccionariopl/edada.jpg','ALEMAN','C:/diccionariopl/alemania.jpg').

aleman(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='si',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='no',
pf5('C:/diccionariopl/horaa.jpg','ALEMAN','C:/diccionariopl/alemania.jpg').

aleman(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='si',
espregunta('pronombres?',P7),P7='no',
pf6('C:/diccionariopl/numerosa.jpg','ALEMAN','C:/diccionariopl/alemania.jpg').

aleman(P1,P2,P3,P4,P5,P6,P7):-
espregunta('saludos?',P1),P1='no',
espregunta('despedidas?',P2),P2='no',
espregunta('preguntar por el nombre?',P3),P3='no',
espregunta('preguntar por la edad?',P4),P4='no',
espregunta('preguntar por la hora?',P5),P5='no',
espregunta('n�meros?',P6),P6='no',
espregunta('pronombres?',P7),P7='si',
pf7('C:/diccionariopl/pronombresa.jpg','ALEMAN','C:/diccionariopl/alemania.jpg').

image(X):-new(D,dialog('TRADUCTOR')),
        mostrar1(X,D),
%       new(B,label(salir,message(D,destroy))),
        %send(D,append,B),
        send(D,open).

mostrar1(V,D):- new(I, image(V)),
        new(B, bitmap(I)),
        new(F2, figure),
        send(F2, display, B),
        new(D1, device),
        send(D1, display, F2),
        send(D, display, D1).

pf1(X,Y,Z):-new(D,dialog('SALUDOS EN ALEMAN')),
          mostrar2(X,D,20,30),
           new(L,label(n,'SALUDOS')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf2(X,Y,Z):-new(D,dialog('DESPEDIDAS EN ALEMAN')),
          mostrar2(X,D,20,30),
           new(L,label(n,'DESPEDIDAS')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf3(X,Y,Z):-new(D,dialog('PREGUNTAR POR EL NOMBRE EN ALEMAN')),
          mostrar2(X,D,20,30),
           new(L,label(n,'PREGUNTAR POR EL NOMBRE')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf4(X,Y,Z):-new(D,dialog('PREGUNTAR POR LA EDAD EN ALEMAN')),
          mostrar2(X,D,20,30),
           new(L,label(n,'PREGUNTAR POR LA EDAD')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf5(X,Y,Z):-new(D,dialog('PREGUNTAR POR LA HORA EN ALEMAN')),
          mostrar2(X,D,70,80),
           new(L,label(n,'PREGUNTAR POR LA HORA')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,60,450),
         send(D,open).

pf6(X,Y,Z):-new(D,dialog('NUMEROS EN ALEMAN')),
          mostrar2(X,D,20,30),
           new(L,label(n,'NUMEROS')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,50,550),
         send(D,open).

pf7(X,Y,Z):-new(D,dialog('PRONOMBRES EN ALEMAN')),
          mostrar2(X,D,20,30),
           new(L,label(n,'PRONOMBRES')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,40,550),
         send(D,open).

pf01(X,Y,Z):-new(D,dialog('SALUDOS EN INGLES')),
          mostrar2(X,D,20,30),
           new(L,label(n,'SALUDOS')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,40,550),
         send(D,open).

pf02(X,Y,Z):-new(D,dialog('DESPEDIDAS EN INGLES')),
          mostrar2(X,D,20,30),
           new(L,label(n,'DESPEDIDAS')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,40,450),
         send(D,open).

pf03(X,Y,Z):-new(D,dialog('PREGUNTAR POR EL NOMBRE EN INGLES')),
          mostrar2(X,D,20,30),
           new(L,label(n,'PREGUNTAR POR EL NOMBRE')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf04(X,Y,Z):-new(D,dialog('PREGUNTAR POR LA EDAD EN INGLES')),
          mostrar2(X,D,20,30),
           new(L,label(n,'PREGUNTAR POR LA EDAD')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf05(X,Y,Z):-new(D,dialog('PREGUNTAR POR LA HORA EN INGLES')),
          mostrar2(X,D,20,30),
           new(L,label(n,'PREGUNTAR POR LA HORA')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf06(X,Y,Z):-new(D,dialog('NUMEROS EN INGLES')),
          mostrar2(X,D,20,30),
           new(L,label(n,'NUMEROS')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,20,350),
         send(D,open).

pf07(X,Y,Z):-new(D,dialog('PRONOMBRES EN INGLES')),
          mostrar2(X,D,20,30),
           new(L,label(n,'PRONOMBRES')),
          send(D, append(label(n,'TRADUCCION'))),
    send(D, append(label(n,'ESPA�OL'))),
         send(D, append(label(n,Y))),
          send(D,append,L),
           mostrar2(Z,D,30,450),
         send(D,open).

mostrar(V,D):- new(I, image(V)),
        new(B, bitmap(I)),
        new(F2, figure),
        send(F2, display, B),
        new(D1, device),
        send(D1, display, F2),
        send(D, display, D1).

mostrar2(V,D,X,Y):- new(I, image(V)),
        new(B, bitmap(I)),
        new(F2, figure),
        send(F2, display, B),
        new(D1, device),
        send(D1, display, F2),
        send(D, display, D1),
        send(D,display,D1,point(X,Y)).
