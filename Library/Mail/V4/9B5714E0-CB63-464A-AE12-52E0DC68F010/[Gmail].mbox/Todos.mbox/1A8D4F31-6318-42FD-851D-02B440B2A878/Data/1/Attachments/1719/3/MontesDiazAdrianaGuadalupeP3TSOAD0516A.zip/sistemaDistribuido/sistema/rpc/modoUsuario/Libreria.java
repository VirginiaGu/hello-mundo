/*
 * Pr�ctica #3: 
 * Llamadas a Procedimientos Remotos (RPC) 
 * �Resguardos del Cliente y del Servidor� 
 * @author: Adriana Guadalupe Montes D�az
 * @code: 210224063
 */

package sistemaDistribuido.sistema.rpc.modoUsuario;

import java.util.Stack;

import sistemaDistribuido.util.Escribano;

public abstract class Libreria{
	private Escribano esc;
	Stack stack;

	/**
	 * 
	 */
	public Libreria(Escribano esc){
		this.esc=esc;
		stack = new Stack();
	}

	/**
	 * 
	 */
	protected void imprime(String s){
		esc.imprime(s);
	}

	/**
	 * 
	 */
	protected void imprimeln(String s){
		esc.imprimeln(s);
	}

	/**
	 * Ejemplo para el paso intermedio de parametros en pila.
	 * Esto es lo que esta disponible como interfaz al usuario programador
	 */
	/*public int suma(int sum1,int sum2){
    //...
    suma();
    //...
    return 0;
  }*/
	
	public int cube(int side) {
		stack.push(side);
		cube();
		return (Integer) stack.pop();
	}
	
	public int factorial(int number) {
		stack.push(number);
		factorial();
		return (Integer) stack.pop();
	}
	
	public int pow(int base, int exp) {
		stack.push(base);
		stack.push(exp);
		pow();
		return (Integer) stack.pop();
	}
	
	public int min(int[] list) {
		for(int i = 0; i < list.length; i++) {
			stack.push(list[i]);
		}
		min();
		return (Integer) stack.pop();
	}

	public int suma(int sum1,int sum2){
		return sum1+sum2;
	}

	public int resta(int minuendo,int sustraendo){
		return minuendo-sustraendo;
	}

	public int multiplicacion(int multiplicando,int multiplicador){
		return multiplicando*multiplicador;
	}

	public int division(int dividendo,int divisor){
		return dividendo/divisor;
	}

	/**
	 * Servidor suma verdadera generable por un compilador estandar
	 * o resguardo de la misma por un compilador de resguardos.
	 */
	protected abstract void suma();
	protected abstract void cube();
	protected abstract void factorial();
	protected abstract void pow();
	protected abstract void min();
}