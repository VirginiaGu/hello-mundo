//*Nombre: Virginia Sayde Guti�rrez Gonz�lez
//*Secci�n: D01
//*Tarea Java#6: Paso de parametros 

public class Proceso {
	private void valor(int a,int b){
		a= b+a;	
		b=7;
		System.out.print("\nProceso por paso de valor: "+a+"\t"+b);
	}//valor
	
	public void referencia(int ar[], int b[]){
		for(int i=0; i<ar.length; i++){
			ar[i]=b[i]+ar[i];
			System.out.print("\nProceso por referencia:\t"+ar[i]);
		}//for
		for(int i=0; i<b.length; i++){
			b[i]=ar[i]+b[i];
			System.out.print("\t"+b[i]);
		}//for
	}//referencia
	
     public static void main(String[]args){
    	 Proceso p= new Proceso();
    	 int a=8;
    	 int ar[]=new int[1];
    	 ar[0]=a;
    	 System.out.print("Antes del paso de valor: "+a);
    	 p.valor(a,a);
    	 System.out.print("\nDespues del paso de valor: "+a);
    	 System.out.print("\n");
    	 System.out.print("\nAntes del paso por referencia: "+ar[0]);
    	 p.referencia(ar, ar);
    	 System.out.print("\nDespues del paso por referencia: "+ar[0]);
     }//main
}//clase proceso