/*
 * PRACTICA 1
 * @author: Adriana Guadalupe Montes D�az
 */
package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class TextFile {
	static File file;
	String text;
	
	public TextFile(String name) {
		file = new File(name);
		text = "";
	}
	
	public String getText() {
		return text;
	}
	
	public boolean read() {
		String line;
		try {
			Scanner scanner = new Scanner(file);
			while(scanner.hasNextLine()){
				line = scanner.nextLine();
				
				if(scanner.hasNextLine()){
					text += line +"\n";
				} else {
					text += line;
				}
			}
			scanner.close();
			return true;
		} catch (FileNotFoundException e) {}
		return false;
	}
	
	public boolean delete() {
		try {
			if(file.delete()) {
				return true;
			}
		} catch (Exception e) {}
		return false;
	}
	
	public boolean write(String content){
		FileWriter filewritter;
		
		try {
			filewritter = new FileWriter (file);
			filewritter.write(content);
			filewritter.close();
			return true;
		} catch (IOException e) {}
		return false;
	}
}
