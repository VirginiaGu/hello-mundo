/*
 * Pr�ctica #3: 
 * Llamadas a Procedimientos Remotos (RPC) 
 * �Resguardos del Cliente y del Servidor� 
 * @author: Adriana Guadalupe Montes D�az
 * @code: 210224063
 */

package sistemaDistribuido.sistema.rpc.modoUsuario;

import java.util.Arrays;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import sistemaDistribuido.sistema.rpc.modoUsuario.Libreria;
import sistemaDistribuido.util.Escribano;

public class LibreriaServidor extends Libreria{

	/**
	 * 
	 */
	public LibreriaServidor(Escribano esc){
		super(esc);
	}

	/**
	 * Ejemplo de servidor suma verdadera
	 */
	protected void suma(){
		//saca parametros de pila

		//devuelve valor izquierdo
	}

	@Override
	protected void cube() {
		// TODO Auto-generated method stub
		int param = (Integer) stack.pop();
		int result = param*param*param;
		stack.push(result);
	}

	@Override
	protected void factorial() {
		// TODO Auto-generated method stub
		int param = (Integer) stack.pop();
		int result = 1;
		while (param != 0) {
			result = result*param;
			  param--;
		}
		stack.push(result);
	}

	@Override
	protected void pow() {
		// TODO Auto-generated method stub
		int exp = (Integer) stack.pop();
		int base = (Integer) stack.pop();
		
		int result = (int) Math.pow(base, exp);
		stack.push(result);
	}

	@Override
	protected void min() {
		// TODO Auto-generated method stub
		int[] list = new int[(stack.size())];
		int i = stack.size();
		
		for(int j = 0; i > 0; i--) {
			list[j] = (Integer)stack.pop();
			j++;
		}
	
		Arrays.sort(list);
		stack.push(list[0]);
	}
	
	
}