/*Nombre: Virginia Sayde Gutierrez Gonzalez
 *Seccion: D01
 *Tarea Java #5: Manejo de eventos
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Ventana extends JFrame implements ActionListener{
	JButton b1,b2,b3;
	JTextField t1;
	JLabel l1;
  
	 public  Ventana (){
	     b1 = new JButton("Copiar texto");
	     this.getContentPane().add(b1,BorderLayout.SOUTH);
	     b1.addActionListener(this);
	     b2 = new JButton("Borrar contenido");
	     this.getContentPane().add(b2,BorderLayout.EAST);
	     b2.addActionListener(this);
	     b3 = new JButton("Color");
	     this.getContentPane().add(b3,BorderLayout.WEST);
	     b3.addActionListener(this);
	     t1 = new JTextField();
	     this.getContentPane().add(t1,BorderLayout.NORTH);
	     l1 = new JLabel("");
	     this.getContentPane().add(l1,BorderLayout.CENTER);
	 }//ventana
	 
	 public void actionPerformed(ActionEvent ae){
		 if(ae.getSource()==b1){
			 String dato;
			 dato= this.t1.getText();
			 this.l1.setText(dato);
		 }//if	 
		 if(ae.getSource()==b2){
			 this.t1.setText("");
			 this.l1.setText("");
		 }//if
		 if(ae.getSource()==b3){
			 b3.setBackground(Color.green);
			 b3.setForeground(Color.blue);
		 }//if
	 }//actionPerformed     
	     public static void main(String []args){	   
	   	  Ventana v = new Ventana();
	   	  v.setSize(790,590); 
	   	  v.setVisible(true);
	   	  v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	   }//main 	     
}//clase Ventana
