//*Nombre: Virginia Sayde Guti�rrez Gonz�lez
//*Secci�n: D01
//*Tarea#8: Clase administradora de objetos

import java.awt.*;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.JOptionPane;

public class ClaseAdministradora extends javax.swing.JFrame {
    int contador =5;
    Hashtable<String,String> contenedor=new Hashtable<String,String>();
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtClave;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextArea txtImprimir;
    private javax.swing.JTextField txtMateria;
    
    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setTitle("CLASE ADMINISTRADORA");
    	jScrollPane1 = new javax.swing.JScrollPane();
        txtImprimir = new javax.swing.JTextArea();
        txtImprimir.setBackground(Color.cyan);
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtClave = new javax.swing.JTextField();
        txtMateria = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        btnAgregar.setBackground(Color.blue); 
        txtID = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnBuscar.setBackground(Color.blue); 
        btnEliminar = new javax.swing.JButton();
        btnEliminar.setBackground(Color.blue); 
        txtImprimir.setColumns(10);
        txtImprimir.setRows(5);
        jScrollPane1.setViewportView(txtImprimir);
        jLabel1.setText("Clave de la materia:");
        jLabel2.setText("Nombre de la materia:");
        jLabel3.setText("ID:");
        btnAgregar.setText("Registrar materia");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar materia");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar materia");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup().addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE,300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup().addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup().addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnAgregar)
                                .addComponent(txtMateria)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txtClave, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(10, 10, 10)));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtClave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtMateria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))        
                        .addComponent(btnAgregar).addGap(41, 41, 41)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup().addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(jLabel3)
                                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBuscar).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnEliminar))))).addContainerGap(5, Short.MAX_VALUE)));
                                 pack();
   }
    
    public ClaseAdministradora() {
        initComponents();  
        contenedor.put("1","|CC317|COMPILADORES");
        contenedor.put("2","|CC318|TALLER DE COMPILADORES");
        contenedor.put("3","|CC319|SISTEMAS OPERATIVOS AVANZADOS");
        contenedor.put("4","|CC320|TALLER DE SISTEMAS OPERATIVOS AVANZADOS");
        imprimir(contenedor);
        txtImprimir.setEditable(false);
    }

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {
        String i= Integer.toString(contador);
        String info = "|"+txtClave.getText()+"|"+txtMateria.getText();
        contenedor.put(i, info);
        contador++;
        txtClave.setText("");
        txtMateria.setText("");
        imprimir(contenedor);
    }

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        String buscado = txtID.getText();
        if(contenedor.get(buscado) != null)
        {
            String aux = contenedor.get(buscado);
            buscado = "ID|Clave|Nombre Materia\n" + buscado+aux;
            txtID.setText("");
            JOptionPane.showMessageDialog(null, buscado,"Busqueda", JOptionPane.INFORMATION_MESSAGE);
        } 
        else 
        {
            txtID.setText("");
            JOptionPane.showMessageDialog(null, "Materia no Encontrada",":(", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {
        String eliminado = txtID.getText();
        if(contenedor.get(eliminado) != null)
        {
            contenedor.remove(eliminado);
            JOptionPane.showMessageDialog(null, "Materia Eliminada",":(", JOptionPane.INFORMATION_MESSAGE);
            txtID.setText("");
            imprimir(contenedor);
        }
        else
        {
            txtID.setText("");
           JOptionPane.showMessageDialog(null, "Materia no Encontrada",":(", JOptionPane.INFORMATION_MESSAGE); 
        }
    }

    public void imprimir(Hashtable contenedor){
        txtImprimir.setText("");
        Enumeration<String> enumeration = contenedor.elements();
        Enumeration<String> llaves = contenedor.keys();
        String datos = "ID|Clave|Nombre Materia\n";
        while(enumeration.hasMoreElements() && llaves.hasMoreElements())
        {
            datos = datos + llaves.nextElement()+enumeration.nextElement()+"\n"; 
        }
        txtImprimir.setText(datos);
    }
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClaseAdministradora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClaseAdministradora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClaseAdministradora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClaseAdministradora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex); }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClaseAdministradora().setVisible(true);
            }
        });      
    }
}
