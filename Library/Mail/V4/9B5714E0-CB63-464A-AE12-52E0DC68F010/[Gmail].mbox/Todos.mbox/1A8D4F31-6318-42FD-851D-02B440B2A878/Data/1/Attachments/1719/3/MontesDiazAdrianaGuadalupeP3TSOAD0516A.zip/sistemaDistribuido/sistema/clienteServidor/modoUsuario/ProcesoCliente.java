/*
 * Pr�ctica #2: Modelo Cliente / Servidor 
 * Administraci�n de Procesos y Mecanismo de Comunicaci�n B�sico 
 * @author: Adriana Guadalupe Montes D�az
 */


package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 */
public class ProcesoCliente extends Proceso{
	final int MESSAGE_LENGTH = 1024;
	final int CONTENT_LENGTH = 1014;
	final int BITS_X_SHORT = 2;
	final  int BITS_X_BYTE = 8;
	final int BYTES_X_INT = 4;
	String message;
	String[] array;
	
	static byte[] file_content;
	byte[] aux;
	byte[] file_name;
	byte[] file_content_length;
	byte[] file_name_length;
	byte[] code_operation;
	byte[] solCliente;

	/**
	 * 
	 */
	public ProcesoCliente(Escribano esc) {
		super(esc);
		start();
		message = "";
		aux = new byte[CONTENT_LENGTH];
		solCliente=new byte[MESSAGE_LENGTH];
		file_content_length = convertToByte(0);
		file_name_length = convertToByte(0);
		code_operation = null;
	}
	
	/**
	 * 
	 */
	public String getMessage() {
		return message;
	}
	
	public static int convertToInteger(byte[] array) {
		int number = 0;
		for(int i = 0; i < array.length; i++) {
			number +=(int)((array[i] & 0xFF)<<(i*8));
		}
		return number;
	}
	
	public byte[] convertToByte(int decimal) {
		byte[] result = new byte[BYTES_X_INT];
		
		for(int i = 0; i < BYTES_X_INT; i++) {
			result[i] = (byte) ((decimal >> (BITS_X_BYTE*i))& 0xFF);
		}
		return result;
	}
	
	public byte[] convertToByte(short decimal) {
		byte[] result = new byte[BITS_X_SHORT];
		
		for(int i = 0; i < BITS_X_SHORT; i++) {
			result[i] = (byte) ((decimal >> (BITS_X_BYTE*i))& 0xFF);
		}
		return result;
	}
	
	public static String convertToString(byte[] array) {
		String text = "";
		for(int i = 0; i < array.length; i++) {
			text += (char)array[i];
		}
		return text;
	}
	
	public byte[] getCodeOperation() {
		if(array.length > 0) {
			return convertToByte((short)Short.parseShort(array[0]));
		}
		return null;
	}
	
	public byte[] getFileName() {
		if(array.length > 1) {
			return array[1].getBytes();
		}
		return null;
	}
	
	public byte[] getFileContent() {
		if(array.length > 2) {
			return array[2].getBytes();
		}
		return null;
	}
	
	public byte[] getLength(byte[] arra) {
		if(arra != null) {
			return convertToByte(arra.length+BYTES_X_INT);
		}
		return null;
	}
	
	public void setMessage(String message) {
		this.message = message;
		array = message.split("[|]");
	}
	
	public void setRequest() {
		array = message.split("[|]");
		code_operation = getCodeOperation();
		System.arraycopy(code_operation, 0, aux, 0, BITS_X_SHORT);
		
		file_name = getFileName();
		if(file_name != null) {
			file_name_length = getLength(file_name);
			System.arraycopy(file_name_length, 0, aux, 2, BYTES_X_INT);
			System.arraycopy(file_name, 0, aux, 6, file_name.length);
			
			file_content = getFileContent();
			if(file_content !=  null) {
				file_content_length = getLength(file_content);
				System.arraycopy(file_content_length, 0, aux, file_name.length+6, BYTES_X_INT);
				System.arraycopy(file_content, 0, aux, file_name.length+10, file_content.length);
			}
		}
		
		System.arraycopy(aux, 0, solCliente, 8, aux.length);
	}
	
	public String getResponse(byte[] array) {
		String response = "";
		if(array.length > 8) {
			byte[] size = {
				array[8],
				array[9],
				array[10],
				array[11]
			};
			int length = convertToInteger(size);
			
			for(int i = 12; i < (length+8); i++) {
				response += ((char)array[i]);
			}
			
		}
		return response;
	}

	/**
	 * 
	 */
	public void run(){
		imprimeln("Proceso cliente en ejecucion.");
		imprimeln("Esperando datos para continuar.");
		Nucleo.suspenderProceso();

		//byte[] solCliente=new byte[MESSAGE_LENGTH];
		byte[] respCliente=new byte[MESSAGE_LENGTH];
		imprimeln("Generando solicitud a ser enviada, llenando los campos necesarios");
		setRequest();
		
		Nucleo.send(248,solCliente);
		Nucleo.receive(dameID(),respCliente);
		imprimeln("Procesando respuesta recibida del servidor");
		String response = getResponse(respCliente);
		imprimeln("Respuesta del Servidor : "+response);
	}
}
