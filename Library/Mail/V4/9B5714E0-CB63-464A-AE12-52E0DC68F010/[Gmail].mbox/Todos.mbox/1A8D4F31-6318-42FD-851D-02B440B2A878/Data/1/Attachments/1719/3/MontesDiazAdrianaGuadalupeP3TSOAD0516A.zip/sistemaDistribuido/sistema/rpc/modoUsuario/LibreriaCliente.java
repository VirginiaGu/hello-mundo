/*
 * Pr�ctica #3: 
 * Llamadas a Procedimientos Remotos (RPC) 
 * �Resguardos del Cliente y del Servidor� 
 * @author: Adriana Guadalupe Montes D�az
 * @code: 210224063
 */

package sistemaDistribuido.sistema.rpc.modoUsuario;

//import sistemaDistribuido.sistema.rpc.modoMonitor.RPC;  //para pr�ctica 4
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.rpc.modoUsuario.Libreria;
import sistemaDistribuido.util.Escribano;

public class LibreriaCliente extends Libreria{
	final int MESSAGE_LENGTH = 1024;
	final int BYTES_X_SHORT = 2;
	final int BITS_X_BYTE = 8;
	final int BYTES_X_INT = 4;
	final short CUBE = 11;
	final short FACTORIAL = 12;
	final short POW = 13;
	final short MIN = 14;
	/**
	 * 
	 */
	public LibreriaCliente(Escribano esc){
		super(esc);
	}
	
	protected byte[] convertToByte(int decimal) {
		byte[] result = new byte[BYTES_X_INT];
		
		for(int i = 0; i < BYTES_X_INT; i++) {
			result[i] = (byte) ((decimal >> (BITS_X_BYTE*i))& 0xFF);
		}
		return result;
	}
	
	protected byte[] convertToByte(short decimal) {
		byte[] result = new byte[BYTES_X_SHORT];
		
		for(int i = 0; i < BYTES_X_SHORT; i++) {
			result[i] = (byte) ((decimal >> (BITS_X_BYTE*i))& 0xFF);
		}
		return result;
	}
	
	protected int convertToInteger(byte[] array) {
		int number = 0;
		for(int i = 0; i < array.length; i++) {
			number +=(int)((array[i] & 0xFF)<<(i*8));
		}
		return number;
	}

	/**
	 * Ejemplo de resguardo del cliente suma
	 */
	protected void suma(){
		int asaDest=0;
		//...

		//asaDest=RPC.importarInterfaz(nombreServidor, version)  //para pr�ctica 4
		Nucleo.send(asaDest,null);
		//...
	}

	@Override
	protected void cube() {
		int  side = (Integer) stack.pop();

		byte[] solCliente = new byte[MESSAGE_LENGTH];
		byte[] resCliente = new byte[MESSAGE_LENGTH];
		byte[] operation = convertToByte(CUBE);
		byte[] param = convertToByte(side);
		
		System.arraycopy(operation, 0, solCliente, 8, BYTES_X_SHORT);
		System.arraycopy(param, 0, solCliente, 10, BYTES_X_INT);
		
		Nucleo.send(248, solCliente);
		Nucleo.receive(Nucleo.dameIdProceso(), resCliente);
		
		byte[] aux = {
				resCliente[10],
				resCliente[11],
				resCliente[12],
				resCliente[13]
		};
		int result = convertToInteger(aux);
		
		stack.push(result);
	}

	@Override
	protected void factorial() {
		int number = (Integer) stack.pop();
		
		byte[] solCliente = new byte[MESSAGE_LENGTH];
		byte[] resCliente = new byte[MESSAGE_LENGTH];
		byte[] operation = convertToByte(FACTORIAL);
		byte[] param = convertToByte(number);
		
		System.arraycopy(operation, 0, solCliente, 8, BYTES_X_SHORT);
		System.arraycopy(param, 0, solCliente, 10, BYTES_X_INT);
		
		Nucleo.send(248, solCliente);
		Nucleo.receive(Nucleo.dameIdProceso(), resCliente);
		
		byte[] aux = {
				resCliente[10],
				resCliente[11],
				resCliente[12],
				resCliente[13]
		};
		int result = convertToInteger(aux);
		
		stack.push(result);
	}

	@Override
	protected void pow() {
		int exp = (Integer) stack.pop();
		int base = (Integer) stack.pop();
		
		byte[] solCliente = new byte[MESSAGE_LENGTH];
		byte[] resCliente = new byte[MESSAGE_LENGTH];
		byte[] operation = convertToByte(POW);
		byte[] param1 = convertToByte(exp);
		byte[] param2 = convertToByte(base);
		
		System.arraycopy(operation, 0, solCliente, 8, BYTES_X_SHORT);
		System.arraycopy(param1, 0, solCliente, 10, BYTES_X_INT);
		System.arraycopy(param2, 0, solCliente, 14, BYTES_X_INT);
		
		Nucleo.send(248, solCliente);
		Nucleo.receive(Nucleo.dameIdProceso(), resCliente);
		
		byte[] aux = {
				resCliente[10],
				resCliente[11],
				resCliente[12],
				resCliente[13]
		};
		int result = convertToInteger(aux);
		
		stack.push(result);
	}

	@Override
	protected void min() {
		// TODO Auto-generated method stub
		int size = stack.size();
		
		byte[] solCliente = new byte[MESSAGE_LENGTH];
		byte[] resCliente = new byte[MESSAGE_LENGTH];
		byte[] operation = convertToByte(MIN);
		byte[] count = convertToByte(size);
		
		System.arraycopy(operation, 0, solCliente, 8, BYTES_X_SHORT);
		System.arraycopy(count, 0, solCliente, 10, BYTES_X_INT);
		
		for(int i = 0; i < size; i++) {
			byte[] param = convertToByte((Integer)stack.pop());
			System.arraycopy(param, 0, solCliente, (14+(i*4)), BYTES_X_INT);
		}
		
		Nucleo.send(248, solCliente);
		Nucleo.receive(Nucleo.dameIdProceso(), resCliente);
		
		byte[] aux = {
				resCliente[10],
				resCliente[11],
				resCliente[12],
				resCliente[13]
		};
		int result = convertToInteger(aux);
		
		stack.push(result);
		
	}
	
	
}