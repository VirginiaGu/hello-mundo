/*
 * Pr�ctica #2: Modelo Cliente / Servidor 
 * Administraci�n de Procesos y Mecanismo de Comunicaci�n B�sico 
 * @author: Adriana Guadalupe Montes D�az
 */

package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Hashtable;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.MicroNucleoBase;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;

/**
 * 
 */
public final class MicroNucleo extends MicroNucleoBase{
	final int MESSAGE_LENGTH = 1024;
	private static MicroNucleo nucleo=new MicroNucleo();
	Hashtable <Integer,Par>table_emission;
	Hashtable <Integer,byte[]>table_reception;

	/**
	 * 
	 */
	MicroNucleo(){
		table_emission = new Hashtable <Integer,Par>();
		table_reception = new Hashtable <Integer,byte[]>();
	}

	/**
	 * 
	 */
	public final static MicroNucleo obtenerMicroNucleo(){
		return nucleo;
	}

	/*---Metodos para probar el paso de mensajes entre los procesos cliente y servidor en ausencia de datagramas.
    Esta es una forma incorrecta de programacion "por uso de variables globales" (en este caso atributos de clase)
    ya que, para empezar, no se usan ambos parametros en los metodos y fallaria si dos procesos invocaran
    simultaneamente a receiveFalso() al reescriir el atributo mensaje---*/
	byte[] mensaje;

	public void sendFalso(int dest,byte[] message){
		System.arraycopy(message,0,mensaje,0,message.length);
		notificarHilos();  //Reanuda la ejecucion del proceso que haya invocado a receiveFalso()
	}

	public void receiveFalso(int addr,byte[] message){
		mensaje=message;
		suspenderProceso();
	}
	/*---------------------------------------------------------*/

	/**
	 * 
	 */
	protected boolean iniciarModulos(){
		return true;
	}

	/**
	 * 
	 */
	protected void sendVerdadero(int dest,byte[] message){
		//sendFalso(dest,message);
		imprimeln("El proceso invocante es el "+super.dameIdProceso());
		
		imprimeln("Buscando en listas locales el par (m�quina, proceso) que corresponde al par�metro dest de la llamada a send");
		ParMaquinaProceso pmp = table_emission.get(dest);
		
		//lo siguiente aplica para la pr�ctica #2
		if(pmp == null) {
			imprimeln("Enviando mensaje de b�squeda del servidor");
			pmp=dameDestinatarioDesdeInterfaz();
			imprimeln("Recibido mensaje que contiene la ubicaci�n (m�quina, proceso) del servidor");
		}
		imprimeln("Completando campos de encabezado del mensaje a ser enviado");
		message[1] = (byte)super.dameIdProceso();
		message[4] = (byte)pmp.dameID();
		
		try {
			DatagramPacket dp = new DatagramPacket(message,message.length,InetAddress.getByName(pmp.dameIP()),damePuertoRecepcion());
			DatagramSocket ds=dameSocketEmision();
			ds.send(dp);
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		imprimeln("Enviando mensaje a IP="+pmp.dameIP()+" ID="+pmp.dameID());
		imprimeln("Enviando mensaje por la red");
		//suspenderProceso();   //esta invocacion depende de si se requiere bloquear al hilo de control invocador
	}

	/**
	 * 
	 */
	protected void receiveVerdadero(int addr,byte[] message){
		//receiveFalso(addr,message);
		table_reception.put(addr,message);
		//el siguiente aplica para la pr�ctica #2
		suspenderProceso();
	}

	/**
	 * Para el(la) encargad@ de direccionamiento por servidor de nombres en pr�ctica 5  
	 */
	protected void sendVerdadero(String dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void sendNBVerdadero(int dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void receiveNBVerdadero(int addr,byte[] message){
	}

	/**
	 * 
	 */
	public void run(){
		byte[] array = new byte[MESSAGE_LENGTH];
		DatagramPacket dp = new DatagramPacket(array,array.length);
		DatagramSocket socket = dameSocketRecepcion();
		
		while(seguirEsperandoDatagramas()){
			/* Lo siguiente es reemplazable en la pr�ctica #2,
			 * sin esto, en pr�ctica #1, seg�n el JRE, puede incrementar el uso de CPU
			 */ 
			try {
				socket.receive(dp);
				imprimeln("Recibido mensaje proveniente de la red");
				int origin = (int)array[1];
				int dest = (int)array[4];
				String ip = dp.getAddress().getHostAddress();
				imprimeln("IP="+ip+" ID="+dest);
				imprimeln("Buscando proceso correspondiente al campo dest del mensaje recibido");
				Proceso process = dameProcesoLocal(dest);
				byte[] miau;
				if(process != null) {
					if(array[8] == -100) {
						reanudarProceso(process); 
					} else {
						byte[] dato = table_reception.get(dest);
						
						if(dato != null) {
							table_reception.remove(dest);
							Par table = new Par(origin, ip);
							table_emission.put(origin, table);
							imprimeln("Copiando el mensaje hacia el espacio del proceso");
							System.arraycopy(array,0,dato,0,dato.length);
							reanudarProceso(process); 
						} else {
							//TA
							imprimeln("Intenta m�s tarde");
						}
					}
				} else {
					//AU
					imprimeln("Proceso destinatario no encontrado seg�n campo dest del mensaje recibido");
					miau = new byte[9];
					miau[1] = (byte) origin;
					miau[4] = (byte) dest;
					miau[8] = (byte) -100;
					
					//DatagramPacket dpmiau = new DatagramPacket(array,array.length);
					//DatagramSocket socket = dameSocketRecepcion();
				}

				/*
				try{
					sleep(60000);
				}catch(InterruptedException e){
					System.out.println("InterruptedException");
				}
				*/
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
	}
}
