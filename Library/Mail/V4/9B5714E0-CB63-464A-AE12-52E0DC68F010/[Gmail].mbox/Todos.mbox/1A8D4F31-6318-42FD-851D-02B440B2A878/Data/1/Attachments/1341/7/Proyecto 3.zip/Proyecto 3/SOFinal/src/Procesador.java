import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.Timer;

import java.lang.*;

public class Procesador extends JFrame implements ActionListener{

	String[] titulos={"Proceso","Tama�o","Prioridad","Error","Bloqueo","Contbloq"};
	String t="";
	int cantInstrucciones, cantProcesos, cantDatos, primInst, primDat, quantum=0;
	int Estado=1, Memoria[][];

	
	
	Proceso Proceso = new Proceso();
	Nuevos Nuevo = new Nuevos();
	Listos Listo = new Listos();
	Ejecucion Ejecucion= new Ejecucion();
	Bloqueados Bloqueado = new Bloqueados();
	Terminados Terminado = new Terminados();
	
	Vector<Proceso> ListadeProcesos = new Vector<Proceso>();
	
	Timer timer = new Timer (1000, new ActionListener () 
	{ 
	    public void actionPerformed(ActionEvent e) 
	    { 
	        Ejecutar();
	     } 
	});
	
	JPanel contentPane;
	JTable table = new JTable();
	DefaultTableModel tabla;
	JFileChooser buscador = new JFileChooser();
	
	JButton btnAbrir = new JButton("");
	ImageIcon abrir=new ImageIcon("abrir.jpg");
	
	JButton btnEjecutar = new JButton("");
	ImageIcon ejecutar=new ImageIcon("ejecutar.jpg");
	
	JToolBar toolBar= new JToolBar();
	
	
	public Procesador(){
		super("\tProcesador");
				
		buscador.setDialogTitle("Abrir Documento");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0,0,370,300);

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		setContentPane(contentPane);
		
		table.setModel(new DefaultTableModel(new Object[][] {},titulos));
		
		tabla=(DefaultTableModel) table.getModel();
		
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
		contentPane.add(toolBar, BorderLayout.NORTH);
		
		btnAbrir.setToolTipText("Abrir");
		btnAbrir.setIcon(abrir);
		btnAbrir.addActionListener(this);
		
		btnEjecutar.setToolTipText("Ejecutar");
		btnEjecutar.setIcon(ejecutar);
		btnEjecutar.addActionListener(this);
		
		toolBar.add(btnAbrir);
		toolBar.add(btnEjecutar);
		
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnAbrir){
			Abrir();
		}
		if(e.getSource()==btnEjecutar){
			timer.start();
		}
	}
	
	public void Abrir(){
			
		int x = buscador.showDialog(null,"Abrir");
		if(x==buscador.APPROVE_OPTION){
			while(0<tabla.getRowCount())
				tabla.removeRow(0);
				
				t = buscador.getSelectedFile().getAbsolutePath();
				leer(t);
				Mostrar();
			}
		
		Nuevo.setVisible(true);
		Listo.setVisible(true);
		Ejecucion.setVisible(true);
		Bloqueado.setVisible(true);
		Terminado.setVisible(true);
		
		}
	

	
	
	public void leer(String ruta){
		
		try{
			File f = new File(ruta);
			String linea="";
			int i=0;
			Scanner s = new Scanner(f);
			cantProcesos=Integer.parseInt(s.nextLine());
			
			StringTokenizer st;
			st = new StringTokenizer(s.nextLine(),":");
			cantInstrucciones=Integer.parseInt(st.nextToken());
			primInst=Integer.parseInt(st.nextToken());
			
			st = new StringTokenizer(s.nextLine(),":");
			cantDatos=Integer.parseInt(st.nextToken());
			primDat=Integer.parseInt(st.nextToken());
			
			for(int v=0; v<cantProcesos; v++){
				linea = s.nextLine();
				if(!linea.isEmpty()){
					
					st = new StringTokenizer(linea,":");
					Proceso.ID=st.nextToken();
					Proceso.tama�o=Integer.parseInt(st.nextToken());
					Proceso.prioridad=Integer.parseInt(st.nextToken());
					Proceso.error=Integer.parseInt(st.nextToken());
					Proceso.bloqueo=Integer.parseInt(st.nextToken());
					System.out.println("ID: "+Proceso.ID);
					System.out.println("tama�o: "+Proceso.tama�o);
					System.out.println("prioridad: "+Proceso.prioridad);
					System.out.println("error: "+Proceso.error);
					System.out.println("bloqueo: "+Proceso.bloqueo);
					System.out.println("contbloq: "+Proceso.contbloq+"\n\n");
					ListadeProcesos.add(Proceso);
					Proceso= new Proceso();
				}
				
			}
			
			linea = s.nextLine();
			Memoria=new int[2][cantInstrucciones+cantDatos];
			
				for(i=0;i<cantInstrucciones;i++){
					linea = s.nextLine();
					st = new StringTokenizer(linea,":");
					Memoria[0][i]=Integer.parseInt(st.nextToken());
	       			Memoria[1][i]=Integer.parseInt(st.nextToken());
				}
				
				linea = s.nextLine();
				for(;i<cantDatos+cantInstrucciones;i++){
					linea = s.nextLine();
					st = new StringTokenizer(linea,":");
	       			Memoria[0][i]=Integer.parseInt(st.nextToken());
	    			Memoria[1][i]=Integer.parseInt(st.nextToken());
	    			   
	    		   }
				
				Ejecucion.Procesa=new PROCESA(cantInstrucciones,cantDatos, primInst, primDat, Memoria);
				Ejecucion.Memoria=putMem();
				Ejecucion.Procesa.ImprimeMem();
			s.close();
			
			}	
		catch (IOException e){
			e.printStackTrace();
		}
		
	}
	
	public void Mostrar(){
				
		for (int i = 0; i <tabla.getRowCount();)
	           tabla.removeRow(i);
	           
		
		ArrayList<Object[]> ListaProcesos = new ArrayList<Object[]>();
		Proceso ProcesoAux = new Proceso();
		Object[] fila = new Object[6];
		 
		for(int aux=0;aux<cantProcesos;aux++){
			ProcesoAux=ListadeProcesos.get(aux);
			
			   fila[0]=ProcesoAux.ID;
			   fila[1]=ProcesoAux.tama�o;
			   fila[2]=ProcesoAux.prioridad;
			   fila[3]=ProcesoAux.error;
			   fila[4]=ProcesoAux.bloqueo;
			   fila[5]=ProcesoAux.contbloq;
			   ListaProcesos.add(fila);
			   fila= new Object[6];
		}
						
			Iterator<Object[]> iterador = ListaProcesos.iterator();
			while(iterador.hasNext()){
			        Object[] f = iterador.next();
			        this.tabla.addRow(f);
			}
			//System.out.println("Tama�o del vector: "+ListadeProcesos.size());
	}
	
	public Vector<Proceso> getListaProcesos(){
		return ListadeProcesos;
	}
	
	public void setListadeProcesos(Vector<Proceso> Lista){
		this.ListadeProcesos=Lista;
	}
	
	public void Ejecutar(){
	
		switch(Estado){
		
		case 1:
		   Nuevo.setListadeNuevos(ListadeProcesos);
		   Nuevo.Mostrar();
		   Estado=2;
		break;	
	  
		case 2:
		   if(Listo.ListadeListos.size()==0&&Nuevo.ListadeNuevos.size()>0){
			   Listo.setListadeListos(Nuevo.getListaNuevos());
		   }
		   
		   Estado=3;
		   break;
		
		case 3:
			
			if(Ejecucion.ProcesoenEjecucion.ID==""){
				if(Listo.ListadeListos.size()>0)
					Ejecucion.setProcesoenEjecucion(Listo.getunListo());
				quantum=0;
			}
			
			else if(quantum<20){
				Ejecucion.Ejecutar();
			    switch(Ejecucion.situacion){
				   case 1:
					   Terminado.putunTerminado(Ejecucion.getProcesoenEjecucion());
					   break;

				   case 2:
					   Bloqueado.putunBloqueado(Ejecucion.getProcesoenEjecucion());
					   break;
			    }
			    quantum++;
			}
			else {
				Listo.putunListo(Ejecucion.getProcesoenEjecucion());
			    quantum=0;
			    //Algoritmo();                                              //En caso de que requiera re ordenar en cada vuelta
			}
			
			Bloqueado.ajusteBloqueados();
			if(Bloqueado.flagbloq==1)
				Listo.putunListo(Bloqueado.getunBloqueado());
			
		      //System.out.println("Etapa de muestra");
		      Nuevo.Mostrar();
		      Listo.Mostrar();
		      Ejecucion.Mostrar();
		      Bloqueado.Mostrar();
		      Terminado.Mostrar();
		      
		   if(Terminado.ListadeTerminados.size()==cantProcesos)
			   timer.stop();
		    
		   //System.out.println("Caso 3 Quantum: "+quantum);
		break;
		
		}
	}
		
		
	public int[][] putMem(){
		return Memoria;
	}
	
	public static void main(String[] args) throws Exception
    {
    	
        Procesador CPU= new Procesador();
        CPU.setVisible(true);
        
    }
	
}