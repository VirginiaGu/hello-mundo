import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JToolBar;
import javax.swing.JButton;


public class Nuevos extends JFrame{

	String[] titulos={"Proceso","Tama�o","Prioridad","Error","Bloqueo"};
	String t="";
	int algoritmo, cantNuevos;

	Proceso Proceso = new Proceso();
	
	Vector<Proceso> ListadeNuevos = new Vector<Proceso>();
	
	JPanel contentPane;
	JTable table = new JTable();
	DefaultTableModel tabla;
		
	
	public Nuevos(){
		super("\tNuevos");
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(371,0,370,300);

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		setContentPane(contentPane);
		
		table.setModel(new DefaultTableModel(new Object[][] {},titulos));
		
		tabla=(DefaultTableModel) table.getModel();
		
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
			
				
	}
	
		
	public void Mostrar(){
		
		for (int i = 0; i <this.tabla.getRowCount();)
	           this.tabla.removeRow(i);
		
		ArrayList<Object[]> ListaNuevos = new ArrayList<Object[]>();
		Proceso ProcesoAux = new Proceso();
		Object[] fila = new Object[5];
		cantNuevos=ListadeNuevos.size(); 
		
		for(int aux=0;aux<cantNuevos;aux++){
			ProcesoAux=ListadeNuevos.get(aux);
			
			   fila[0]=ProcesoAux.ID;
			   fila[1]=ProcesoAux.tama�o;
			   fila[2]=ProcesoAux.prioridad;
			   fila[3]=ProcesoAux.error;
			   fila[4]=ProcesoAux.bloqueo;
			   ListaNuevos.add(fila);
			   fila= new Object[5];
		}
						
			Iterator<Object[]> iteradora = ListaNuevos.iterator();
			while(iteradora.hasNext()){
			        Object[] f = iteradora.next();
			        this.tabla.addRow(f);
			}		
	}
	
	public Vector<Proceso> getListaNuevos(){
		Vector<Proceso> ListadeNuevosAux = new Vector<Proceso>();
		while(ListadeNuevos.size()>0){
			ListadeNuevosAux.add(ListadeNuevos.get(0));
		ListadeNuevos.remove(0);
	}   	    	 
		return ListadeNuevosAux;
	}
	
	public void setListadeNuevos(Vector<Proceso> Lista){
		this.ListadeNuevos=Lista;
	}	

}