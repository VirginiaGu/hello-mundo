//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 3
package sistemaDistribuido.sistema.rpc.modoUsuario;

//import sistemaDistribuido.sistema.rpc.modoMonitor.RPC;  //para pr�ctica 4
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.rpc.modoUsuario.Libreria;
import sistemaDistribuido.util.Escribano;

public class LibreriaCliente extends Libreria{

	/**
	 * 
	 */
	public LibreriaCliente(Escribano esc){
		super(esc);
	}

	/**
	 * Ejemplo de resguardo del cliente suma
	 */
	protected void suma(){
		int asaDest=0;
		//...

		//asaDest=RPC.importarInterfaz(nombreServidor, version)  //para pr�ctica 4
		Nucleo.send(asaDest,null);
		//...
	}
	
	protected void sum(){
		int num1,num2;
		byte[] solCliente=new byte[1024];
		byte[] respCliente=new byte[1024];
		solCliente[9]=(int) 0;
		solCliente[8]=(int) 1;
		num1=(int) pila.peek();
		pila.pop();
		num2=(int) pila.peek();
		pila.pop();
		for(int i=11;i<15;i++){
				solCliente[i]=(byte)(num1);
				num1=num1>>>8;
		}
		for(int i=15;i<19;i++){
			solCliente[i]=(byte)(num2);
			num2=num2>>>8;
	}
		imprimeln("\nEl mensaje se esta enviando...");
		Nucleo.send(248,solCliente);
		imprimeln("\nLlamando a receive...");
		Nucleo.receive(Nucleo.dameIdProceso(),respCliente);
		imprimeln(" Procesando respuesta del servidor");
		int aux=0x00000000;
		int emp,blanqueador;
		for(int i=14;i>=11;i--){
			aux=(aux<<8);
			emp= respCliente[i];
			blanqueador=0x000000FF;
			emp= (emp&blanqueador);
			aux=(aux|emp);
		}
		pila.push(Integer.valueOf(aux));
	}
	
	protected void cubo(){
		int num1;
		byte[] solCliente=new byte[1024];
		byte[] respCliente=new byte[1024];
		solCliente[9]=(int) 0;
		solCliente[8]=(int) 2;
		num1=(int) pila.peek();
		pila.pop();
			for(int i=11;i<15;i++){
				solCliente[i]=(byte)(num1);
				num1=num1>>>8;
			}
		imprimeln("\nEl mensaje se esta enviando...");
		Nucleo.send(248,solCliente);
		imprimeln("\nLlamando a receive...");
		Nucleo.receive(Nucleo.dameIdProceso(),respCliente);
		imprimeln(" Procesando respuesta del servidor");
		int aux=0x00000000;
		int emp,blanqueador;
		for(int i=14;i>=11;i--){
			aux=(aux<<8);
			emp= respCliente[i];
			blanqueador=0x000000FF;
			emp= (emp&blanqueador);
			aux=(aux|emp);
		}
		pila.push(Integer.valueOf(aux));
	}
	
	protected void div(){
		int num1,num2;
		byte[] solCliente=new byte[1024];
		byte[] respCliente=new byte[1024];
		solCliente[9]=(int) 0;
		solCliente[8]=(int) 3;
		num1=(int) pila.peek();
		pila.pop();
		num2=(int) pila.peek();
		pila.pop();
		for(int i=11;i<15;i++){
				solCliente[i]=(byte)(num1);
				num1=num1>>>8;
		}
		for(int i=15;i<19;i++){
			solCliente[i]=(byte)(num2);
			num2=num2>>>8;
		}
		imprimeln("\nEl mensaje se esta enviando...");
		Nucleo.send(248,solCliente);
		imprimeln("\nLlamando a receive...");
		Nucleo.receive(Nucleo.dameIdProceso(),respCliente);
		imprimeln(" Procesando respuesta del servidor");
		int aux=0x00000000;
		int emp,blanqueador;
		for(int i=14;i>=11;i--){
			aux=(aux<<8);
			emp= respCliente[i];
			blanqueador=0x000000FF;
			emp= (emp&blanqueador);
			aux=(aux|emp);
		}
		pila.push(Integer.valueOf(aux));
	}
	
	protected void cuad(){
		int num1;
		byte[] solCliente=new byte[1024];
		byte[] respCliente=new byte[1024];
		solCliente[9]=(int) 0;
		solCliente[8]=(int) 4;
		num1=(int) pila.peek();
		pila.pop();
			for(int i=11;i<15;i++){
				solCliente[i]=(byte)(num1);
				num1=num1>>>8;
			}
		imprimeln("\nEl mensaje se esta enviando...");
		Nucleo.send(248,solCliente);
		imprimeln("\nLlamando a receive...");
		Nucleo.receive(Nucleo.dameIdProceso(),respCliente);
		imprimeln(" Procesando respuesta del servidor");
		int aux=0x00000000;
		int emp,blanqueador;
		for(int i=14;i>=11;i--){
			aux=(aux<<8);
			emp= respCliente[i];
			blanqueador=0x000000FF;
			emp= (emp&blanqueador);
			aux=(aux|emp);
		}
		pila.push(Integer.valueOf(aux));
	}
}