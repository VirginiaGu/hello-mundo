

public class Proceso {
	String ID;
	int tama�o, prioridad, error, bloqueo;
	int contbloq;
	
	Proceso(){
		tama�o=prioridad=error=bloqueo=contbloq=0;
		ID="";
		
	}
	
   
}