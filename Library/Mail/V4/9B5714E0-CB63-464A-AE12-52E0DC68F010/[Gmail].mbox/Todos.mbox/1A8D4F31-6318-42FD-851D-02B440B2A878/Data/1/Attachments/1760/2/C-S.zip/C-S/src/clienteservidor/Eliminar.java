/*Sofía Silva Villalobos
  Sección: D01
  Práctica #3
*/

package clienteservidor;

import java.awt.event.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Eliminar extends JFrame implements Runnable, ActionListener{
    JLabel lblClientes=new JLabel("CLIENTES:");
    JLabel lblServidores=new JLabel("SERVIDORES:");
    JButton cmdEliminar=new JButton("ELIMINAR");
    JTextArea txtClientes=new JTextArea();
    JTextArea txtServidores=new JTextArea();
    JComboBox comboProcesosExistentes;
    
    Nucleo Nucleo;
    
    Hashtable<String,Procesos> TablaProcesos= new Hashtable<String,Procesos>();
    Vector<Procesos> ServidoresDisponibles=new Vector<Procesos>();
    
    public Eliminar(Hashtable<String,Procesos> pro,Vector<Procesos> ser,Nucleo nucleo){
        super("ELIMINAR");
        this.setBounds(0,0,500,400);
        lblClientes.setBounds(25,10,100,25);
        lblServidores.setBounds(250,10,100,25);
        txtClientes.setBounds(25,40,200,260);
        txtServidores.setBounds(250,40,200,260);
        comboProcesosExistentes=new JComboBox<String>();
        comboProcesosExistentes.setBounds(100,310,100,30);
        cmdEliminar.setBounds(250,310,100,30);
        
        this.add(lblClientes);
        this.add(lblServidores);
        this.add(txtClientes);
        this.add(txtServidores);
        this.add(comboProcesosExistentes);
        this.add(cmdEliminar);
        
        this.setLayout(null);
        cmdEliminar.addActionListener(this);
        txtClientes.setEditable(false);
        txtServidores.setEditable(false);
        
        TablaProcesos=pro;
        ServidoresDisponibles=ser;
        this.setVisible(true);
        
        Nucleo=nucleo;
    }
    
    public void run() {
        while(true){
            try {
                MostrarProcesos();
                Thread.sleep(4000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Eliminar.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
    }
    
    public void MostrarProcesos(){
        txtClientes.setText("");
        txtServidores.setText("");
        comboProcesosExistentes.removeAllItems();
        
        if(!TablaProcesos.isEmpty()){
            Procesos procesoAux;
            Enumeration<String> llaves = TablaProcesos.keys();
            String llaveActual;
            comboProcesosExistentes.removeAllItems();
            while (llaves.hasMoreElements()) {				
		llaveActual=llaves.nextElement();
		//if(TablaProcesos.get(llaveActual).isVisible()){
                    comboProcesosExistentes.addItem(llaveActual);
                    procesoAux=TablaProcesos.get(llaveActual);
                    
                    int tamanio=ServidoresDisponibles.size();
                    boolean esServidor=false;
                    
                    if(!ServidoresDisponibles.isEmpty()){
                        for(int i=0;i<tamanio;i++){
                           if(ServidoresDisponibles.get(i)==TablaProcesos.get(llaveActual))
                               esServidor=true;
                        }
                    }
                    
                    if(esServidor==true)
                        txtServidores.append(procesoAux.id+"\t"+ procesoAux.ip+"\n");
                    else
                        txtClientes.append(procesoAux.id+"\t"+ procesoAux.ip+"\n");			
            }
        }
    }
    
    public void EliminarProceso(){
        String idProcesoEliminar=comboProcesosExistentes.getSelectedItem().toString();
        if(TablaProcesos.get(idProcesoEliminar) != null)
        {
            Procesos procesoAux;
            procesoAux=TablaProcesos.get(idProcesoEliminar);
            TablaProcesos.remove(idProcesoEliminar);
            
            int tamanio=Nucleo.ServidoresDisponibles.size();
                        
            if(!Nucleo.ServidoresDisponibles.isEmpty()){
                for(int i=0;i<tamanio;i++){
                    if(Nucleo.ServidoresDisponibles.get(i)==TablaProcesos.get(idProcesoEliminar)){
                        Nucleo.ServidoresDisponibles.remove(i);
                    }
                }
            }
            
            if(!Nucleo.TablaServidores.isEmpty()){
                Nucleo.TablaServidores.remove(idProcesoEliminar);
            }
            
            if(!Nucleo.TablaMaquinas.isEmpty()){
                int finalizar=0;
                Enumeration<String> llaves=Nucleo.TablaMaquinas.keys();
                String llaveActual;
                while (llaves.hasMoreElements() && finalizar==0) {				
                    llaveActual=llaves.nextElement();
                    if(Nucleo.TablaMaquinas.get(llaveActual).equals(idProcesoEliminar)){
                        finalizar=1;
                        Nucleo.TablaMaquinas.remove(llaveActual);
                    }
                }
            }
            
            procesoAux.dispose();
            
            JOptionPane.showMessageDialog(null, "Proceso "+idProcesoEliminar+" eliminado con éxito","", JOptionPane.INFORMATION_MESSAGE);
            MostrarProcesos();
        }
        else
            JOptionPane.showMessageDialog(null, "Proceso no existente","", JOptionPane.INFORMATION_MESSAGE); 
    }
    
    public void actionPerformed(ActionEvent e) {
        Object presionado=e.getSource();
	if(presionado==cmdEliminar){
            EliminarProceso();
	}
    }
}