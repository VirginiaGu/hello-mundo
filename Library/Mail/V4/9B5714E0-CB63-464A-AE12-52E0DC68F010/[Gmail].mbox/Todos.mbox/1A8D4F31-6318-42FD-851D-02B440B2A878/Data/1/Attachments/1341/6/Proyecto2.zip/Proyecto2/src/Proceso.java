public class Proceso {
	String ID;
	int tama�o, prioridad, error, bloqueo;
	int contador;
	
	Proceso(){
		tama�o=prioridad=error=bloqueo=contador=0;
		ID="";		
	}//Proceso	  
}//class Proceso