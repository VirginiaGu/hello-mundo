/*Sofía Silva Villalobos
  Sección: D01
  Práctica #3
*/

package clienteservidor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ResguardoServidor implements Runnable {
    Nucleo Nucleo;
    Procesos servidor;
    ByteArrayOutputStream buffer=new ByteArrayOutputStream();
    int operacion,numero1,numero2,resultado;
    boolean recibir,llegoMensaje;
    String idDestino;
    
    public ResguardoServidor(Procesos s,Nucleo nucleo){
        Nucleo=nucleo;
        servidor=s;
    }
    public void run() {
        while(true){
            try {
                byte[] m=new byte[2];
                        
                if(this.recibir==true){
                    RecibirPeticiones();
                    recibir=false;
                    RealizarOperacion();
                    servidor.txtResguardo.append("\nInvocando a Send()\n");
                    CrearMensaje();
                }
                if(this.llegoMensaje==true)
                    llegoMensaje=false;
                    Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
    }
    
    public void RecibirPeticiones(){   
        buffer.reset();
        Nucleo.Receive(servidor.id,buffer.toByteArray());
        
        byte[] mensaje=buffer.toByteArray();
        String idDest="";
        idDest+=Byte.toString(mensaje[0]);
	idDest+=Byte.toString(mensaje[1]);
        
        idDestino=Integer.toString(Integer.parseInt(idDest));
        Nucleo.TablaResguardosClientes.get(idDestino).llegoMensaje=true;
        
        servidor.txtEventos.append("Recibio: REQ("+Integer.parseInt(idDest)+",");
        int tamanio=mensaje.length;
        for(int x=0;x<tamanio;x++){
            servidor.txtEventos.append(Byte.toString(mensaje[x]));
        }
        servidor.txtEventos.append(","+servidor.id+")\n");

        Nucleo.TablaProcesos.get(idDestino).txtEventos.append("Recibio: ACK("+servidor.id+","+Integer.parseInt(idDest)+")\n");
        Nucleo.TablaProcesos.get(idDestino).txtResguardo.append("\nInvocando a Receive()\n");
        servidor.txtResguardo.append("Mensaje recibido: ");
        for(int x=0;x<tamanio;x++){
            servidor.txtResguardo.append(Byte.toString(mensaje[x]));
        }
        servidor.txtResguardo.append("\n");
        MeterParametros(mensaje);
        servidor.txtResguardo.append("Procesando peticion recibida de cliente\n");
        Dormir();
        servidor.txtEventos.append("Recibio: AYA("+Integer.parseInt(idDest)+","+servidor.id+")\n");
        Nucleo.TablaProcesos.get(idDestino).txtEventos.append("Recibio: IAA("+servidor.id+","+Integer.parseInt(idDest)+")\n");
        
        //ObtenerDatos(buffer.toByteArray());
        
        Nucleo.Peticiones.remove(Integer.toString(servidor.id));
    }
    
    public void MeterParametros(byte[] mensaje){
        ObtenerDatos(buffer.toByteArray());
        servidor.txtResguardo.append("Meter parametros\n");
        Dormir();
                
        if(mensaje[5]==1)
            servidor.pila.push("ADD");
        else if(mensaje[5]==2)
            servidor.pila.push("SUB");
        else if(mensaje[5]==3)
            servidor.pila.push("MUL");
        else if(mensaje[5]==4)
            servidor.pila.push("DIV");
        else if(mensaje[5]==5)
            servidor.pila.push("MOD");
        
        servidor.pila.push(Integer.toString(numero1));
        servidor.pila.push(Integer.toString(numero2));
        
        int tamanioPila=servidor.pila.size(),x=0;
        while(x<tamanioPila){
            servidor.txtPila.append(servidor.pila.get(x)+"\n");
            x++;
        }
        
    }
    
    public void EliminarParametros(){
        int x=0;
        int tamaniopila=servidor.pila.size();
        while(x<tamaniopila){
            servidor.pila.set(x, null);
            x++;
        }
        x=0;
        servidor.txtPila.setText("");
        while(x<tamaniopila){
            if(servidor.pila.get(x)!=null)
                servidor.txtPila.append(servidor.pila.get(x)+"\n");
            x++;
        }
    }
    
    public void ObtenerDatos(byte[] mensaje){
        byte[] cod=new byte[2];
        cod[0]=mensaje[4];
        cod[1]=mensaje[5];
        byte[] tamanio=new byte[2];
        
        operacion=ConvertirByteEntero(cod);
        
        tamanio[0]=mensaje[6];
        tamanio[1]=mensaje[7];
        int tamanioOp1=ConvertirByteEntero(tamanio);
        
        tamanio[0]=mensaje[8];
        tamanio[1]=mensaje[9];
        int tamanioOp2=ConvertirByteEntero(tamanio);
        
        int i,j;
        numero1=0;
        numero2=0;
        j=10;
        for(i=0;i<tamanioOp1;i++){
            int num=mensaje[j];
            if(num!=0)
                num-=48;
            numero1=(numero1*10)+num;
            j++;
        }
        for(i=0;i<tamanioOp2;i++){
            int num=mensaje[j];
            if(num!=0)
                num-=48;
            numero2=(numero2*10)+num;
            j++;
        }
        servidor.txtResguardo.append("Parametros desempacados: "+numero1);
        if(operacion==1)
            servidor.txtResguardo.append("+");
        else if(operacion==2)
            servidor.txtResguardo.append("-");
        else if(operacion==3)
            servidor.txtResguardo.append("*");
        else if(operacion==4)
            servidor.txtResguardo.append("/");
        else
            servidor.txtResguardo.append("%");
        servidor.txtResguardo.append(numero2+"\n");
    }
    
    public void RealizarOperacion(){
        servidor.txtResguardo.append("Llamando al servidor\n");
        Dormir();
        servidor.txtEventos.append("Sacando parametros\n");
        Dormir();
        servidor.txtEventos.append("Realizando Operación\n");
        Dormir();
        switch(operacion)  {
	    case 1: Suma();  	  
	    break;
	    case 2: Resta();        
	    break;
	    case 3: Multiplicacion();
	    break;
	    case 4: Division();
	    break;
	    case 5: Modulo();   	  
	    break;
	}
        servidor.txtEventos.append("Operación realizada\n");
        EliminarParametros();
        servidor.txtEventos.append("Enviando resultado a resguardo\n");
        Dormir();
        servidor.txtResguardo.append("Resultado recibido: "+resultado+"\n");
        servidor.txtResguardo.append("Empacando resultado\n");
    }
    
    public void Suma(){
        servidor.txtEventos.append(numero1+ " + "+numero2+"\n");
	resultado=numero1+numero2;  
    }
    
    public void Resta(){
        servidor.txtEventos.append(numero1+ " - "+numero2+"\n");
	resultado=numero1-numero2; 
    }
    
    public void Multiplicacion(){
        servidor.txtEventos.append(numero1+ " * " +numero2+"\n");
	resultado=numero1*numero2;
    }
    
    public void Division(){
        servidor.txtEventos.append(numero1+ " / "+numero2+"\n");
	resultado=numero1/numero2;
    }
    
    public void Modulo(){
        servidor.txtEventos.append(numero1+ " % "+numero2+"\n");
	resultado=numero1%numero2; 
    }
    
    public void CrearMensaje(){
        servidor.txtResguardo.append("Generando mensaje a ser enviado,llenando los campos necesarios\n");
        Dormir();
        
            try {
                buffer.reset();
                buffer.write(ConvertirResultadoBytes(resultado));
                Nucleo.CompletarMensajeServidor(servidor.id,Integer.parseInt(idDestino),buffer.toByteArray());
            } catch (IOException ex) {
                Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
            } 
    }
      
    public byte[] ConvertirResultadoBytes(int numero){
        String resCadena= Integer.toString(numero);
        int i=0;
        char[] resCaracteres=resCadena.toCharArray();
        byte[] resultado=new byte[resCaracteres.length];
        while(i<resCaracteres.length){
            byte[] opBytes=resCadena.getBytes();
            resultado[i]=opBytes[i];
            i++;
        }
        return resultado;
    }
    
    public int ConvertirByteEntero(byte[] numero){
        int byte1=(byte)numero[0];
        int byte2=(byte)numero[1];
        int entero=ConvertirBinario(byte1,byte2);
        return entero;
    }
    
    public int ConvertirBinario(int num1,int num2){
        char[] cadenaBinaria=new char[17];
        int dividendo,nuevo_dividendo,residuo,pos=15;
        char caracter;
        
        for(int i=0;i<16;i++){
            cadenaBinaria[i]='0';
        }

        dividendo=num2;
        nuevo_dividendo=dividendo/2;

        while(nuevo_dividendo!=0){
            residuo=dividendo%2;
            caracter=(char)(residuo+48);
            cadenaBinaria[pos]=caracter;
            pos--;
            dividendo=nuevo_dividendo;
            nuevo_dividendo=dividendo/2;
        }
        caracter=(char)(dividendo+48);
        cadenaBinaria[pos]=caracter;
        pos--;
        
        dividendo=num1;
        nuevo_dividendo=dividendo/2;

        while(nuevo_dividendo!=0){
            residuo=dividendo%2;
            caracter=(char)(residuo+48);
            cadenaBinaria[pos]=caracter;
            pos--;
            dividendo=nuevo_dividendo;
            nuevo_dividendo=dividendo/2;
        }
        caracter=(char)(dividendo+48);
        cadenaBinaria[pos]=caracter;
        
        
        int entero=ConvertirEntero2(cadenaBinaria);
        return entero;
    }
    
    public int ConvertirEntero2(char[] cadenaBinaria){
        int num,suma=0;
        for(int x=0;x<16;x++){
            if(cadenaBinaria[x]=='0'||cadenaBinaria[x]=='1'){
                num=(int)(cadenaBinaria[x]-48);
                suma=(suma*2)+num;
            }
        }
        
        return suma;
    }
   
    public void Dormir(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Procesos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
