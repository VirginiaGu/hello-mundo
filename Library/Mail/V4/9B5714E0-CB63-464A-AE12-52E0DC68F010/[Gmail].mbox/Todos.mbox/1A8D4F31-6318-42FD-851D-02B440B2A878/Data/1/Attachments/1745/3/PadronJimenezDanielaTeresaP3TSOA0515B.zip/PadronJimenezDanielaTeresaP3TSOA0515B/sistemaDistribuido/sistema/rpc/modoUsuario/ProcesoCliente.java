//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 3
package sistemaDistribuido.sistema.rpc.modoUsuario;

import java.util.StringTokenizer;


import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 */
public class ProcesoCliente extends Proceso{
	private Libreria lib;
	private String Suma;
	private String Cubo;
	private String Division;
	private String Cuadrado;
	/**
	 * 
	 */
	public ProcesoCliente(Escribano esc){
		super(esc);
		//lib=new LibreriaServidor(esc);  //primero debe funcionar con esta para subrutina servidor local
		lib=new LibreriaCliente(esc);  //luego con esta comentando la anterior, para subrutina servidor remota
		start();
	}

	/**
	 * Programa Cliente
	 */
	public void run(){
		/*int sum1,sum2,minuendo,sustraendo,multiplicando,multiplicador,dividendo,divisor;

		sum1=8;
		sum2=7;
		minuendo=6;
		sustraendo=5;
		multiplicando=4;
		multiplicador=4;
		dividendo=2;
		divisor=1;*/

		imprimeln("Proceso cliente en ejecucion.");
		imprimeln("Esperando datos para continuar.");
		Nucleo.suspenderProceso();
		imprimeln("Salio de suspenderProceso");
		
		int resultado;
		StringTokenizer token;
		int i,cont=0, aux;
		byte [] Operacion= new byte[1024];
		token=new StringTokenizer(Suma);
		while(token.hasMoreTokens()){
			aux=Integer.parseInt(token.nextToken());
			for(i=cont;i<cont+4;i++){
				Operacion[i]=(byte)(aux);
				aux=aux>>>8;
			}
			cont=i;
		}
		resultado=lib.sum(Operacion);
		imprimeln("suma="+resultado);
		token=null;
		cont=0;
		aux=0;
		
		/*Operacion2*/
		token=new StringTokenizer(Cubo);
		while(token.hasMoreTokens()){
			aux=Integer.parseInt(token.nextToken());
			for(i=cont;i<cont+4;i++){
				Operacion[i]=(byte)(aux);
				aux=aux>>>8;
			}
			cont=i;
		}
		resultado=lib.cubo(Operacion);
		imprimeln("Cubo="+resultado);
		token=null;
		cont=0;
		aux=0;
				
		/*Operacion3*/
		token=new StringTokenizer(Division);
		while(token.hasMoreTokens()){
			aux=Integer.parseInt(token.nextToken());
			for(i=cont;i<cont+4;i++){
				Operacion[i]=(byte)(aux);
				aux=aux>>>8;
			}
			cont=i;
		}
		resultado=lib.div(Operacion);
		imprimeln("Division="+resultado);
		token=null;
		cont=0;
		aux=0;
		

			/*Operacion4*/
			token=new StringTokenizer(Cuadrado);
			while(token.hasMoreTokens()){
				aux=Integer.parseInt(token.nextToken());
				for(i=cont;i<cont+4;i++){
					Operacion[i]=(byte)(aux);
					aux=aux>>>8;
				}
				cont=i;
			}
			resultado=lib.cuad(Operacion);
			imprimeln("Cuadrado="+resultado);
			token=null;
			cont=0;
			aux=0;
		imprimeln("Fin del cliente.");
	}

	
	public void Datos(String text, String text2, String text3, String text4) {
		// TODO Auto-generated method stub
		Suma=text;
		Cubo=text2;
		Division=text3;
		Cuadrado=text4;
		
	}
}
