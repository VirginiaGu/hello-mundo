
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JToolBar;
import javax.swing.JButton;


public class Terminados extends JFrame{

	String[] titulos={"Proceso","Tama�o","Prioridad","Error","Bloqueo"};
	String t="";
	int algoritmo, cantTerminados;

	
	Vector<Proceso> ListadeTerminados = new Vector<Proceso>();
	
	JPanel contentPane;
	JTable table = new JTable();
	DefaultTableModel tabla;
		
	
	public Terminados(){
		super("\tTerminados");
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(742,302,370,300);

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		setContentPane(contentPane);
		
		table.setModel(new DefaultTableModel(new Object[][] {},titulos));
		
		tabla=(DefaultTableModel) table.getModel();
		
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
			
				
	}
	
		
	public void Mostrar(){
		
		for (int i = 0; i <tabla.getRowCount();)
	           tabla.removeRow(i);
		
		ArrayList<Object[]> ListaTerminados = new ArrayList<Object[]>();
		Proceso ProcesoAux = new Proceso();
		Object[] fila = new Object[5];
		cantTerminados=ListadeTerminados.size(); 
		
		for(int aux=0;aux<cantTerminados;aux++){
			ProcesoAux=ListadeTerminados.get(aux);
			
			   fila[0]=ProcesoAux.ID;
			   fila[1]=ProcesoAux.tama�o;
			   fila[2]=ProcesoAux.prioridad;
			   fila[3]=ProcesoAux.error;
			   fila[4]=ProcesoAux.bloqueo;
			   //fila[5]=ProcesoAux.contbloq;
			   ListaTerminados.add(fila);
			   fila= new Object[5];
		}
						
			Iterator<Object[]> iterador = ListaTerminados.iterator();
			while(iterador.hasNext()){
			        Object[] f = iterador.next();
			        tabla.addRow(f);
			}		
	}
	
	
	public void putunTerminado(Proceso Finalizado){
		ListadeTerminados.add(Finalizado);
		
	}
	
}