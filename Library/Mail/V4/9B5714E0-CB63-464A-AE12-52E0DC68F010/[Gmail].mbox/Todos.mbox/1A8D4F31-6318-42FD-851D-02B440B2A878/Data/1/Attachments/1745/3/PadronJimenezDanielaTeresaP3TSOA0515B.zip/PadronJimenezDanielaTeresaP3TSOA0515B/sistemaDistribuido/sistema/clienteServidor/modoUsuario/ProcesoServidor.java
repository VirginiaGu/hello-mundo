//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 2
//Operaciones:
//Para CREAR el archivo solo es necesario ingresar el nombre del archivo seguido de la extension que puede ser .txt o .doc si se ingresa otra extension marcara error. 
//Ej: Tsoa.txt o Tsoa.doc
//Para la opcion de ESCRIBIR se ingresa el titulo del archivo se da un espacio despues una / espacio y enseguida el texto que se desea escribir. 
//Ej: Tsoa.txt / Daniela Padron
//Para LEER solo ingresamos el nombre del archivo.
//Ej: Tsoa.txt
//Para ELIMINAR solo ingresamos el nombre del archivo.
//Ej: Tsoa.txt
package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;
import sistemaDistribuido.util.Pausador;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 */
public class ProcesoServidor extends Proceso{

	/**
	 * 
	 */
	public ProcesoServidor(Escribano esc){
		super(esc);
		start();
	}

	/**
	 * 
	 */
	public void run(){
		imprimeln(" Proceso servidor en ejecucion");
		File archivo;
		FileWriter escribir;
		BufferedReader contenido;
		FileReader lector = null;
		byte[] solServidor=new byte[1024];
		byte[] respServidor;
		String nombre=" ",texto=" ",msj_res=" ";
		int band=0;
		while(continuar()){
			respServidor=new byte[1024];
			imprimeln("\nEsperando peticion de los clientes");
			nombre=" ";
			texto=" "; 
			band=0;
			archivo =null;
			imprimeln("\nLlamando a receive...");
			Nucleo.receive(dameID(),solServidor);
			imprimeln("\nProcesando peticion del cliente..."+solServidor[8]);
			if(solServidor[9]!=-101){
				for (int i=11;i<(int)(solServidor[10]+11);i++){
					if((char)solServidor[i]=='/')
						band=1;
					if(band==1 && (char)solServidor[i-2]=='/')
						band=2;
					if(band==0)
						nombre+=(char)solServidor[i];
					if(band==2)
						texto+=(char)solServidor[i];
				}
				archivo=new File(nombre);
				switch((int)(solServidor[8]))
				{
				case 0:
					imprimeln("\n CREAR");
					imprimeln("Nombre:"+nombre);
						try {
							 Pattern pat = Pattern.compile("[a-z1-9]+(.txt|.doc)");
						       Matcher mat = pat.matcher(nombre);
						       if(mat.find()){
						    	   if (archivo.createNewFile()){					       
									imprimeln("\n El archivo a sido creado exitosamente");
									msj_res ="\n El archivo a sido creado exitosamente";
						    	   }
						        	else{
							        imprimeln("\n ERROR!! Ya existe un archivo con ese nombre");
							        msj_res ="\n ERROR!! Ya existe un archivo con ese nombre";
											}
								        	
						       		}
						       else{
									imprimeln("\n ERROR!! La extension del archivo es incorrecta, recuerda que solo acepta .TXT o .DOC");
									msj_res ="\n ERROR!! La extension del archivo es incorrecta, recuerda que solo acepta .TXT o .DOC";
									}
						} catch (IOException ioe) {
							ioe.printStackTrace();
						}
					break;
				case 1:
					imprimeln("\n ESCRIBIR");
					imprimeln(" Nombre: "+nombre);
					imprimeln(" Texto : "+texto);
					try
					{
						if(archivo.exists()){
						escribir=new FileWriter(archivo,true);
						escribir.write(texto);
						escribir.close();
						imprimeln("\n Se escribio de manera exitosa");
						msj_res ="\n Se escribio de manera exitosa";
					}
						else{
						imprimeln("\n ERROR!! No se puede realizar la escritura, verifique la existencia del archivo");
						msj_res =" ERROR!! No se puede realizar la escritura, verifique la existencia del archivo";
					}}
					catch(Exception e)
					{
					}
				break;
				case 2:
					texto=" ";
					msj_res=" ";
					imprimeln("\n LEER");
					imprimeln("\n Nombre: "+nombre+"\n Lectura: \n  ");
					if(archivo.exists())
						try
						{
							msj_res="Exito al realizar la Lectura \n ";
							lector=new FileReader(archivo);
							contenido=new BufferedReader(lector);
							while((texto=contenido.readLine())!=null)
							{
								imprimeln(texto);
								msj_res+=texto;
							}
							lector.close();
							contenido.close();
						}
						catch (FileNotFoundException e1) {
							e1.printStackTrace();
							imprimeln("\n ERROR!! No se puede realizar la lectura");
							msj_res = "\n ERROR!! No se puede realizar la lectura";
						}
						catch(Exception e)
						{
							imprimeln("\n ERROR!! No se puede realizar la lectura");
							msj_res = "\n ERROR!! No se puede realizar la lectura";
						}
					else{
						imprimeln("\n ERROR!! No se puede realizar la lectura, no existe el archivo");
						msj_res = "\n ERROR!! No se puede realizar la lectura, no existe el archivo";
					}
						
					break;
				case 3:
					imprimeln("\nELIMINAR");
					imprimeln("Nombre: "+nombre);
					if (archivo.delete()){
						imprimeln("\n El archivo se elimino de manera exitosa");
						msj_res ="\n El archivo se elimino de manera exitosa";
					}				
					else{
						imprimeln("\n ERROR!! No pudo ser eliminado el archivo, verifique su existencia");
						msj_res = "\n ERROR!! No pudo ser eliminado el archivo, verifique su existencia";
					}
					break;
				default:
					break;
				}
				int op=11;
	            for(int i=0;i<msj_res.length();i++){
	            	respServidor[op]=(byte)(msj_res.charAt(i));
	            	op++;
	            }
			
			}	
			else
				respServidor[9]=-101;
			imprimeln("\n Procesando petici�n recibida del cliente");
			imprimeln(" Generando mensaje para ser enviado, llenando los campos necesarios");

			int jaux=4;
			for(int i=0;i<4;i++)
			{
				respServidor[i]=solServidor[jaux];
				jaux++;
			}
			jaux=0;
			for(int i=4;i<8;i++)
			{
				respServidor[i]=solServidor[jaux];
				jaux++;
			}
			int dest,aux,blanqueador;
			aux = 0x00000000;
			for(int i = 3;i>=0;i--){
                aux=(aux<<8);
                dest= solServidor[i];
                blanqueador=0x000000FF;
                dest= (dest&blanqueador);
                aux=(aux|dest);
            }dest=aux;
			Pausador.pausa(1000);  //sin esta l�nea es posible que Servidor solicite send antes que Cliente solicite receive
			imprimeln(" Enviando respuesta...");
			Nucleo.send(dest,respServidor);
		}
	}
}
