//*Nombre: Virginia Sayde Gutierrez Gonzalez
//*Seccion: D01
//*Tarea#3: Cadenas en Arreglos de Bytes

import java.util.*;

public class CadenaBytes{	
	byte arreglo []; //arreglo de bytes
	
	public String array(){//funcion para imprimir la cadena
		int length = arreglo[0];
		int i;
		String mensaje="";
		for (i=1; i<length + 1; i++){
			mensaje+=(char)arreglo[i];
		}//for
		return mensaje;
	}//array
	
	public void imprimir(){
		int i;
		for(i=0; i<arreglo.length; i++){
			System.out.println(arreglo[i]+" ");//Imprime el arreglo
		}//for
	}//imprimir
	
	public CadenaBytes(String s){//se le indica el tipo de dato que debe de ser la variable para poder guardar la cadena de caracteres
		bytes(s, s.length());
	}//public CadenaBytes
	
	public void bytes(String c, int length){
		arreglo = new byte[length+1];
		arreglo[0] = (byte) length;
		System.arraycopy(c.getBytes(), 0, arreglo, 1, length);//se copia el arreglo
	}//void bytes
			
	public static void main(String[] args) {
		CadenaBytes cadena = new CadenaBytes("Thomas Kehl");//constructor
		System.out.println(cadena.array());//imprime en pantalla la cadena "Thomas Kehl" 
		cadena.imprimir();
	}//main
}//clase CadenaBytes