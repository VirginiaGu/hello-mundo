//Padron Jimenez Daniela Teresa 206681018 Ing. en Computacion TSOA D05
//Modificado para la practica 3
package sistemaDistribuido.sistema.rpc.modoUsuario;

//import sistemaDistribuido.sistema.rpc.modoMonitor.RPC;   //para pr�ctica 4
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;
import sistemaDistribuido.util.Pausador;

/**
 * 
 */
public class ProcesoServidor extends Proceso{
	private LibreriaServidor ls;   //para pr�ctica 3

	/**
	 * 
	 */
	public ProcesoServidor(Escribano esc){
		super(esc);
		ls=new LibreriaServidor(esc);   //para pr�ctica 3
		start();
	}

	/**
	 * Resguardo del servidor
	 */
	public void run(){
		imprimeln("Proceso servidor en ejecucion.");
		//idUnico=RPC.exportarInterfaz("FileServer", "3.1", asa)  //para pr�ctica 4
		byte[] respServidor;
		byte[] solServidor;
		byte[] aux;
		int resultado=0,j,dest;
		while(continuar()){
			respServidor= new byte [1024];
			solServidor= new byte [1024];
			aux= new byte [1024];
			Nucleo.receive(dameID(),solServidor);
			respServidor[8]=solServidor[8];
			respServidor[9]=solServidor[9];
			switch((int)(solServidor[8])){
			case 1:
				j=0;
				for (int i=11;i<19;i++){
					aux[j]=solServidor[i];
					j++;
				}
				resultado=ls.sum(aux);
				break;
			case 2:
				j=0;
				for (int i=11;i<15;i++){
					aux[j]=solServidor[i];
					j++;
				}
				resultado=ls.cubo(aux);
				break;
			case 3:
				j=0;
				for (int i=11;i<19;i++){
					aux[j]=solServidor[i];
					j++;
				}
				resultado=ls.div(aux);
				break;
			case 4:
				j=0;
				for (int i=11;i<15;i++){
					aux[j]=solServidor[i];
					j++;
				}
				resultado=ls.cuad(aux);
				break;
				
			}
			j=4;
			for (int i=0;i<4;i++){
				respServidor[i]=solServidor[j];
				j++;
			}
			j=4;
			for (int i=0;i<4;i++){
				respServidor[j]=solServidor[i];
				j++;
			}
			imprimeln("Resultado: "+resultado);
			for(int i=11;i<15;i++){
				respServidor[i]=(byte)(resultado);
				resultado=resultado>>>8;
			}
			dest=0x00000000;
			int emp=0, blanqueador;
			for(int i=3;i>=0;i--){
				dest=(dest<<8);
				emp= solServidor[i];
				blanqueador=0x000000FF;
				emp= (emp&blanqueador);
				dest=(dest|emp);
			}
			Pausador.pausa(1000);  //sin esta l�nea es posible que Servidor solicite send antes que Cliente solicite receive
			imprimeln(" Enviando respuesta...:");
			Nucleo.send(dest,respServidor);
		}

		//RPC.deregistrarInterfaz(nombreServidor, version, idUnico)  //para pr�ctica 4
	}
}
