/*Sofía Silva Villalobos
  Sección: D01
  Práctica #3
*/

package clienteservidor;

import java.awt.event.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Procesos extends JFrame implements ItemListener, ActionListener{
    JLabel lblNumeroProceso=new JLabel();
    JLabel lblEventos=new JLabel("Eventos:");
    JLabel lblResguardo=new JLabel("Resguardo:");
    JLabel lblPila=new JLabel("Pila:");
    JLabel lblNumero1=new JLabel("Numero 1:");
    JLabel lblNumero2=new JLabel("Numero 2:");
    JLabel lblCodop=new JLabel("Codop:");
    JTextField txtNumero1=new JTextField();
    JTextField txtNumero2=new JTextField();
    JTextArea txtEventos=new JTextArea();
    JTextArea txtResguardo=new JTextArea();
    JTextArea txtPila=new JTextArea();
    JButton cmdEnviar=new JButton("ENVIAR");
    JButton cmdFinalizar=new JButton("FINALIZAR");
    JComboBox comboCodop;
    JScrollPane scrollPane= new JScrollPane();
    JScrollPane scrollPane2=new JScrollPane();
    
    int id;
    byte codop[]=new byte[2];
    Nucleo Nucleo;
    String ip;
    Stack<String> pila = new Stack<String>();
    
    public Procesos(int Id,String Ip, Nucleo nucleo,int tip){
        super("CLIENTE "+ Ip);
        this.setLayout(null);
        
        this.setBounds(0,0,730,400);
        lblNumeroProceso.setBounds(600,10,100,25);
        lblEventos.setBounds(150,30,50,25);
        lblResguardo.setBounds(370,30,100,25);
        lblPila.setBounds(590,30,100,25);
        lblNumero1.setBounds(25,30,100,25);
        lblNumero2.setBounds(25,90,100,25);
        lblCodop.setBounds(25,150,50,25);
        txtNumero1.setBounds(25,55,100,25);
        txtNumero2.setBounds(25,115,100,25);
        txtPila.setBounds(590,55,100,250);
        comboCodop = new JComboBox<String>();
        comboCodop.setBounds(25,175,100,25);
        cmdEnviar.setBounds(25,220,100,25);
        cmdFinalizar.setBounds(25,300,100,50);
        scrollPane.setBounds(150,55,200,250);
	scrollPane.setViewportView(txtEventos);
        scrollPane2.setBounds(370,55,200,250);
        scrollPane2.setViewportView(txtResguardo);
          
        
        this.add(lblNumeroProceso);
        this.add(lblEventos);
        this.add(lblResguardo);
        this.add(lblPila);
        this.add(lblNumero1);
        this.add(lblNumero2);
        this.add(lblCodop);
        this.add(txtNumero1);
        this.add(txtNumero2);
        this.add(txtPila);
        this.add(cmdFinalizar);
        this.add(cmdEnviar);
        this.add(comboCodop);
        this.add(scrollPane);
        this.add(scrollPane2);
  
        txtEventos.setEditable(false);
        txtResguardo.setEditable(false);
        txtPila.setEditable(false);
        
        cmdEnviar.addActionListener(this);
        cmdFinalizar.addActionListener(this);
        
        comboCodop.addItemListener(this);
        
        comboCodop.addItem("Suma");
	comboCodop.addItem("Resta");
	comboCodop.addItem("Multiplicacion");
        comboCodop.addItem("Division");
	comboCodop.addItem("Modulo");
        
        this.setVisible(true);
        
        lblNumeroProceso.setText("CLIENTE "+Id);
        txtEventos.append("INICIO DE PROCESO\n");
        
        id=Id;
        ip=Ip;
        Nucleo=nucleo;
    }
    public Procesos(int Id,String Ip, Nucleo nucleo){
        super("SERVIDOR " + Ip);
        this.setLayout(null);
        
        this.setBounds(0,0,600,400);
        lblNumeroProceso.setBounds(500,10,100,25);
        lblEventos.setBounds(25,10,50,25);
        lblResguardo.setBounds(250,10,100,25);
        lblPila.setBounds(470,10,100,25);
        cmdFinalizar.setBounds(270,300,100,50);
        txtPila.setBounds(470,35,100,250);
        scrollPane.setBounds(25,35,200,250);
	scrollPane.setViewportView(txtEventos);
        scrollPane2.setBounds(250,35,200,250);
        scrollPane2.setViewportView(txtResguardo);
        
        this.add(lblNumeroProceso);
        this.add(lblEventos);
        this.add(lblResguardo);
        this.add(lblPila);
        this.add(cmdFinalizar);
        this.add(txtPila);
        this.add(scrollPane);
        this.add(scrollPane2);
        
        txtEventos.setEditable(false);
        txtResguardo.setEditable(false);
        txtPila.setEditable(false);
        
        cmdFinalizar.addActionListener(this);
        
        this.setVisible(true);
        
        lblNumeroProceso.setText("SERVIDOR "+Id);
        txtEventos.append("INICIO DE PROCESO\n");
        txtResguardo.append("Invocando a Receive()\n");
        
        id=Id;
        ip=Ip;
        Nucleo=nucleo;
    }
   
    public void MeterParametros(){
        txtEventos.append("Meter parametros\n");
        if(codop[1]==1)
            pila.push("ADD");
        else if(codop[1]==2)
            pila.push("SUB");
        else if(codop[1]==3)
            pila.push("MUL");
        else if(codop[1]==4)
            pila.push("DIV");
        else if(codop[1]==5)
            pila.push("MOD");
        
        pila.push(txtNumero1.getText());
        pila.push(txtNumero2.getText());
        
        int tamanioPila=pila.size(),x=0;
        while(x<tamanioPila){
            txtPila.append(pila.get(x)+"\n");
            x++;
        }
    }
    
    public void itemStateChanged(ItemEvent arg0) {
	if (arg0.getSource()==comboCodop) {
            switch((String)comboCodop.getSelectedItem())
	    {
	        case "Suma":
	            this.codop[0] = 0;
	            this.codop[1] = 1;
	        break;   
	        case "Resta":
	            this.codop[0] = 0;
	            this.codop[1] = 2;
	        break;
	        case "Multiplicacion":
	            this.codop[0] = 0;
	            this.codop[1] = 3;
	        break;    
	        case "Division":
	            this.codop[0] = 0;
	            this.codop[1] = 4;
	        break;    
	        case "Modulo":
	            this.codop[0] = 0;
	            this.codop[1] = 5;
	        break;
	    }
        }
    }
    
    public void actionPerformed(ActionEvent evt){
        Object presionado=evt.getSource();
        if(presionado==cmdEnviar){
            MeterParametros();
            txtEventos.append("Llamando a resguardo\n");
            Nucleo.TablaResguardosClientes.get(Integer.toString(id)).enviar=true;
        }
        if(presionado==cmdFinalizar){
            this.dispose();
        }
    }
    
}
