import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.DefaultCaret;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingConstants;
import javax.swing.ScrollPaneConstants;

public class ClienteGUI extends JFrame {

	private JPanel contentPane;
	private String id;
	private JTextArea textArea;
	private JTextField txtOPR1;
	private JTextField txtOPR2;
	private JTextField txtCoOp;
	private JMenuItem menuEnviar;
	private JTextField textField;
	private JTextField textField_1;

	public ClienteGUI(final String id) {
		this.id = id;
		setTitle(id);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(550, 55, 494, 345);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNuevaSolicitud = new JMenu("Nueva solicitud");
		menuBar.add(mnNuevaSolicitud);
		
		JRadioButtonMenuItem rdbtnmntmSumar = new JRadioButtonMenuItem("Sumar");
		rdbtnmntmSumar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pideOPRs();
				txtCoOp.setText("SMR");
			}
		});
		mnNuevaSolicitud.add(rdbtnmntmSumar);
		
		JRadioButtonMenuItem rdbtnmntmRestar = new JRadioButtonMenuItem("Restar");
		rdbtnmntmRestar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pideOPRs();
				txtCoOp.setText("RST");
			}
		});
		mnNuevaSolicitud.add(rdbtnmntmRestar);
		
		JRadioButtonMenuItem rdbtnmntmMultiplicar = new JRadioButtonMenuItem("Multiplicar");
		rdbtnmntmMultiplicar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pideOPRs();
				txtCoOp.setText("MLT");
			}
		});
		mnNuevaSolicitud.add(rdbtnmntmMultiplicar);
		
		JRadioButtonMenuItem rdbtnmntmDividir = new JRadioButtonMenuItem("Dividir");
		rdbtnmntmDividir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pideOPRs();
				txtCoOp.setText("DVR");
			}
		});
		mnNuevaSolicitud.add(rdbtnmntmDividir);
		
		JRadioButtonMenuItem rdbtnmntmArchivoDeTexto = new JRadioButtonMenuItem("Archivo de texto");
		rdbtnmntmArchivoDeTexto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtCoOp.setText("TXT");
				JFileChooser chooser = new JFileChooser();
				chooser.setAcceptAllFileFilterUsed(false);
			    FileNameExtensionFilter filter = new FileNameExtensionFilter("S�lo archivos de texto", "txt");
			    chooser.setFileFilter(filter);
			    int returnVal = chooser.showOpenDialog(null);
			    if(returnVal == JFileChooser.APPROVE_OPTION) {
			       String ruta = chooser.getSelectedFile().getPath();
			       txtOPR1.setText("---");
			       txtOPR2.setText(ruta);
			       menuEnviar.setEnabled(true);
			    }
			}
		});
		mnNuevaSolicitud.add(rdbtnmntmArchivoDeTexto);
		
		ButtonGroup gb = new ButtonGroup();
		gb.add(rdbtnmntmSumar);
		gb.add(rdbtnmntmRestar);
		gb.add(rdbtnmntmMultiplicar);
		gb.add(rdbtnmntmDividir);
		gb.add(rdbtnmntmArchivoDeTexto);
		
		JMenu mnOpciones = new JMenu("Opciones");
		menuBar.add(mnOpciones);
		
		JMenuItem mntmCerrar = new JMenuItem("Cerrar");
		mntmCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cerrar();
				dispose();
			}
		});
		
		menuEnviar = new JMenuItem("Enviar solicitud");
		menuEnviar.setEnabled(false);
		menuEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StringBuilder sb = new StringBuilder();
				sb.append(getID());
				sb.append("~");
				sb.append(txtCoOp.getText());
				sb.append("~");
				sb.append(txtOPR1.getText());
				sb.append("~");
				sb.append(txtOPR2.getText());
				textArea.append("Datagrama generado correctamente\n");
				textArea.append("Operaci�n solicitada: "+txtCoOp.getText()+"\n");
				textArea.append("Primer operador: "+txtOPR1.getText()+"\n");
				textArea.append("Segundo operador: "+txtOPR2.getText()+"\n");
				textArea.append("Enlazando con MicroN�cleo\n");
				///////////////////////////////////////////////////////////////////////////////////////
				byte[] datagramaEnviar = new byte[1024];
				byte[] datagramaRecibir = new byte[1024];
				datagramaEnviar=sb.toString().getBytes();
				try{
					DatagramSocket clientSocket = new DatagramSocket();
					InetAddress IPAddress = InetAddress.getByName("localhost");
					DatagramPacket paqueteEnviar = new DatagramPacket(datagramaEnviar, datagramaEnviar.length, IPAddress, 25000);
					clientSocket.send(paqueteEnviar);
					DatagramPacket paqueteRecibir = new DatagramPacket(datagramaRecibir, datagramaRecibir.length);      
					clientSocket.receive(paqueteRecibir);
					String response = new String(paqueteRecibir.getData());
										
					if(response.startsWith("No hay")){
						textArea.append("No es posible procesar la solicitud por falta de servidores :(\n");
						textArea.append("�������������������������������������\n");
					}
					else{
						textArea.append("Respuesta recibida desde un servidor\n");
						String[] resp = response.split("~");
						textArea.append(resp[0]+"\n");
						textArea.append(resp[1]+"\n");
						textArea.append("�������������������������������������\n");
					}
					clientSocket.close();
				}catch(IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		mnOpciones.add(menuEnviar);
		mnOpciones.add(mntmCerrar);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 36, 458, 180);
		contentPane.add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		DefaultCaret caret_creados = (DefaultCaret)textArea.getCaret();
		caret_creados.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		scrollPane.setViewportView(textArea);
		
		JLabel lblConstruyendoDatagrama = new JLabel("Construyendo datagrama");
		lblConstruyendoDatagrama.setBounds(10, 227, 196, 14);
		contentPane.add(lblConstruyendoDatagrama);
		
		txtOPR1 = new JTextField();
		txtOPR1.setHorizontalAlignment(SwingConstants.CENTER);
		txtOPR1.setBackground(Color.WHITE);
		txtOPR1.setEditable(false);
		txtOPR1.setBounds(10, 252, 68, 20);
		contentPane.add(txtOPR1);
		txtOPR1.setColumns(10);
		
		txtOPR2 = new JTextField();
		txtOPR2.setHorizontalAlignment(SwingConstants.CENTER);
		txtOPR2.setBackground(Color.WHITE);
		txtOPR2.setEditable(false);
		txtOPR2.setColumns(10);
		txtOPR2.setBounds(123, 252, 214, 20);
		contentPane.add(txtOPR2);
		
		txtCoOp = new JTextField();
		txtCoOp.setHorizontalAlignment(SwingConstants.CENTER);
		txtCoOp.setBackground(Color.WHITE);
		txtCoOp.setEditable(false);
		txtCoOp.setColumns(10);
		txtCoOp.setBounds(382, 252, 86, 20);
		contentPane.add(txtCoOp);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setBackground(Color.WHITE);
		textField.setEditable(false);
		textField.setText("-");
		textField.setBounds(88, 252, 25, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setText("-");
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBackground(Color.WHITE);
		textField_1.setBounds(347, 252, 25, 20);
		contentPane.add(textField_1);
		
		JLabel lblEventos = new JLabel("Eventos");
		lblEventos.setBounds(10, 11, 68, 14);
		contentPane.add(lblEventos);
		textArea.append("Inicio de proceso\n");
		textArea.append("Tipo: Cliente\n");
		textArea.append("ID: "+id+"\n");
		textArea.append("�������������������������������������\n");
	}
	
	public void pideOPRs(){
		Pattern pat = Pattern.compile("-?[0-9]*(\\.?[0-9]+){1}");
		Matcher mat;
		String opr1;
		String opr2;
		do{
			opr1 = JOptionPane.showInputDialog("Cu�l es el primer operador?");
			if(opr1==null)
				return;
			mat = pat.matcher(opr1);
			if(!mat.matches())
				JOptionPane.showMessageDialog(null, "No es correcto", "Error", JOptionPane.ERROR_MESSAGE);
		}while(!mat.matches());
		
		do{
			opr2 = JOptionPane.showInputDialog("Cu�l es el segundo operador?");
			if(opr2==null)
				return;
			mat = pat.matcher(opr2);
			if(!mat.matches())
				JOptionPane.showMessageDialog(null, "No es correcto", "Error", JOptionPane.ERROR_MESSAGE);
		}while(!mat.matches());
		
		txtOPR1.setText(opr1);
		txtOPR2.setText(opr2);
		menuEnviar.setEnabled(true);
	}
	
	private void cerrar(){
		CSControlSingleton clt = CSControlSingleton.getInstance();
		clt.clientePush(this.id);
		clt.eliminarCliente(this.id);
	}
	
	public String getID(){
		return this.id;
	}
}
