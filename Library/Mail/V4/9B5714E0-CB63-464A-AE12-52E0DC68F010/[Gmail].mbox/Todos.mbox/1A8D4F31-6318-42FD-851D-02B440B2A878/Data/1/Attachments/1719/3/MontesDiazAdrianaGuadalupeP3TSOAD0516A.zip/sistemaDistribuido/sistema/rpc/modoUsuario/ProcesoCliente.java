/*
 * Pr�ctica #3: 
 * Llamadas a Procedimientos Remotos (RPC) 
 * �Resguardos del Cliente y del Servidor� 
 * @author: Adriana Guadalupe Montes D�az
 * @code: 210224063
 */

package sistemaDistribuido.sistema.rpc.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 */
public class ProcesoCliente extends Proceso{
	private Libreria lib;
	String campo1;
	String campo2;
	String campo3;
	String campo4;

	/**
	 * 
	 */
	public ProcesoCliente(Escribano esc){
		super(esc);
		//lib=new LibreriaServidor(esc);  //primero debe funcionar con esta para subrutina servidor local
		lib=new LibreriaCliente(esc);  //luego con esta comentando la anterior, para subrutina servidor remota
		start();
		campo1 = "";
		campo2 = "0";
		campo3 = "0";
		campo4 = "0";
	}
	
	public String getCampo1() {
		return campo1;
	}

	public void setCampo1(String campo1) {
		this.campo1 = campo1;
	}

	public String getCampo2() {
		return campo2;
	}

	public void setCampo2(String campo2) {
		this.campo2 = campo2;
	}

	public String getCampo3() {
		return campo3;
	}

	public void setCampo3(String campo3) {
		this.campo3 = campo3;
	}

	public String getCampo4() {
		return campo4;
	}

	public void setCampo4(String campo4) {
		this.campo4 = campo4;
	}

	/**
	 * Programa Cliente
	 */
	public void run(){
		//int sum1,sum2,minuendo,sustraendo,multiplicando,multiplicador,dividendo,divisor;
		int resultado;
		int parameter;
		int base;
		int exp;
		/*
		sum1=8;
		sum2=7;
		minuendo=6;
		sustraendo=5;
		multiplicando=4;
		multiplicador=4;
		dividendo=2;
		divisor=1;
		*/
		
		
		imprimeln("Proceso cliente en ejecucion.");
		imprimeln("Esperando datos para continuar.");
		Nucleo.suspenderProceso();
		imprimeln("Salio de suspenderProceso");

		parameter = Integer.parseInt(campo1);
		resultado = lib.cube(parameter);
		imprimeln("CUBE = "+resultado);
		
		parameter = Integer.parseInt(campo2);
		resultado = lib.factorial(parameter);
		imprimeln("FACTORIAL = "+resultado);
		
		String[] array = campo3.split("\\ ");
		base = Integer.parseInt(array[0]);
		exp = Integer.parseInt(array[1]);
		resultado = lib.pow(base,exp);
		imprimeln("POW = "+resultado);
		
		array = campo4.split("\\ ");
		int[] list = new int[array.length];
		for(int i = 0; i < list.length; i++) {
			list[i] = Integer.parseInt(array[i]);
		}
		resultado = lib.min(list);
		imprimeln("MIN = "+resultado);
		/*
		resultado=lib.suma(sum1,sum2);
		imprimeln("suma="+resultado);
		resultado=lib.resta(minuendo,sustraendo);
		imprimeln("diferencia="+resultado);
		resultado=lib.multiplicacion(multiplicando,multiplicador);
		imprimeln("multiplicacion="+resultado);
		resultado=lib.division(dividendo,divisor);
		imprimeln("cociente="+resultado);
		*/

		imprimeln("Fin del cliente.");
	}
}
